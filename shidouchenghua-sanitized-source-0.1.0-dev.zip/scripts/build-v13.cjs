// V1.3 is the single editable PRD source; do not reconstruct it from old versions.
const path = require('node:path');
const {spawnSync} = require('node:child_process');
const result = spawnSync('python', ['build_prd.py', '照片转拼豆辅助图_PRD_V1.3.md'], {cwd:path.join(__dirname,'..'),stdio:'inherit'});
if(result.error) throw result.error;
process.exitCode = result.status === null ? 1 : result.status;
