// Rasterize the existing vector design for WeChat's image and native tab bar.
// Run after `npm ci` in browser-preview. No image service is used.
const fs = require('node:fs');
const path = require('node:path');
const sharp = require(require.resolve('sharp', {paths:[path.join(__dirname,'../browser-preview')]}));
const root = path.join(__dirname,'../miniprogram/assets');
async function main(){
 fs.mkdirSync(root,{recursive:true});
 for(const name of ['inspiration-flower','inspiration-source']) await sharp(path.join(__dirname,'../browser-preview/public',name+'.svg')).resize(492,492).png().toFile(path.join(root,name+'.png'));
 for(const name of ['flower','heart','cat']) await sharp(path.join(__dirname,'../browser-preview/public/materials',name+'.svg')).resize(512,512).png().toFile(path.join(root,'material-'+name+'.png'));
 const paths={create:'<rect x="4" y="4" width="6" height="6"/><rect x="14" y="4" width="6" height="6"/><rect x="4" y="14" width="6" height="6"/><rect x="14" y="14" width="6" height="6"/>',works:'<path d="M3 6h7l2 2h9v12H3z"/>'};
 paths.library='<rect x="3" y="3" width="7" height="7" rx="1"/><circle cx="17" cy="7" r="4"/><path d="m7 14 4 7H3zM14 15h7v6h-7z"/>';
 paths.community='<path d="M4 4h16v12H9l-5 4zM8 8h8M8 12h5"/>';
 for(const [name,shape] of Object.entries(paths)) for(const [suffix,color] of [['','#8E8E93'],['-active','#007AFF']]) await sharp(Buffer.from(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="${color}" stroke-width="1.7" stroke-linejoin="round">${shape}</g></svg>`)).resize(72,72).png().toFile(path.join(root,name+suffix+'.png'));
}
main().catch(e=>{console.error(e);process.exitCode=1;});
