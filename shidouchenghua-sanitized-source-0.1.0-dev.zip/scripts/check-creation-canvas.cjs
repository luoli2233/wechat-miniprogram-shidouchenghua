// Browser Canvas checks for the shared renderer; does not replace WeChat device QA.
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {chromium}=require(process.env.PLAYWRIGHT_PATH||'playwright');
(async()=>{
 const browser=await chromium.launch({headless:true});try{
  const page=await browser.newPage({viewport:{width:560,height:600},deviceScaleFactor:1});
  await page.setContent('<body style="margin:0;background:#eef2f6;padding:24px;font-family:sans-serif"><canvas id="art" width="512" height="512" style="background:white;border-radius:12px"></canvas><p style="color:#52606c;font-size:13px">自由创作 · 图层渲染验证样例（非微信真机截图）</p></body>');
  await page.addScriptTag({content:'window.module={exports:{}};'+fs.readFileSync(path.join(__dirname,'../miniprogram/core/creative-editor.js'),'utf8')+';window.editor=module.exports;'});
  const result=await page.evaluate(()=>{
   const canvas=document.getElementById('art'),ctx=canvas.getContext('2d'),scratch=document.createElement('canvas'),base={x:50,y:50,size:100,rotation:0,flip:false,opacity:1};
   const below={...base,id:'bg',type:'shape',shape:'rect',color:'#0000ff',fill:true,lineWidth:2};
   const ink={...base,id:'p',type:'paint',strokes:[{color:'#ff0000',width:40,erase:false,points:[[100,256],[400,256]]},{color:'#000000',width:20,erase:true,points:[[256,256]]}]};
   editor.draw(ctx,[below,ink],{},scratch);const pixel=(x,y)=>Array.from(ctx.getImageData(x,y,1,1).data);const erased=pixel(256,256),painted=pixel(180,256);
   editor.draw(ctx,[ink],{},scratch);const transparent=pixel(256,256);
   const picture=document.createElement('canvas');picture.width=400;picture.height=200;picture.getContext('2d').fillStyle='#00ff00';picture.getContext('2d').fillRect(0,0,400,200);
   editor.draw(ctx,[{...base,id:'image',type:'image',material:'photo'}],{photo:picture},scratch);const letterbox=pixel(256,40),center=pixel(256,256);
   return {erased,painted,transparent,letterbox,center};
  });
  assert.deepEqual(result.erased,[0,0,255,255]);assert.deepEqual(result.painted,[255,0,0,255]);assert.equal(result.transparent[3],0);assert.equal(result.letterbox[3],0);assert.deepEqual(result.center,[0,255,0,255]);
  const image='data:image/png;base64,'+fs.readFileSync(path.join(__dirname,'../miniprogram/assets/material-cat.png')).toString('base64');
  await page.evaluate(async src=>{
   const img=new Image();img.src=src;await img.decode();const scratch=document.createElement('canvas'),ctx=document.getElementById('art').getContext('2d'),base={x:50,y:50,size:100,rotation:0,flip:false,opacity:1};
   const layers=[{...base,id:'bg',type:'shape',shape:'circle',color:'#e5f0ec',fill:true,lineWidth:4,size:76},{...base,id:'cat',type:'image',material:'cat',size:55,y:46},{...base,id:'name',type:'text',text:'我的小猫',fontSize:100,color:'#263c35',size:65,y:83},{...base,id:'pen',type:'paint',strokes:[{color:'#e89c80',width:9,erase:false,points:[[80,110],[90,90],[100,110],[120,120],[100,130],[90,150],[80,130],[60,120],[80,110]]},{color:'#73a69c',width:8,erase:false,points:[[400,330],[410,310],[420,330],[440,340],[420,350],[410,370],[400,350],[380,340],[400,330]]}]}];
   editor.draw(ctx,editor.layers(layers,[{id:'cat'}]),{cat:img},scratch,'#ffffff');
  },image);
  const out=path.join(__dirname,'../artifacts/free-creation');fs.mkdirSync(out,{recursive:true});await page.screenshot({path:path.join(out,'canvas-preview.png')});console.log('PASS: eraser isolation, transparent export, source aspect ratio; preview saved to artifacts/free-creation/canvas-preview.png');
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
