"""Package current tracked and non-ignored source; never commit or export history."""
import datetime
import hashlib
import json
import pathlib
import re
import subprocess
import zipfile

ROOT = pathlib.Path(__file__).resolve().parent.parent
BLOCKED = {'.git', 'node_modules', 'artifacts', 'tmp', 'dist', 'coverage',
           '__pycache__', '.next', '.vinext', '.wrangler'}
SECRET = re.compile(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|sk-[A-Za-z0-9]{20,}|gh[pousr]_[A-Za-z0-9]{20,}|AIza[0-9A-Za-z_-]{35}|AKIA[0-9A-Z]{16}')

def allowed(name):
    path = pathlib.PurePosixPath(name)
    return not (set(path.parts) & BLOCKED or any(
        (p == '.env' or p.startswith('.env.') or p.startswith('.dev.vars'))
        and p != '.env.example' for p in path.parts)
        or path.name == 'project.private.config.json'
        or path.suffix.lower() in {'.pem', '.key', '.p12', '.pfx', '.pyc', '.log', '.zip'})

def main():
    names = subprocess.check_output(['git', 'ls-files', '-z', '--cached', '--others', '--exclude-standard'], cwd=ROOT).decode('utf-8').split('\0')
    files = {}
    for name in sorted(set(filter(None, names))):
        path = ROOT / name
        if not allowed(name) or not path.is_file():
            continue
        if path.is_symlink() or ROOT not in path.resolve().parents:
            raise SystemExit('Unsafe path: ' + name)
        data = path.read_bytes()
        if SECRET.search(data):
            raise SystemExit('Potential credential: ' + name)
        files[name] = data
    checks = []
    commands = [('native', ['npm.cmd', 'run', 'verify'], ROOT),
                ('browser-lint', ['npm.cmd', 'run', 'lint:app'], ROOT / 'browser-preview'),
                ('browser-build', ['npm.cmd', 'run', 'build'], ROOT / 'browser-preview')]
    for label, command, cwd in commands:
        result = subprocess.run(command, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        if SECRET.search(result.stdout):
            raise SystemExit('Potential credential in log: ' + label)
        files['verification/' + label + '.txt'] = result.stdout
        checks.append({'name': label, 'exit_code': result.returncode})
        print(label + ': ' + str(result.returncode), flush=True)
        if result.returncode:
            raise SystemExit('Verification failed; no ZIP created: ' + label)
    now = datetime.datetime.now().astimezone()
    manifest = {'product': '拾豆成画', 'version': '0.1.0-dev',
                'created_at': now.isoformat(), 'snapshot': 'current working tree, including uncommitted files',
                'base_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip(),
                'checks': checks, 'production_ready': False,
                'files': {n: hashlib.sha256(b).hexdigest() for n, b in files.items()}}
    files['PACKAGE_MANIFEST.json'] = json.dumps(manifest, ensure_ascii=False, indent=2).encode('utf-8')
    folder = '拾豆成画_源码交接_0.1.0-dev_' + now.strftime('%Y-%m-%d_%H%M%S')
    output = ROOT / 'artifacts' / (folder + '.zip')
    output.parent.mkdir(exist_ok=True)
    with zipfile.ZipFile(output, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in files.items():
            archive.writestr(folder + '/' + name, data)
    with zipfile.ZipFile(output) as archive:
        assert archive.testzip() is None
        assert len(archive.namelist()) == len(files)
        for name, data in files.items():
            assert archive.read(folder + '/' + name) == data, name
    checksum = hashlib.sha256(output.read_bytes()).hexdigest()
    output.with_suffix('.zip.sha256').write_text(checksum + '  ' + output.name + '\n', encoding='utf-8')
    print(json.dumps({'zip': str(output), 'files': len(files), 'bytes': output.stat().st_size, 'sha256': checksum}, ensure_ascii=False))

if __name__ == '__main__':
    main()
