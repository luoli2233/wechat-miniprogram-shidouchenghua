"""Structural check only. Does not replace the WeChat WXML compiler."""
from pathlib import Path
import re
import xml.etree.ElementTree as ET

allowed = {'view', 'text', 'button', 'image', 'canvas', 'slider', 'scroll-view', 'block', 'privacy-guard', 'input', 'picker', 'textarea', 'checkbox-group', 'checkbox', 'label'}
files = list((Path(__file__).resolve().parent.parent / 'miniprogram').rglob('*.wxml'))
for file in files:
    source = file.read_text(encoding='utf-8')
    source = re.sub(r'\bwx:else(?=\s|>)', 'wx:else="true"', source)
    try:
        root = ET.fromstring('<root xmlns:wx="urn:wx">' + source + '</root>')
    except Exception as exc:
        raise RuntimeError(f'{file}: {exc}') from exc
    for element in root.iter():
        assert element.tag in allowed | {'root'}, f'{file}: unexpected tag {element.tag}'
print(f'PASS: {len(files)} WXML files, balanced structure and recognized components')
