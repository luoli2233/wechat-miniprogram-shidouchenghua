const fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..');
const names=['model','palette','quantize','render','examples'];
let text='// Generated from miniprogram/core. Run node scripts/sync-browser-core.cjs to update.\nconst factories = {\n';
for(const name of names)text+=JSON.stringify(name)+': function(record,exports,loadModule){\n'+fs.readFileSync(path.join(root,'miniprogram/core',name+'.js'),'utf8').replace(/\brequire\(/g,'loadModule(').replace(/\bmodule\.exports/g,'record.exports')+'\n},\n';
text+='};\nconst cache={};\nfunction load(name){name=name.replace(/^\\.\\//, "");if(!factories[name])throw new Error("Unknown core module");if(!cache[name]){const module={exports:{}};cache[name]=module;factories[name](module,module.exports,load);}return cache[name].exports;}\nexport const model=load("model"), quantize=load("quantize"), render=load("render"), examples=load("examples");\nexport const {palette,board}=load("palette");\n';
fs.writeFileSync(path.join(root,'browser-preview/lib/bead-core.js'),text);
console.log('Browser adapter updated: five shared modules, no algorithm fork.');
