"""Export committed source and all reachable Git history, without local secrets."""
import argparse
import datetime
import hashlib
import io
import json
import pathlib
import re
import shutil
import subprocess
import zipfile

ROOT = pathlib.Path(__file__).resolve().parent.parent

def git(*args):
    return subprocess.check_output(['git', *args], cwd=str(ROOT))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def unsafe_name(name):
    parts = pathlib.PurePosixPath(name).parts
    return any(p in {'.git', 'node_modules', 'dist', '.wrangler', '.vinext', '.next', 'artifacts'} for p in parts) or any((p == '.env' or p.startswith('.env.') or p.startswith('.dev.vars')) and p != '.env.example' for p in parts) or name.endswith(('.pem', '.key', '.p12', '.pfx', 'project.private.config.json'))

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--verification', required=True, help='Directory containing current verification logs and results.json')
    args = parser.parse_args()
    if git('status', '--porcelain').strip():
        raise SystemExit('Commit the intended changes first; working tree must be clean.')
    verification = pathlib.Path(args.verification).resolve()
    results = json.loads((verification / 'results.json').read_text(encoding='utf-8'))
    if not results['checks'] or any(c['exit_code'] != 0 for c in results['checks']):
        raise SystemExit('Verification results contain failed or incomplete checks.')
    head = git('rev-parse', 'HEAD').decode().strip()
    secret_re = re.compile(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|sk-[A-Za-z0-9]{20,}|gh[pousr]_[A-Za-z0-9]{20,}|AIza[0-9A-Za-z_-]{35}|AKIA[0-9A-Z]{16}')
    # A bundle can retain removed secrets, so inspect every reachable revision.
    checked = set()
    commits = git('rev-list', '--all').decode().splitlines()
    for commit in commits:
        for entry in git('ls-tree', '-r', '-z', commit).split(b'\0'):
            if not entry:
                continue
            header, raw_path = entry.split(b'\t', 1)
            mode, kind, object_id = header.split()
            name = raw_path.decode('utf-8')
            if kind != b'blob' or mode == b'120000' or unsafe_name(name):
                raise SystemExit('Excluded file found in Git history: ' + name)
            if object_id not in checked:
                if secret_re.search(git('cat-file', 'blob', object_id.decode())):
                    raise SystemExit('Potential credential found in history; not exporting: ' + name)
                checked.add(object_id)
    base = ROOT / 'artifacts'
    base.mkdir(exist_ok=True)
    name = 'douge-developer-handoff-' + head[:7]
    destination = base / name
    destination.mkdir()  # Do not silently replace a prior handoff.
    source = destination / 'source'
    source.mkdir()
    archive = zipfile.ZipFile(io.BytesIO(git('archive', '--format=zip', head)))
    for item in archive.infolist():
        target = (source / item.filename).resolve()
        if source.resolve() not in target.parents or unsafe_name(item.filename):
            raise SystemExit('Unsafe archive member: ' + item.filename)
        if item.is_dir():
            target.mkdir(parents=True, exist_ok=True)
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(archive.read(item.filename))
    expected = set(git('ls-tree', '-r', '--name-only', '-z', head).decode('utf-8').rstrip('\0').split('\0'))
    actual = {p.relative_to(source).as_posix() for p in source.rglob('*') if p.is_file()}
    if actual != expected:
        raise SystemExit('Source snapshot does not match Git HEAD.')
    history_dir = destination / 'git'
    history_dir.mkdir()
    bundle = history_dir / 'douge-history.bundle'
    subprocess.run(['git', 'bundle', 'create', str(bundle), '--all'], cwd=str(ROOT), check=True)
    subprocess.run(['git', 'bundle', 'verify', str(bundle)], cwd=str(ROOT), check=True, capture_output=True)
    verify_out = destination / 'verification'
    verify_out.mkdir()
    for log in verification.iterdir():
        if log.is_file() and log.suffix in {'.txt', '.json'}:
            if secret_re.search(log.read_bytes()):
                raise SystemExit('Potential credential found in verification log: ' + log.name)
            shutil.copyfile(str(log), str(verify_out / log.name))
    start = '''# 豆格开发交接包：先读这里

1. 首先阅读 source/docs/handoff/开发交接说明.md。
2. 完整需求：source/照片转拼豆辅助图_PRD_V1.3.html。
3. 当前设计：source/docs/ui-ios/douge-ios-board.svg 及PNG。
4. 无需Git可直接使用source目录；有Git推荐恢复完整历史：

```sh
git clone git/douge-history.bundle douge-work
cd douge-work/browser-preview
npm ci
npm run dev
```

然后打开 http://localhost:3000/ 。需要Node.js 22.13+及网络下载依赖。测试还需PATH中的Python 3。

注意：AI还没有真实密钥与效果验收；社区是本机草稿；微信原生端已同步素材拼贴、社区草稿与风格选择；真实AI按钮仍禁用。演示色号不能采购，不是1:1实物模板。这个包不是线上可运营版本。

MANIFEST.json记录源码提交及交付范围。verification保存本次验证日志。SHA256SUMS.txt记录除自身外的全部文件校验。

不含：密钥、账号会话、个人作品数据库、node_modules、dist、旧压缩包或机器私有配置。没有逐字聊天记录，交接文档保留了关键需求和开发决策。
'''
    (destination / 'START_HERE.md').write_text(start, encoding='utf-8')
    manifest = {
        'product': '豆格 / 照片转拼豆辅助图',
        'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'source_commit': head,
        'git_commits': len(commits),
        'source_files': len(actual),
        'prd_version': '1.3',
        'software_status': '0.1.0 development preview; not production-ready',
        'history_bundle': 'git/douge-history.bundle',
        'verification': results,
        'not_verified': ['real AI provider calls and image quality', 'browser clicking/dragging/screenshots', 'full WeChat simulator interaction/visual acceptance and real-device permissions', 'production community, billing and moderation'],
        'excluded': ['credentials and sessions', 'browser personal works', 'node_modules and build caches', 'machine-private config', 'raw chat transcript'],
        'source_prd': 'source/照片转拼豆辅助图_PRD_V1.3.md',
        'remote_repository': 'not configured at handoff',
    }
    (destination / 'MANIFEST.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    paths = sorted((p for p in destination.rglob('*') if p.is_file()), key=lambda p:p.as_posix())
    sums = ''.join(sha(p) + '  ' + p.relative_to(destination).as_posix() + '\n' for p in paths)
    (destination / 'SHA256SUMS.txt').write_text(sums, encoding='utf-8')
    zip_path = base / (name + '.zip')
    with zipfile.ZipFile(zip_path, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as out:
        for path in sorted(destination.rglob('*')):
            if path.is_file():
                out.write(path, name + '/' + path.relative_to(destination).as_posix())
    with zipfile.ZipFile(zip_path) as check:
        if check.testzip() is not None:
            raise SystemExit('Archive integrity verification failed.')
        for path in paths:
            zipped = check.read(name + '/' + path.relative_to(destination).as_posix())
            if hashlib.sha256(zipped).hexdigest() != sha(path):
                raise SystemExit('Archive hash mismatch.')
    (base / (name + '.zip.sha256')).write_text(sha(zip_path) + '  ' + zip_path.name + '\n', encoding='utf-8')
    print(json.dumps({'archive': str(zip_path), 'source_commit': head, 'files': len(actual), 'git_commits': len(commits), 'bytes': zip_path.stat().st_size}, ensure_ascii=False))

if __name__ == '__main__':
    main()
