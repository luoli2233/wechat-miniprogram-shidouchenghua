const test=require('node:test');
const assert=require('node:assert/strict');
const sharing=require('../miniprogram/services/share');
const security=require('../miniprogram/services/security');
const model=require('../miniprogram/core/model');
const {palette,board}=require('../miniprogram/core/palette');
security.image=async()=>true;security.text=async()=>true;

test('friend sharing checks image and title before opening the WeChat menu',async()=>{
 const order=[];security.image=async path=>order.push(['image',path]);security.text=async title=>order.push(['text',title]);
 global.wx={canIUse:()=>true,showShareImageMenu:args=>{order.push(['menu',args.path]);args.success({});}};
 await sharing.send('/tmp/work.png',true,'我的作品');
 assert.deepEqual(order,[['image','/tmp/work.png'],['text','我的作品'],['menu','/tmp/work.png']]);
 order.length=0;security.image=async()=>{throw Error('blocked');};
 await assert.rejects(sharing.send('/tmp/work.png',true,'我的作品'),/blocked/);assert.deepEqual(order,[]);
 security.image=async()=>true;security.text=async()=>true;
});

test('friend sharing requires consent, rejects remote files and attaches no private page link',async()=>{
 const calls=[];global.wx={env:{USER_DATA_PATH:'/user'},canIUse:()=>true,showShareImageMenu:args=>{calls.push(args);args.success({});}};
 await assert.rejects(sharing.send('/tmp/work.png',false),/权利/);
 for(const path of ['https://example.com/photo.png','//example.com/p.png','/tmp/../private.png','data:image/png;base64,AA'])await assert.rejects(sharing.send(path,true));
 assert.equal(calls.length,0);
 const status=await sharing.send('http://tmp/work.png',true);
 assert.equal(calls.length,1);assert.equal(calls[0].needShowEntrance,false);assert.equal('entrancePath' in calls[0],false);
 assert.match(status,/无法确认是否送达/);assert.equal('uploadFile' in wx,false);
});
test('cancel and failure do not trigger another share or save the image',async()=>{
 let calls=0;global.wx={showShareImageMenu:args=>{calls++;args.fail({errMsg:'showShareImageMenu:fail cancel'});}};
 assert.match(await sharing.send('/tmp/work.png',true),/取消/);assert.equal(calls,1);
 wx.showShareImageMenu=args=>{calls++;args.fail({errMsg:'showShareImageMenu:fail not available'});};
 await assert.rejects(sharing.send('/tmp/work.png',true),/真|手机微信/);assert.equal(calls,2);
});
test('unsupported WeChat falls back to preview only without requesting album access',async()=>{
 const paths=[];global.wx={canIUse:()=>false,showShareImageMenu:()=>assert.fail('unsupported API called'),previewImage:args=>{paths.push(args.urls);args.success({});},saveImageToPhotosAlbum:()=>assert.fail('unexpected album permission request')};
 assert.match(await sharing.send('/tmp/work.png',true),/长按发送/);assert.deepEqual(paths,[['/tmp/work.png']]);
});
test('work sharing uses edited grid without reading source photo or changing saved project',async()=>{
 const project=model.create({columns:16,rows:16,maxColors:8,cells:Array(256).fill(palette.colors[0].id)},palette,board);
 model.edit(project,0,palette.colors[1].id);const before=JSON.stringify(project);const colors=[];
 const ctx={fillRect(){colors.push(this.fillStyle);},fillText(){}};
 const canvas={getContext:()=>ctx,createImage:()=>assert.fail('original photo must not be read')};
 Object.defineProperty(project,'sourcePath',{get:()=>assert.fail('private source path must not be read'),configurable:true});
 global.wx={canvasToTempFilePath:args=>{assert.equal(args.fileType,'png');assert.equal(args.destWidth,1200);args.success({tempFilePath:'/tmp/final.png'});}};
 assert.equal(await sharing.work(canvas,project),'/tmp/final.png');assert.ok(colors.includes(palette.colors[1].hex));
 Object.defineProperty(project,'sourcePath',{value:JSON.parse(before).sourcePath,writable:true,configurable:true});assert.equal(JSON.stringify(project),before);
});
test('photo share checks dimensions before decoding, exports a bounded PNG and keeps source untouched',async()=>{
 let decoded=0,drawn=0;const canvas={getContext:()=>({clearRect(){},drawImage(){drawn++;}}),createImage(){decoded++;return {width:4000,height:3000,set src(path){assert.equal(path,'/tmp/photo.jpg');this.onload();}};}};
 global.wx={getImageInfo:args=>args.success({type:'jpg',width:9000,height:9000}),canvasToTempFilePath:args=>{assert.equal(args.fileType,'png');assert.equal(args.destWidth,1200);assert.equal(args.destHeight,900);args.success({tempFilePath:'/tmp/normalized.png'});}};
 await assert.rejects(sharing.photo(canvas,{tempFilePath:'/tmp/photo.jpg',size:2000}),/2400万/);assert.equal(decoded,0);
 wx.getImageInfo=args=>args.success({type:'jpg',width:4000,height:3000});
 assert.equal(await sharing.photo(canvas,{tempFilePath:'/tmp/photo.jpg',size:2000}),'/tmp/normalized.png');assert.equal(decoded,1);assert.equal(drawn,1);
 await assert.rejects(sharing.photo(canvas,{tempFilePath:'/tmp/photo.jpg',size:21*1024*1024}),/20MB/);assert.equal(decoded,1);
});
