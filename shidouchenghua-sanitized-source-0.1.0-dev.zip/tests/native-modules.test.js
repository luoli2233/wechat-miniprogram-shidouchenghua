const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const root=path.resolve(__dirname,'../miniprogram');
test('all native pages load using only JavaScript modules without Node JSON resolution',()=>{
 const cache=new Map();let definition;
 function load(file){if(cache.has(file))return cache.get(file).exports;assert.ok(file.startsWith(root+path.sep));const module={exports:{}};cache.set(file,module);
  const requireNative=specifier=>{assert.ok(specifier.startsWith('.'),'Only relative native modules: '+specifier);assert.ok(!specifier.endsWith('.json'),'JSON cannot be used as a native JS module: '+specifier);const target=path.resolve(path.dirname(file),specifier.endsWith('.js')?specifier:specifier+'.js');return load(target);};
  const run=vm.runInNewContext('(function(require,module,exports){'+fs.readFileSync(file,'utf8')+'\n})',{Page:p=>definition=p,Component(){},console,setTimeout,clearTimeout});run(requireNative,module,module.exports);return module.exports;
 }
 const app=JSON.parse(fs.readFileSync(path.join(root,'app.json'),'utf8'));
 for(const page of app.pages){definition=null;load(path.join(root,page+'.js'));assert.ok(definition,page);if(page==='pages/library/index'){assert.equal(typeof definition.addText,'function');assert.equal(typeof definition.generate,'function');}}
});
test('native color modules exactly match their source JSON snapshots',()=>{
 for(const name of ['artkal-s','mard-221'])assert.deepEqual(require('../miniprogram/core/'+name),require('../miniprogram/core/'+name+'.json'));
});
