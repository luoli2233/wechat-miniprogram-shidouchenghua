const test=require('node:test');
const assert=require('node:assert/strict');

function loadPage(saved){
 const values=new Map(saved?[['douge-local-profile-v1',saved]]:[]);let definition;
 global.wx={
  getStorageSync:key=>values.get(key),setStorageSync:(key,value)=>values.set(key,JSON.parse(JSON.stringify(value))),removeStorageSync:key=>values.delete(key),
  showModal:options=>options.success({confirm:true,content:'温柔的信客'}),cloud:null
 };
 global.Page=value=>{definition=value;};
 delete require.cache[require.resolve('../miniprogram/services/auth')];delete require.cache[require.resolve('../miniprogram/pages/account/index')];
 require('../miniprogram/pages/account/index');
 const page={...definition,data:JSON.parse(JSON.stringify(definition.data)),setData(value){Object.assign(this.data,value);}};page.onLoad();return {page,values};
}

test('local profile name restores and can be edited without changing WeChat identity',async()=>{
 const {page,values}=loadPage({version:1,name:'拼豆小匠'});assert.equal(page.data.profileName,'拼豆小匠');assert.equal(page.data.avatarText,'拼');
 await page.rename();assert.equal(page.data.profileName,'温柔的信客');assert.equal(page.data.avatarText,'温');assert.deepEqual(values.get('douge-local-profile-v1'),{version:1,name:'温柔的信客'});assert.equal(page.data.account.loggedIn,false);
 page.onUnload();
});
