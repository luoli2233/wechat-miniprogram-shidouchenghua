const test=require('node:test'),assert=require('node:assert/strict');
const studio=require('../miniprogram/pages/library/studio'),editor=require('../miniprogram/core/creative-editor'),palettes=require('../miniprogram/core/palette-catalog');
const base={id:'a',type:'paint',x:50,y:50,size:100,rotation:0,flip:false,strokes:[]};
function page(layer=base){global.wx={};const p={...studio,data:{layers:editor.layers([layer],[{id:'img'}]),materials:[{id:'img',name:'image'}],layer:editor.layers([layer],[{id:'img'}])[0],selected:'a',busy:false,ready:true,mode:'move',paletteIndex:0,background:'transparent',ink:'#123456',brushWidth:8},stage:{left:0,top:0,width:512,height:512},paletteOptions:palettes.list(),setData(v){Object.assign(this.data,v);},redraw(){},previewPen(){},commit(){return true;}};p.history=new editor.History();p.baseline=p.snapshot();return p;}
const event=(...points)=>({touches:points.map(([x,y])=>({x,y}))});
test('second finger retains selected layer, scales beyond 100 and lifts to drag with one undo step',()=>{
 const p=page();p.touchStart(event([256,256]));p.touchStart(event([256,256],[456,256]));p.touchMove(event([56,256],[456,256]));assert.equal(p.data.layer.size,200);p.touchEnd(event([256,256]));assert.ok(p.gesture);p.touchMove(event([266,256]));p.touchEnd(event());assert.equal(p.history.past.length,1);p.historyStep({currentTarget:{dataset:{action:'undo'}}});assert.equal(p.data.layer.size,100);assert.equal(p.data.layer.x,50);
});
test('image and text scale with buttons and live slider, restore and undo without clipping at 100',()=>{
 for(const layer of [{...base,type:'image',material:'img'},{...base,type:'text',text:'文字',fontSize:80,color:'#123456'}]){const p=page(layer);p.scaleStep({currentTarget:{dataset:{step:10}}});assert.equal(p.data.layer.size,110);const evt=v=>({currentTarget:{dataset:{key:'size'}},detail:{value:v}});p.changing(evt(200));p.changing(evt(300));p.change(evt(300));assert.equal(p.history.past.length,2);assert.equal(editor.layers(JSON.parse(JSON.stringify(p.data.layers)),p.data.materials)[0].size,300);p.historyStep({currentTarget:{dataset:{action:'undo'}}});assert.equal(p.data.layer.size,110);p.toggleLayer({currentTarget:{dataset:{key:'locked'}}});p.scaleStep({currentTarget:{dataset:{step:10}}});assert.equal(p.data.layer.size,110);}
});
test('brush preserves a stroke on second touch without connecting unrelated fingers',()=>{
 const p=page();p.data.mode='draw';p.touchStart(event([200,200]));p.touchMove(event([220,220]));p.touchStart(event([220,220],[400,400]));p.touchMove(event([400,400]));p.touchEnd(event());assert.equal(p.data.layer.strokes.length,1);assert.deepEqual(p.data.layer.strokes[0].points,[[200,200],[220,220]]);assert.equal(p.history.past.length,1);
});
test('quick client-coordinate brush stroke survives asynchronous canvas bounds lookup',()=>{
 const p=page();p.data.mode='draw';let callback;p.createSelectorQuery=()=>({select(){return this;},boundingClientRect(cb){callback=cb;return this;},exec(){}});const e=(x,y)=>({touches:[{clientX:x,clientY:y}]});p.touchStart(e(120,230));p.touchMove(e(140,250));p.touchEnd({touches:[],changedTouches:[{clientX:150,clientY:260}]});callback({left:100,top:200,width:512,height:512});assert.deepEqual(p.data.layer.strokes[0].points,[[20,30],[40,50],[50,60]]);assert.equal(p.history.past.length,1);
});
test('brush activates from an image by creating a paint layer, then reuses it',()=>{
 const p=page({...base,type:'image',material:'img'});p.setMode({currentTarget:{dataset:{mode:'draw'}}});assert.equal(p.data.layer.type,'paint');assert.equal(p.data.mode,'draw');assert.equal(p.data.layers.length,2);p.setMode({currentTarget:{dataset:{mode:'draw'}}});assert.equal(p.data.layers.length,2);
});
