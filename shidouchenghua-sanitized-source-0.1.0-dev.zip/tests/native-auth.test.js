const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const config=require('../miniprogram/cloud-config');
function deferred(){let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b;});return {promise,resolve,reject};}
function setup(call=async()=>({result:{openid:'trusted-owner-123456'}})){
 const keys=new Map();let calls=0;
 global.wx={getStorageSync:key=>keys.get(key),setStorageSync:(key,value)=>keys.set(key,JSON.parse(JSON.stringify(value))),removeStorageSync:key=>keys.delete(key),cloud:{init(){},callFunction:options=>{calls++;assert.equal(options.name,'dougeIdentity');assert.equal(options.config.env,config.env);assert.deepEqual(options.data,{});return call(options);},database:()=>assert.fail('unexpected database access'),uploadFile:()=>assert.fail('unexpected upload')}};
 function load(){delete require.cache[require.resolve('../miniprogram/services/auth')];return require('../miniprogram/services/auth');}
 return {keys,auth:load(),load,calls:()=>calls};
}

test('login needs consent; local cached identity never authenticates and no user content is uploaded',async()=>{
 const s=setup();s.keys.set(s.auth.KEY,{openid:'forged-owner',loggedIn:true});
 assert.equal((await s.auth.restore()).loggedIn,false);assert.equal(s.calls(),0);
 await assert.rejects(s.auth.login(false),e=>e.code==='AUTH_CONSENT');assert.equal(s.calls(),0);
 const state=await s.auth.login(true,true);
 assert.equal(state.loggedIn,true);assert.equal(state.accountLabel,'微信用户 · 123456');assert.equal(state.openid,undefined);
 assert.deepEqual(s.keys.get(s.auth.KEY),{version:1,env:config.env,restore:true});
 assert.equal(JSON.stringify([...s.keys]).includes('trusted-owner'),false);
});

test('concurrent login requests share one identity check and listeners are removable',async()=>{
 const reply=deferred(),s=setup(()=>reply.promise);let events=0;
 const off=s.auth.subscribe(()=>events++);
 const a=s.auth.login(true),b=s.auth.login(true);assert.equal(a,b);
 await Promise.resolve();assert.equal(s.calls(),1);
 reply.resolve({result:{openid:'owner-a'}});await a;
 assert.equal(s.auth.snapshot().loggedIn,true);const before=events;off();s.auth.logout();assert.equal(events,before);
 assert.equal(s.auth.snapshot().loggedIn,false);assert.equal(s.keys.has(s.auth.KEY),false);
});

test('remembered login is verified again on restart and takes the server identity',async()=>{
 let owner='owner-a';const s=setup(async()=>({result:{openid:owner}}));
 await s.auth.login(true,true);owner='owner-b';const restarted=s.load();
 assert.equal(restarted.snapshot().loggedIn,false);await restarted.restore();
 assert.equal(s.calls(),2);assert.equal(restarted.requireIdentity().openid,'owner-b');
 restarted.logout();const guest=s.load();await guest.restore();assert.equal(s.calls(),2);assert.equal(guest.snapshot().loggedIn,false);
});

test('logout cancels a pending login and a late response cannot restore the session',async()=>{
 const reply=deferred(),s=setup(()=>reply.promise),p=s.auth.login(true,true);
 const rejected=assert.rejects(p,e=>e.code==='AUTH_CANCELLED');await Promise.resolve();
 s.auth.logout();reply.resolve({result:{openid:'late-owner'}});await rejected;await Promise.resolve();
 assert.equal(s.auth.snapshot().loggedIn,false);assert.equal(s.keys.has(s.auth.KEY),false);
 assert.throws(()=>s.auth.requireIdentity(),e=>e.code==='AUTH_REQUIRED');
});

test('failed or malformed restored identity stays logged out and clears the restore preference',async()=>{
 for(const result of [null,{openid:''},{openid:{fake:true}}]){
  const s=setup(async()=>({result}));s.keys.set(s.auth.KEY,{version:1,env:config.env,restore:true,openid:'forged'});
  await s.auth.restore();assert.equal(s.auth.snapshot().loggedIn,false);assert.equal(s.keys.has(s.auth.KEY),false);
 }
 const s=setup(async()=>{throw Error('network unavailable PRIVATE_INTERNAL_DETAILS');});
 s.keys.set(s.auth.KEY,{version:1,env:config.env,restore:true});await s.auth.restore();
 assert.equal(s.auth.snapshot().loggedIn,false);assert.equal(s.auth.snapshot().error.includes('PRIVATE_INTERNAL_DETAILS'),false);
});

test('session cannot survive an environment change during or after login',async()=>{
 const oldEnv=config.env;
 try{
  const reply=deferred(),s=setup(()=>reply.promise),p=s.auth.login(true);await Promise.resolve();
  config.env='changed-env';reply.resolve({result:{openid:'wrong-environment'}});
  await assert.rejects(p,e=>e.code==='AUTH_CANCELLED');assert.equal(s.auth.snapshot().busy,false);assert.equal(s.auth.snapshot().loggedIn,false);
  config.env=oldEnv;const good=setup();await good.auth.login(true);const ticket=good.auth.requireIdentity();config.env='changed-env';
  assert.equal(good.auth.snapshot().loggedIn,false);assert.throws(()=>good.auth.assertCurrent(ticket),e=>e.code==='AUTH_REQUIRED');
 }finally{config.env=oldEnv;}
});

test('identity timeout releases busy state and ignores an eventual server response',async()=>{
 const reply=deferred(),timers=new Set(),output={exports:{}},keys=new Map();
 vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../miniprogram/services/auth.js'),'utf8'),{
  module:output,require:name=>name==='../cloud-config'?config:{initialize:()=>true},
  wx:{cloud:{callFunction:()=>reply.promise},getStorageSync:key=>keys.get(key),setStorageSync:(key,v)=>keys.set(key,v),removeStorageSync:key=>keys.delete(key)},
  setTimeout:fn=>{timers.add(fn);return fn;},clearTimeout:fn=>timers.delete(fn)
 });
 const auth=output.exports,p=auth.login(true),rejected=assert.rejects(p,e=>e.code==='AUTH_TIMEOUT');await Promise.resolve();
 [...timers][0]();await rejected;reply.resolve({result:{openid:'too-late'}});await Promise.resolve();
 assert.equal(auth.snapshot().busy,false);assert.equal(auth.snapshot().loggedIn,false);assert.equal(keys.size,0);
});

test('storage failures do not fake a remembered login and logout still clears memory',async()=>{
 const s=setup();wx.setStorageSync=()=>{throw Error('disk full');};
 const state=await s.auth.login(true,true);assert.equal(state.loggedIn,true);assert.equal(state.remembered,false);
 wx.removeStorageSync=()=>{throw Error('disk full');};const out=s.auth.logout();
 assert.equal(out.loggedIn,false);assert.match(out.error,/未能清除/);
 assert.throws(()=>s.auth.requireIdentity(),e=>e.code==='AUTH_REQUIRED');
});

test('backup requires app login and logout during a query prevents later file access',async()=>{
 const saved={...config},reply=deferred(),s=setup();
 try{
  config.enabled=true;config.privacyReady=true;
  delete require.cache[require.resolve('../miniprogram/services/cloud-backup')];const backup=require('../miniprogram/services/cloud-backup');
  await assert.rejects(backup.list(true),e=>e.code==='AUTH_REQUIRED');
  await s.auth.login(true);wx.cloud.database=()=>({collection:()=>({where:()=>({get:()=>reply.promise})})});
  wx.cloud.downloadFile=()=>assert.fail('download after logout');
  const p=backup.download('backup-example',true);s.auth.logout();
  reply.resolve({data:[{_id:'backup-example',_openid:'trusted-owner-123456',fileID:'cloud://'+config.env+'.bucket/backups/trusted-owner-123456/backup-example.douge',status:'ready'}]});
  await assert.rejects(p,e=>e.code==='AUTH_REQUIRED');
 }finally{Object.assign(config,saved);}
});
