const test=require('node:test');
const assert=require('node:assert/strict');
const layer={id:'one',material:'flower',x:50,y:50,size:40,rotation:90,flip:false};
test('collage rejects oversized, duplicate, unknown and non-finite layer inputs',async()=>{
 const {validateCollage}=await import('../browser-preview/lib/creative.js');
 assert.deepEqual(validateCollage({version:1,layers:[layer]}).layers,[layer]);
 for(const layers of [Array.from({length:13},(_,i)=>({...layer,id:String(i)})),[layer,layer],[{...layer,x:NaN}],[{...layer,material:'https://untrusted/image.svg'}],[{...layer,size:81}],[{...layer,rotation:45}],[null]])assert.throws(()=>validateCollage({version:1,layers}));
});
test('share draft requires consent and never copies originals or project data',async()=>{
 const {shareDraft}=await import('../browser-preview/lib/creative.js');
 const data={title:'  小花  ',description:'我的作品',image:'data:image/png;base64,AAAA',consent:true,sourceData:'private original',project:{private:true},status:'published'};
 const result=shareDraft(data);
 assert.equal(result.title,'小花');assert.equal(result.status,'local-draft');assert.equal('sourceData' in result,false);assert.equal('project' in result,false);
 assert.throws(()=>shareDraft({...data,consent:false}));assert.throws(()=>shareDraft({...data,image:'https://external/photo.jpg'}));assert.throws(()=>shareDraft({...data,image:'data:image/svg+xml;base64,AAAA'}));assert.throws(()=>shareDraft({...data,title:'  '}));assert.throws(()=>shareDraft({...data,description:'x'.repeat(301)}));
});
