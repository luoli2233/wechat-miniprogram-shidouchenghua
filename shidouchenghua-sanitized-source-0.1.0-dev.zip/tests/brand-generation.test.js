const test=require('node:test'),assert=require('node:assert/strict');
const catalog=require('../miniprogram/core/palette-catalog'),model=require('../miniprogram/core/model');
const bench=require('../miniprogram/services/workbench'),ui=require('../miniprogram/services/ui');
const {board}=require('../miniprogram/core/palette');
let definition;global.Page=p=>definition=p;require('../miniprogram/pages/editor/index');
function page(){const p={...definition,data:{...definition.data},setData(v,cb){Object.assign(this.data,v);if(cb)cb();}};p.onLoad({});bench.preferences=()=>({palette:catalog.list()[0],board});p.setupPalettes();p.input={width:16,height:16,getContext:()=>({getImageData:()=>({data:new Uint8ClampedArray(1024).fill(255)})})};p.readSource=async()=>{};p.draw=()=>{};p.save=()=>true;ui.later=async()=>{};ui.error=e=>{throw e;};return p;}
test('MARD reference is explicitly nonofficial and quantization uses selected codes, not renamed Artkal cells',async()=>{
 const p=page();p.choosePalette({detail:{value:1}});ui.modal=async text=>{assert.match(text,/MARD/);assert.match(text,/非官方标准/);assert.match(text,/实际豆子/);return true;};
 await p.generate();const m=catalog.list()[1];assert.equal(p.project.palette.id,m.id);assert.ok(p.project.cells.every(c=>m.colors.some(x=>x.id===c)));assert.equal(catalog.official(m),false);assert.equal(catalog.reference(m),true);assert.equal(m.colors.length,221);assert.equal(new Set(m.colors.map(c=>c.id)).size,221);assert.match(model.materialText(p.project),/MARD/);assert.doesNotMatch(model.materialText(p.project),/非真实品牌/);
 const changed=structuredClone(m);changed.colors[0].hex='#000000';assert.equal(catalog.reference(changed),false);
});
test('cancel confirmation does not read pixels, save or replace existing work',async()=>{
 const p=page(),original=model.create({columns:16,rows:16,maxColors:8,cells:Array(256).fill('S01')},catalog.list()[0],board);p.project=original;p.choosePalette({detail:{value:1}});let writes=0;p.save=()=>{writes++;return true;};p.readSource=()=>{throw Error('must not run');};ui.modal=async()=>false;await p.generate(false);assert.equal(p.project,original);assert.equal(writes,0);assert.equal(p.confirming,false);
});
test('regeneration preserves old palette snapshot and editor colors change only after conversion',async()=>{
 const p=page();ui.modal=async()=>true;await p.generate();const old=p.project,before=JSON.stringify(old);p.choosePalette({detail:{value:1}});assert.equal(p.project,old);await p.generate();assert.notEqual(p.project.id,old.id);assert.equal(JSON.stringify(old),before);assert.equal(p.project.palette.brand,'MARD');
});
test('pending confirmation blocks duplicate generation and navigation away prevents late generation',async()=>{
 const p=page();let answer,calls=0;ui.modal=()=>{calls++;return new Promise(r=>answer=r);};const run=p.generate();await p.generate();assert.equal(calls,1);p.choosePalette({detail:{value:1}});assert.equal(p.generationPalette.brand,'Artkal');p.token++;answer(true);await run;assert.equal(p.project,undefined);
});
test('new photo, example and creation enter selection without automatic generation',async()=>{
 for(const kind of ['photo','example','collage']){const p=page();let generated=0;const ctx={fillRect(){},drawImage(){}};ui.node=async()=>({node:{width:16,height:16,getContext:()=>ctx}});global.wx={getWindowInfo:()=>({windowWidth:400})};global.getApp=()=>({globalData:{pendingSource:{kind,path:'/tmp/image.png',palette:kind==='collage'?catalog.list()[1]:undefined}}});if(kind==='example'){require('../miniprogram/core/examples').draw=()=>{};ui.temp=async()=>'/tmp/example.png';global.getApp=()=>({globalData:{pendingSource:{example:'cat'}}});}p.generate=()=>{generated++;};await p.onReady();assert.equal(generated,0);assert.equal(p.data.settingsOpen,true);assert.match(p.data.status,/请选择品牌/);assert.equal(p.data.ready,false);if(kind==='collage')assert.equal(p.generationPalette.brand,'MARD');}
});
test('old snapshot and custom profiles remain selectable without being relabeled as built-in',()=>{
 const p=page(),custom={...catalog.list()[1],id:'custom',brand:'自备',colors:catalog.list()[1].colors.slice(0,2)};bench.preferences=()=>({palette:custom,board});p.setupPalettes(custom);assert.equal(p.generationPalette.brand,'自备');assert.match(p.data.paletteNote,/自备色表/);const old=structuredClone(catalog.list()[1]);old.version='older';old.colors[0].hex='#000001';p.setupPalettes(old);assert.deepEqual(p.generationPalette,old);assert.equal(catalog.reference(p.generationPalette),false);
});
