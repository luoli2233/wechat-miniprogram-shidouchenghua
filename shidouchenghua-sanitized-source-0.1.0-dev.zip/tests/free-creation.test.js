const test=require('node:test'),assert=require('node:assert/strict');
const editor=require('../miniprogram/core/creative-editor');
const core=require('../miniprogram/core/workbench');
const palettes=require('../miniprogram/core/palette-catalog');
const artkal=require('../miniprogram/core/artkal-s.json');
const model=require('../miniprogram/core/model'),quant=require('../miniprogram/core/quantize');
const studio=require('../miniprogram/pages/library/studio');
const ui=require('../miniprogram/services/ui');
const common={id:'layer-a',x:50,y:50,size:100,rotation:0,flip:false};
const paint={...common,type:'paint',strokes:[{color:'#ff0000',width:10,erase:false,points:[[20,20],[100,100]]},{color:'#000000',width:5,erase:true,points:[[40,40]]}]};
test('editable text, shape and pen survive workbench serialization and old image layers migrate',()=>{
 const state=core.empty();state.collages=[{id:'collage-new',name:'创作',updatedAt:1,background:'white',paletteId:artkal.id,layers:[paint,{...common,id:'t',type:'text',text:'豆格\n姓名',fontSize:80,color:'#123456'},{...common,id:'s',type:'shape',shape:'circle',color:'#abcdef',fill:false,lineWidth:8},{...common,id:'i',material:'flower'}]}];state.activeCollage='collage-new';
 const first=core.validate(state,[{id:'flower'}]),roundtrip=core.validate(JSON.parse(JSON.stringify(first)),[{id:'flower'}]);assert.deepEqual(first,roundtrip);assert.equal(roundtrip.collages[0].paletteId,artkal.id);assert.equal(roundtrip.collages[0].layers[3].type,'image');assert.deepEqual(roundtrip.collages[0].layers[0].strokes,paint.strokes);
});
test('untrusted brush geometry and budgets reject before any saved document can be replaced',()=>{
 for(const bad of [{...paint,strokes:[{...paint.strokes[0],points:[[NaN,0]]}]},{...paint,strokes:[{...paint.strokes[0],erase:'yes'}]},{...paint,opacity:Infinity},{...paint,type:'script'}, {...paint,strokes:Array(121).fill(paint.strokes[0])}])assert.throws(()=>editor.layers([bad]));
 assert.throws(()=>editor.layers([{...paint,strokes:Array(4).fill({...paint.strokes[0],points:Array(1600).fill([0,0])})}]),/笔迹/);
 assert.deepEqual(paint.strokes[0].points,[[20,20],[100,100]]);
});
test('history restores independent layer geometry, erase strokes and brand choice and clears redo on new edit',()=>{
 const a={layers:editor.layers([paint]),paletteId:'demo-v1'},b=JSON.parse(JSON.stringify(a));b.layers[0].rotation=47;b.paletteId=artkal.id;const h=new editor.History();h.push(a,b);a.layers[0].strokes[0].points[0][0]=999;const prev=h.undo(b);assert.equal(prev.layers[0].strokes[0].points[0][0],20);assert.deepEqual(h.redo(prev),b);h.undo(b);h.push(prev,{...prev,paletteId:'custom'});assert.equal(h.redo(prev),null);
});
test('inverse transforms preserve pen positions for translated rotated flipped layers and hidden/locked layers cannot be hit',()=>{
 const l={...common,x:25,y:75,size:50,rotation:90,flip:true};assert.deepEqual(editor.localPoint(l,128,384),[256,256]);const p=editor.localPoint(l,128,334);assert.ok(Math.abs(p[0]-356)<1e-6);assert.equal(editor.hit([{...l,hidden:true}],128,384),undefined);assert.equal(editor.hit([{...l,locked:true}],128,384),undefined);
});
test('overlapping layers are returned from top to bottom and image hit boxes respect aspect ratio',()=>{
 const bottom={...common,id:'bottom',type:'shape',shape:'rect',color:'#ffffff',fill:true,lineWidth:3},top={...common,id:'top',type:'image',material:'wide'};
 assert.deepEqual(editor.hits([bottom,top],256,256,{wide:{width:400,height:100}}).map(l=>l.id),['top','bottom']);
 assert.equal(editor.hit([top],256,100,{wide:{width:400,height:100}}),undefined);assert.equal(editor.hit([top],256,220,{wide:{width:400,height:100}}).id,'top');
});
test('official RGB subset is complete for its documented scope, cannot certify modified data and quantizes only to that brand',async()=>{
 assert.equal(artkal.colors.length,173);assert.equal(new Set(artkal.colors.map(c=>c.id)).size,173);assert.equal(artkal.verified,false);assert.equal(artkal.colors.find(c=>c.id==='S51').hex,'#fff8db');assert.ok(['S41','S42','S63'].every(id=>!artkal.colors.some(c=>c.id===id)));
 const changed=JSON.parse(JSON.stringify(artkal));changed.colors[0].hex='#000001';assert.equal(palettes.official(changed),false);
 const pixels=new Uint8ClampedArray(16*16*4).fill(255);const result=await quant.convertAsync(pixels,16,16,16,8,artkal);assert.ok(result.cells.every(c=>c==='S01'));const project=model.create(result,artkal,require('../miniprogram/core/palette').board);assert.match(model.materialText(project),/品牌材料参考清单/);assert.match(model.materialText(project),/色差/);
});
function page(){const p={...studio,data:{layers:editor.layers([paint]),materials:[],selected:'layer-a',layer:editor.layers([paint])[0],background:'transparent',paletteIndex:0,mode:'draw',ink:'#123456',brushWidth:8,busy:false,ready:true},paletteOptions:palettes.list(),setData(v){Object.assign(this.data,v);},redraw(){},commit(){this.saved=this.snapshot();return true;}};p.history=new editor.History();p.baseline=p.snapshot();return p;}
test('locked layers cannot be edited or deleted; unlock, edit, undo and redo preserve exact strokes',()=>{
 const p=page();p.toggleLayer({currentTarget:{dataset:{key:'locked'}}});const locked=p.snapshot();p.patch({x:12});p.remove();assert.deepEqual(p.snapshot(),locked);p.toggleLayer({currentTarget:{dataset:{key:'locked'}}});p.patch({x:30});assert.equal(p.data.layer.x,30);p.historyStep({currentTarget:{dataset:{action:'undo'}}});assert.equal(p.data.layer.x,50);p.historyStep({currentTarget:{dataset:{action:'redo'}}});assert.equal(p.data.layer.x,30);assert.deepEqual(p.data.layer.strokes,paint.strokes);
});
test('a selected image material can be deleted directly from the canvas and restored with undo',()=>{
 const p=page(),image={...common,type:'image',material:'flower'};p.data.materials=[{id:'flower',name:'小花',src:'/tmp/flower.png'}];p.sync([image],'layer-a');p.baseline=p.snapshot();p.remove();assert.equal(p.data.layers.length,0);p.historyStep({currentTarget:{dataset:{action:'undo'}}});assert.equal(p.data.layers.length,1);assert.equal(p.data.layers[0].material,'flower');
});
test('layer ordering supports step, top, bottom and exact PS-like positions',()=>{
 const p=page(),layers=['a','b','c'].map((id,i)=>({...common,id,type:'shape',shape:'rect',color:'#ffffff',fill:true,lineWidth:3,x:40+i*5}));p.sync(layers,'b');p.baseline=p.snapshot();
 p.reorder({currentTarget:{dataset:{action:'top'}}});assert.deepEqual(p.data.layers.map(l=>l.id),['a','c','b']);
 p.reorder({currentTarget:{dataset:{action:'bottom'}}});assert.deepEqual(p.data.layers.map(l=>l.id),['b','a','c']);
 p.setLayerPosition({detail:{value:1}});assert.deepEqual(p.data.layers.map(l=>l.id),['a','b','c']);assert.deepEqual(p.data.layerRows.map(l=>l.id),['c','b','a']);
});
test('canvas-local touch points drag image layers and a cancelled gesture rolls back without changing history',()=>{
 const p=page();p.data.mode='move';p.sync([{...common,type:'shape',shape:'rect',color:'#ffffff',fill:true,lineWidth:3}],'layer-a');p.baseline=p.snapshot();p.createSelectorQuery=()=>({select(){return this;},boundingClientRect(cb){this.cb=cb;return this;},exec(){this.cb({left:0,top:0,width:512,height:512});}});
 p.touchStart({touches:[{x:256,y:256}]});p.touchMove({touches:[{x:300,y:256}]});assert.ok(p.data.layer.x>50);p.touchEnd();assert.equal(p.history.past.length,1);const saved=p.snapshot();p.touchStart({touches:[{x:300,y:256}]});p.touchMove({touches:[{x:330,y:256}]});p.touchCancel();assert.deepEqual(p.snapshot(),saved);assert.equal(p.history.past.length,1);
});
test('creation passes selected palette to the central pre-generation confirmation page',async()=>{
 const p=page();let navigations=0;const app={globalData:{}};global.getApp=()=>app;global.wx={showModal:o=>o.success({confirm:false}),navigateTo:o=>{navigations++;o.success({});}};p.image=async()=>'/tmp/art.png';await p.generate();assert.equal(navigations,1);assert.equal(app.globalData.pendingSource.palette.id,artkal.id);assert.equal(p.data.busy,false);
});

test('completed creation entry blocks unusable canvases and saves before rendering the pattern source',async()=>{
 const originalError=ui.error,errors=[];ui.error=e=>errors.push(e.message);let navigations=0;
 try{
  const p=page(),app={globalData:{}};global.getApp=()=>app;global.wx={navigateTo:o=>{navigations++;o.success({});}};
  p.data.layers=p.data.layers.map(layer=>({...layer,hidden:true}));await p.generate();assert.equal(navigations,0);assert.match(errors.pop(),/显示至少一个/);
  p.data.layers=editor.layers([paint]);p.data.renderError=true;await p.generate();assert.equal(navigations,0);assert.match(errors.pop(),/渲染失败/);
  p.data.renderError=false;p.commit=()=>{p.savedBeforeRender=true;return true;};p.image=async()=>{assert.equal(p.savedBeforeRender,true);return '/tmp/completed-art.png';};await p.generate();
  assert.equal(navigations,1);assert.equal(app.globalData.pendingSource.path,'/tmp/completed-art.png');assert.equal(app.globalData.pendingSource.kind,'collage');
 }finally{ui.error=originalError;}
});


test('a saved palette snapshot survives external color profile replacement without claiming physical verification',()=>{
 const state=core.empty();state.collages=[{id:'collage-palette',name:'旧配色',updatedAt:1,layers:[],paletteSnapshot:JSON.parse(JSON.stringify(artkal)),paletteId:artkal.id}];state.activeCollage='collage-palette';state.collages[0].paletteSnapshot.verified=true;
 const restored=core.validate(state);assert.equal(restored.collages[0].paletteSnapshot.verified,false);assert.equal(palettes.official(restored.collages[0].paletteSnapshot),true);restored.profile={brand:'另一个品牌',series:'系列',version:2,colors:[{id:'a',name:'a',hex:'#000000'},{id:'b',name:'b',hex:'#ffffff'}]};assert.deepEqual(core.validate(restored).collages[0].paletteSnapshot.colors,artkal.colors);
});

test('quick brush tap records a dot without an asynchronous selector and each stroke is one undo step',()=>{
 const p=page();p.stage={width:512,height:512,left:0,top:0};p.previewPen=()=>{};p.createSelectorQuery=()=>assert.fail('local coordinates should not need an async query');
 p.touchStart({touches:[{x:180,y:200}]});p.touchEnd();assert.equal(p.data.layer.strokes.length,3);assert.deepEqual(p.data.layer.strokes[2].points,[[180,200]]);assert.equal(p.history.past.length,1);p.historyStep({currentTarget:{dataset:{action:'undo'}}});assert.equal(p.data.layer.strokes.length,2);
});
