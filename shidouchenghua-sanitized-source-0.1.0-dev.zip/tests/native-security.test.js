const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');

function cloudFunction(options={}){
 const deleted=[],calls=[];
 const cloud={DYNAMIC_CURRENT_ENV:'current-env',init:value=>assert.equal(value.env,'current-env'),getWXContext:()=>({OPENID:'trusted-owner'}),
  openapi:{security:{msgSecCheck:async value=>{calls.push(['text',value]);if(options.error)throw options.error;return options.textResponse;},imgSecCheck:async value=>{calls.push(['image',value]);if(options.error)throw options.error;return options.imageResponse;}}},
  downloadFile:async()=>({fileContent:options.file||Buffer.from([0xff,0xd8,0xff])}),deleteFile:async value=>deleted.push(value.fileList[0])};
 const output={exports:{}},sandbox={module:output,exports:output.exports,require:name=>{assert.equal(name,'wx-server-sdk');return cloud;},console:{error:(...args)=>calls.push(['log',...args])},Buffer};
 vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../cloudfunctions/dougeSecurity/index.js'),'utf8'),sandbox);
 return {main:output.exports.main,calls,deleted};
}
const plain=value=>JSON.parse(JSON.stringify(value));

test('security cloud function accepts safe text and image with bounded content',async()=>{
 const text=cloudFunction({textResponse:{errCode:0,result:{suggest:'pass'}}});assert.deepEqual(plain(await text.main({action:'text',content:'拼豆作品'})),{pass:true});
 assert.equal(text.calls[0][0],'text');assert.deepEqual(plain(text.calls[0][1]),{content:'拼豆作品',version:2,scene:4,openid:'trusted-owner'});
 const image=cloudFunction({file:Buffer.from([0x89,0x50,0x4e,0x47])}),id='cloud://env.bucket/security-check/example.png';
 assert.deepEqual(plain(await image.main({action:'image',fileID:id})),{pass:true});
 assert.equal(image.calls[0][1].media.contentType,'image/png');assert.equal(image.deleted[0],id);
});

test('security cloud function separates risky content, permission delay and service errors',async()=>{
 for(const [error,expected] of [[{errCode:87014},{pass:false,risky:true,reason:'content_rejected'}],[{errCode:-604101},{pass:false,risky:false,reason:'permission_not_ready'}],[{errCode:48001},{pass:false,risky:false,reason:'account_permission'}],[Error('upstream detail'),{pass:false,risky:false,reason:'service_error'}]]){
  const fn=cloudFunction({error});assert.deepEqual(plain(await fn.main({action:'text',content:'测试'})),expected);
 }
 for(const suggest of ['risky','review']){
  const fn=cloudFunction({textResponse:{errCode:0,result:{suggest}}});
  assert.deepEqual(plain(await fn.main({action:'text',content:'测试'})),{pass:false,risky:true,reason:'content_rejected'});
 }
});

test('security cloud function rejects malformed requests without calling OpenAPI',async()=>{
 for(const event of [{},{action:'text',content:''},{action:'image',fileID:'https://example.com/a.jpg'},{action:'image',fileID:'cloud://env.bucket/other/a.jpg'}]){
  const fn=cloudFunction();assert.deepEqual(plain(await fn.main(event)),{pass:false});assert.equal(fn.calls.length,0);
 }
});

test('client converts safe diagnostic reasons to useful messages without leaking upstream errors',async()=>{
 const config=require('../miniprogram/cloud-config'),runtime=require('../miniprogram/services/cloud');
 const cases=[['permission_not_ready',/10分钟/],['account_permission',/公众平台配置/],['service_error',/服务暂时异常/]];
 for(const [reason,pattern] of cases){
  global.wx={cloud:{init(){},callFunction:async()=>({result:{pass:false,risky:false,reason}})}};
  assert.equal(runtime.initialize(),true);
  delete require.cache[require.resolve('../miniprogram/services/security')];
  await assert.rejects(require('../miniprogram/services/security').text('作品'),pattern);
 }
 global.wx={cloud:{init(){},callFunction:async()=>({result:{pass:false,risky:false,reason:'unexpected',detail:'SECRET'}})}};
 delete require.cache[require.resolve('../miniprogram/services/security')];
 await assert.rejects(require('../miniprogram/services/security').text('作品'),error=>/稍后重试/.test(error.message)&&!error.message.includes('SECRET'));
 assert.equal(config.env,'your-cloud-env-id');
});

test('private creation stays local while every friend share keeps the security gate',()=>{
 const read=file=>fs.readFileSync(path.join(__dirname,'..',file),'utf8');
 assert.doesNotMatch(read('miniprogram/pages/home/index.js'),/services\/security|security\.image/);
 assert.doesNotMatch(read('miniprogram/pages/library/index.js'),/services\/security|security\.(image|text)/);
 const share=read('miniprogram/services/share.js');
 assert.match(share,/await security\.image\(path\)/);
 assert.match(share,/await security\.text\(title\)/);
 assert.ok(share.indexOf('await security.image(path)')<share.indexOf('showShareImageMenu'));
 const sharePage=read('miniprogram/pages/share/index.js');
 assert.ok(sharePage.indexOf('await sharing.validate(this.data.image,this.data.title)')<sharePage.indexOf("saveImageToPhotosAlbum"));
 const exportPage=read('miniprogram/pages/export/index.js');
 assert.ok(exportPage.indexOf('await security.image(files[i].path)')<exportPage.indexOf('saveImageToPhotosAlbum'));
 assert.ok(exportPage.indexOf("await security.text(this.data.name+' · '+files[i].name)")<exportPage.indexOf('saveImageToPhotosAlbum'));
 const workbench=read('miniprogram/pages/workbench/index.js');
 assert.ok(workbench.indexOf('await backup.audit(path')<workbench.indexOf("await ui.call('shareFileMessage'"));
});
