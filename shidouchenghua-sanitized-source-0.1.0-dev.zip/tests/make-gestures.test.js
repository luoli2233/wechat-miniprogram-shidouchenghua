const test=require('node:test');
const assert=require('node:assert/strict');

function page(){
 let definition;global.Page=value=>{definition=value;};delete require.cache[require.resolve('../miniprogram/pages/make/index')];require('../miniprogram/pages/make/index');
 const p={...definition,data:{...definition.data,zoom:1,maxZoom:5},project:{columns:4,rows:4},origin:28,cell:20,panX:40,panY:20,completed:new Set(),setData(value,done){Object.assign(this.data,value);if(done)done();},draw(){this.draws=(this.draws||0)+1;},indices(){return Array.from({length:16},(_,i)=>i);},mark(indices,complete){this.marked={indices,complete};}};return p;
}
const event=(...points)=>({touches:points.map(([x,y])=>({x,y}))});

test('making canvas supports drag and pinch without accidentally marking a bead',()=>{
 const p=page();p.touchStart(event([100,100]));p.touchMove(event([50,70]));assert.equal(p.panX,90);assert.equal(p.panY,50);p.touchEnd(event());assert.equal(p.marked,undefined);
 p.panX=40;p.panY=20;p.touchStart(event([100,100],[200,100]));p.applyZoom=zoom=>{p.pinchZoom=zoom;};p.touchMove(event([50,100],[250,100]));assert.equal(p.pinchZoom,2);p.touchEnd(event());assert.equal(p.marked,undefined);
});

test('tap coordinates include the current pan offset when marking progress',()=>{
 const p=page();p.touchStart(event([18,18]));p.touchEnd(event());assert.deepEqual(p.marked,{indices:[1],complete:true});
});
