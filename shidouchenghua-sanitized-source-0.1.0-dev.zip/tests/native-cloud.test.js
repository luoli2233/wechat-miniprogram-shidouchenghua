const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const config=require('../miniprogram/cloud-config');

function startApp(api){
 const runtimePath=require.resolve('../miniprogram/services/cloud');
 delete require.cache[runtimePath];
 const runtime=require(runtimePath);
 global.wx=api;
 let app,recovered=0,privacyRegistered=0;
 api.onNeedPrivacyAuthorization=()=>privacyRegistered++;
 vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../miniprogram/app.js'),'utf8'),{
  wx:api,App:value=>{app=value;},
  require:name=>{
   if(name==='./services/cloud')return runtime;
   if(name==='./services/auth')return {restore:()=>Promise.resolve()};
   if(name==='./services/transaction')return {recover:()=>recovered++};
   throw Error('Unexpected dependency: '+name);
  }
 });
 app.onLaunch();
 return {app,runtime,recovered,privacyRegistered};
}

test('cloud startup initializes without enabling backups or transferring user content',async()=>{
 let initialized=0;
 const {app,runtime,recovered,privacyRegistered}=startApp({cloud:{
  init:options=>{initialized++;assert.equal(options.env,config.env);assert.equal(options.traceUser,false);},
  callFunction:()=>assert.fail('startup must not request identity'),
  database:()=>assert.fail('startup must not access the database'),
  uploadFile:()=>assert.fail('startup must not upload files')
 }});
 assert.equal(app.globalData.cloudReady,true);
 assert.equal(recovered,1);assert.equal(privacyRegistered,1);
 assert.equal(runtime.initialize(),true);assert.equal(initialized,1);
 const backup=require('../miniprogram/services/cloud-backup');
 assert.equal(backup.available(),false);
 await assert.rejects(backup.list(true),/未配置/);
});

test('unsupported or failed cloud startup preserves local recovery and can retry',()=>{
 for(const api of [{},{cloud:{init(){throw Error('SDK unavailable');}}}]){
  const state=startApp(api);
  assert.equal(state.app.globalData.cloudReady,false);
  assert.equal(state.recovered,1);assert.equal(state.privacyRegistered,1);
  global.wx.cloud={init(){}};
  assert.equal(state.runtime.initialize(),true);
 }
 const saved=config.env;
 try{config.env='';const state=startApp({cloud:{init:()=>assert.fail('must not choose a default environment')}});assert.equal(state.app.globalData.cloudReady,false);assert.equal(state.recovered,1);}
 finally{config.env=saved;}
});

test('identity function rejects forged input and uses only the WeChat server context',async()=>{
 let context={};const output={};
 vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../cloudfunctions/dougeIdentity/index.js'),'utf8'),{
  exports:output,require:name=>{
   assert.equal(name,'wx-server-sdk');
   return {DYNAMIC_CURRENT_ENV:'current-env',init:options=>assert.equal(options.env,'current-env'),getWXContext:()=>context};
  }
 });
 await assert.rejects(output.main({openid:'forged-user',OPENID:'forged-user'}),/WECHAT_IDENTITY_REQUIRED/);
 context={OPENID:'trusted-user'};
 const result=await output.main({openid:'forged-user'});
 assert.equal(result.openid,'trusted-user');assert.deepEqual(Object.keys(result),['openid']);
});
