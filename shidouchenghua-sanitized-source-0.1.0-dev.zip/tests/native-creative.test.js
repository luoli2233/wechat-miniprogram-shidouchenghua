const test=require('node:test');
const assert=require('node:assert/strict');
const creative=require('../miniprogram/services/creative');
function setup(){
 const files=new Map([['/tmp/photo.png',Buffer.from('normalized-png')]]),keys=new Map();let fail=false;
 const fs={accessSync:()=>{},mkdirSync:()=>{},statSync:p=>{if(!files.has(p))throw Error('missing');return {size:files.get(p).length};},readdirSync:p=>[...files.keys()].filter(k=>k.startsWith(p+'/')).map(k=>k.slice(p.length+1)),copyFileSync:(a,b)=>{if(!files.has(a))throw Error('missing');files.set(b,files.get(a));},unlinkSync:p=>files.delete(p)};
 global.wx={env:{USER_DATA_PATH:'/user'},getFileSystemManager:()=>fs,getStorageSync:k=>keys.get(k),setStorageSync:(k,v)=>{if(fail)throw Error('quota');keys.set(k,JSON.parse(JSON.stringify(v)));}};
 return {files,keys,fail:()=>{fail=true;},recover:()=>{fail=false;}};
}
function post(extra={}){return {title:'我的小花',description:'手作记录',image:'/tmp/photo.png',consent:true,...extra};}
const layer={id:'a',material:'flower',x:50,y:50,size:40,rotation:90,flip:true};
test('native collage restores transforms and rejects corrupt or oversized drafts before overwriting',()=>{
 setup();creative.saveCollage([layer]);const saved=creative.loadCollage();assert.deepEqual(saved,{version:1,layers:[layer]});
 for(const bad of [[layer,layer],[{...layer,size:Infinity}],[{...layer,material:'unknown'}],Array.from({length:13},(_,i)=>({...layer,id:String(i)}))])assert.throws(()=>creative.saveCollage(bad));
 assert.deepEqual(creative.loadCollage(),saved);
});
test('native sharing requires rights, rejects remote sources, and whitelists metadata',()=>{
 const env=setup();assert.throws(()=>creative.savePost(post({consent:false})));assert.throws(()=>creative.savePost(post({image:'https://example.invalid/photo.png'})));
 const saved=creative.savePost(post({sourcePath:'/private/original.jpg',cells:['secret'],aiAssisted:true}));
 assert.equal(saved.status,'local-draft');assert.equal(saved.aiAssisted,true);assert.equal('sourcePath' in saved,false);assert.equal('cells' in saved,false);
 assert.ok(env.files.has(saved.image));assert.ok(env.files.has('/tmp/photo.png'));assert.deepEqual(creative.posts(),[saved]);
});
test('native share index failure rolls back new copy and preserves all existing images',()=>{
 const env=setup();const old=creative.savePost(post());const before=[...env.files.keys()];env.fail();assert.throws(()=>creative.savePost(post({title:'第二幅'})));env.recover();
 assert.deepEqual([...env.files.keys()],before);assert.deepEqual(creative.posts(),[old]);
});
test('native share deletion commits index first and only removes its independent copy',()=>{
 const env=setup();const saved=creative.savePost(post());env.fail();assert.throws(()=>creative.removePost(saved.id));env.recover();assert.ok(env.files.has(saved.image));assert.equal(creative.posts().length,1);
 creative.removePost(saved.id);assert.equal(env.files.has(saved.image),false);assert.ok(env.files.has('/tmp/photo.png'));assert.deepEqual(creative.posts(),[]);
});
test('native sharing enforces image and aggregate quotas without publishing partial drafts',()=>{
 const env=setup();env.files.set('/tmp/large.png',Buffer.alloc(6*1024*1024+1));assert.throws(()=>creative.savePost(post({image:'/tmp/large.png'})));
 env.files.set('/user/douge-community/post-budget.png',Buffer.alloc(20*1024*1024));assert.throws(()=>creative.savePost(post()));assert.deepEqual(creative.posts(),[]);
 assert.equal([...env.files.keys()].filter(k=>k.startsWith('/user/')).length,1);
});
