const test=require('node:test');
const assert=require('node:assert/strict');
const model=require('../miniprogram/core/model');
const demo=require('../miniprogram/core/palette');
const core=require('../miniprogram/core/workbench');
const bench=require('../miniprogram/services/workbench');
const storage=require('../miniprogram/services/storage');
const creative=require('../miniprogram/services/creative');
const backup=require('../miniprogram/services/backup');
const transaction=require('../miniprogram/services/transaction');
const codec=require('../miniprogram/core/codec');
const png=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aXioAAAAASUVORK5CYII=','base64');
function setup(){
 const files=new Map([['/tmp/photo.png',Buffer.from(png)]]),keys=new Map(),dirs=new Set(['/user']),handles=new Map();let next=0,failKey='',failCount=0;
 const copy=v=>JSON.parse(JSON.stringify(v));
 const file=p=>{if(!files.has(p))throw Error('Missing: '+p);return files.get(p);};
 const fs={accessSync:p=>{if(!files.has(p)&&!dirs.has(p))throw Error('Missing');},mkdirSync:p=>dirs.add(p),statSync:p=>({size:file(p).length}),readdirSync:p=>[...files.keys()].filter(k=>k.startsWith(p+'/')&&!k.slice(p.length+1).includes('/')).map(k=>k.slice(p.length+1)),copyFileSync:(a,b)=>files.set(b,Buffer.from(file(a))),writeFileSync:(p,v,enc)=>files.set(p,Buffer.from(v,enc)),readFileSync:(p,enc)=>enc?file(p).toString(enc):file(p).buffer.slice(file(p).byteOffset,file(p).byteOffset+file(p).length),renameSync:(a,b)=>{files.set(b,file(a));files.delete(a);},unlinkSync:p=>files.delete(p),
  openSync:({filePath,flag})=>{if(flag==='wx'&&files.has(filePath))throw Error('exists');if(flag==='wx'||flag==='w')files.set(filePath,Buffer.alloc(0));else file(filePath);const fd=String(++next);handles.set(fd,{path:filePath,pos:0});return fd;},closeSync:({fd})=>handles.delete(fd),
  readSync:({fd,arrayBuffer,offset=0,length,position})=>{const h=handles.get(fd),data=file(h.path),start=position===undefined?h.pos:position,n=Math.min(length,data.length-start);new Uint8Array(arrayBuffer).set(data.subarray(start,start+n),offset);if(position===undefined)h.pos+=n;return {bytesRead:n,arrayBuffer};},
  writeSync:({fd,data,offset=0,length,position})=>{const h=handles.get(fd),bytes=Buffer.from(data,offset,length),start=position===undefined?h.pos:position,old=file(h.path),next=Buffer.alloc(Math.max(old.length,start+bytes.length));old.copy(next);bytes.copy(next,start);files.set(h.path,next);if(position===undefined)h.pos+=bytes.length;return {bytesWritten:bytes.length};}
 };
 global.wx={env:{USER_DATA_PATH:'/user'},getFileSystemManager:()=>fs,getStorageSync:k=>keys.has(k)?copy(keys.get(k)):'',setStorageSync:(k,v)=>{if(k===failKey&&failCount-->0)throw Error('commit failure');keys.set(k,copy(v));},removeStorageSync:k=>keys.delete(k),getImageInfo:args=>args.success({type:'png',width:1,height:1})};
 return {files,keys,handles,fs,fail:(key,n=1)=>{failKey=key;failCount=n;}};
}
function project(){const p=model.create({columns:16,rows:16,maxColors:8,cells:Array(256).fill(demo.palette.colors[0].id)},demo.palette,demo.board,'/tmp/photo.png');model.edit(p,0,demo.palette.colors[1].id);return p;}
function populate(){const p=project();storage.save(p);const m=bench.addMaterial('/tmp/photo.png','个人素材','动物');bench.mutate(s=>{s.materials[0].favorite=true;s.collages=[{id:'collage-original',name:'两层拼贴',updatedAt:Date.now(),layers:[{id:'layer-a',material:m.id,x:30,y:70,size:45,rotation:90,flip:true},{id:'layer-b',material:'flower',x:50,y:50,size:20,rotation:0,flip:false}]}];s.activeCollage='collage-original';core.mark(p,s,[0,1,2],true);s.inventory[core.inventoryKey(p.palette,p.cells[0])]=100;s.board={name:'个人拼板',columns:16,rows:24,pitch:2.6};});creative.savePost({title:'旧分享图',description:'保留旧数据',image:'/tmp/photo.png',consent:true});return {p,m};}

test('personal materials persist, reject referenced deletion and roll back a failed index commit',()=>{
 const env=setup();const {m}=populate();assert.equal(bench.load().materials[0].favorite,true);assert.throws(()=>bench.removeMaterial(m.id),/引用/);const before=[...env.files.keys()].sort();env.fail(bench.KEY);assert.throws(()=>bench.addMaterial('/tmp/photo.png','失败素材'));assert.deepEqual([...env.files.keys()].sort(),before);assert.equal(bench.load().materials.length,1);
 bench.mutate(s=>{s.collages=[];s.activeCollage='';});bench.removeMaterial(m.id);assert.equal(bench.load().materials.length,0);assert.ok(env.files.has('/tmp/photo.png'));
});
test('missing workbench state recovers the newest valid orphan or safely resets',()=>{
 const env=setup(),state=core.empty(),key=core.inventoryKey(demo.palette,demo.palette.colors[0].id);state.inventory[key]=7;const valid=bench.root()+'/state-valid.json',broken=bench.root()+'/state-broken.json',missing=bench.root()+'/state-missing.json';
 env.fs.mkdirSync(bench.root(),true);env.fs.writeFileSync(valid,JSON.stringify(state),'utf8');env.fs.writeFileSync(broken,'{bad json','utf8');wx.setStorageSync(bench.KEY,missing);
 assert.equal(bench.load().inventory[key],7);assert.equal(wx.getStorageSync(bench.KEY),valid);
 env.files.delete(valid);wx.setStorageSync(bench.KEY,missing);assert.deepEqual(bench.load(),core.empty());assert.equal(wx.getStorageSync(bench.KEY),'');
 wx.setStorageSync(bench.KEY,'/tmp/not-owned.json');assert.throws(()=>bench.load(),/索引损坏/);
});
test('making progress survives metadata edits but invalidates changed cells, dimensions and palette',()=>{
 const p=project(),s=core.empty();core.mark(p,s,[0,1,2],true);p.name='新名称';model.touch(p);assert.deepEqual(core.progress(p,s).done,[0,1,2]);model.edit(p,1,demo.palette.colors[2].id);assert.deepEqual(core.progress(p,s).done,[0,2]);model.edit(p,2,null);assert.deepEqual(core.progress(p,s).done,[0]);core.mark(p,s,[0],false);assert.deepEqual(core.progress(p,s).done,[]);core.mark(p,s,[0],true);p.palette.colors[0].hex='#123456';assert.deepEqual(core.progress(p,s).done,[]);
});
test('inventory keeps palette namespaces separate and never decrements on completion',()=>{
 const p=project(),s=core.empty(),key=core.inventoryKey(p.palette,p.cells[0]);s.inventory[key]=3;core.mark(p,s,[0],true);assert.equal(s.inventory[key],3);assert.equal(core.supply(p,s).find(c=>c.id===p.cells[0]).missing,0);const other=core.clone(p);other.palette.series='another series';assert.equal(core.supply(other,s).find(c=>c.id===p.cells[0]).stock,0);s.inventory[key]=-1;assert.throws(()=>core.validate(s),/库存/);
});
test('drag and pinch stay bounded while copying preserves the source layer',()=>{
 const layer={id:'l',material:'flower',x:50,y:50,size:40,rotation:90,flip:true};assert.equal(core.gesture(layer,[{x:0,y:0}],[{x:1000,y:-1000}],300,300).x,100);assert.equal(core.gesture(layer,[{x:0,y:0}],[{x:1000,y:-1000}],300,300).y,0);assert.equal(core.gesture(layer,[{x:0,y:0},{x:10,y:0}],[{x:0,y:0},{x:100,y:0}],300,300).size,80);assert.equal(layer.size,40);
});
test('imported palette cannot claim verification; duplicate or unsafe color codes and bad boards fail',()=>{
 const p={brand:'自备品牌',series:'测试',version:'1',verified:true,colors:[{id:'a',name:'红',hex:'#FF0000'},{id:'b',name:'蓝',hex:'#0000FF'}]};assert.equal(core.profile(p).verified,false);assert.equal(core.profile(p).colors[0].hex,'#ff0000');assert.throws(()=>core.profile({...p,colors:[p.colors[0],p.colors[0]]}));assert.throws(()=>core.profile({...p,colors:[{...p.colors[0],id:'toString'},p.colors[1]]}));assert.throws(()=>core.board({name:'坏板',columns:0,rows:29,pitch:5}));assert.throws(()=>core.board({name:'坏板',columns:29,rows:29,pitch:Infinity}));
});
test('complete backup roundtrip restores editable works, source images, materials, layers, progress, inventory and legacy images',async()=>{
 let env=setup();const {p}=populate();const file=await backup.build();const bytes=Buffer.from(env.files.get(file.path));assert.equal(backup.inspect(file.path).manifest.works.length,1);assert.equal(env.handles.size,0);
 env=setup();env.files.set('/tmp/restore.douge',bytes);const r=await backup.restore('/tmp/restore.douge');assert.deepEqual(r,{works:1,materials:1,collages:1});const restored=storage.read(storage.list()[0].id);assert.notEqual(restored.id,p.id);assert.deepEqual(restored.cells,p.cells);assert.deepEqual(env.files.get(restored.sourcePath),png);const state=bench.load();assert.equal(state.materials[0].favorite,true);assert.equal(state.collages[0].layers[0].material,state.materials[0].id);assert.deepEqual(core.progress(restored,state).done,[0,1,2]);assert.equal(core.supply(restored,state).find(c=>c.id===p.cells[0]).stock,100);assert.equal(state.board.pitch,2.6);assert.equal(creative.posts().length,1);assert.deepEqual(env.files.get(creative.posts()[0].image),png);assert.equal(env.handles.size,0);assert.equal(wx.getStorageSync(transaction.KEY),'');
});
test('restore adds independent copies and keeps existing work, stock and collage untouched',async()=>{
 const env=setup();const {p}=populate();const before=storage.read(p.id),stock=core.clone(bench.load().inventory);const file=await backup.build();await backup.restore(file.path);assert.equal(storage.list().length,2);assert.deepEqual(storage.read(p.id),before);assert.deepEqual(bench.load().inventory,stock);assert.equal(bench.load().collages.length,2);const restored=storage.list().find(x=>x.id!==p.id);storage.remove(restored.id);assert.deepEqual(storage.read(p.id),before);assert.ok(env.files.has(p.sourcePath));
});
test('corrupt backup or oversized image fails before publishing any recovered data',async()=>{
 const env=setup();populate();const file=await backup.build();const oldKeys=JSON.stringify([...env.keys]);const changed=Buffer.from(env.files.get(file.path));changed[changed.length-1]^=1;env.files.set('/tmp/bad.douge',changed);await assert.rejects(backup.restore('/tmp/bad.douge'),/校验/);assert.equal(JSON.stringify([...env.keys]),oldKeys);
 wx.getImageInfo=args=>args.success({type:'png',width:100000,height:100000});await assert.rejects(backup.restore(file.path),/像素/);assert.equal(JSON.stringify([...env.keys]),oldKeys);assert.equal(env.handles.size,0);
});
test('mid-commit failure rolls every data index back without deleting original files',async()=>{
 const env=setup();const {p}=populate();const file=await backup.build(),old=storage.read(p.id),state=bench.load(),post=creative.posts();env.fail('douge-share-drafts-v1');await assert.rejects(backup.restore(file.path),/commit failure/);assert.equal(storage.list().length,1);assert.deepEqual(storage.read(p.id),old);assert.deepEqual(bench.load(),state);assert.deepEqual(creative.posts(),post);assert.ok(env.files.has(p.sourcePath));assert.equal(wx.getStorageSync(transaction.KEY),'');assert.equal(env.handles.size,0);
});
test('startup journal recovery repairs an interrupted multi-index commit',()=>{
 const env=setup();const {p}=populate();const old=transaction.KEYS.map(key=>({key,value:wx.getStorageSync(key)||''}));const file=bench.root()+'/import-interrupted.png',journal=bench.root()+'/restore-interrupted.json';env.files.set(file,Buffer.from(png));env.files.set(journal,Buffer.from(JSON.stringify({old,files:[file]})));wx.setStorageSync(transaction.KEY,journal);wx.setStorageSync('bead-studio-index-v1',[]);transaction.recover();assert.equal(storage.list()[0].id,p.id);assert.equal(env.files.has(file),false);assert.equal(env.files.has(p.sourcePath),true);
});
test('UTF8/CRC encoding preserves Chinese and emoji while malicious metadata is rejected',()=>{
 const text='豆格🌷完整备份';assert.equal(codec.decode(codec.encode(text)),text);assert.equal(codec.checksum(codec.encode('123456789')),'cbf43926');assert.throws(()=>codec.parse('{"__proto__":{"polluted":true}}'),/不安全/);assert.equal({}.polluted,undefined);
});
test('cloud backup is fail-closed without config and rejects another owner file',async()=>{
 const config=require('../miniprogram/cloud-config');let calls=0;global.wx={cloud:{init:()=>calls++}};delete require.cache[require.resolve('../miniprogram/services/cloud-backup')];const cloud=require('../miniprogram/services/cloud-backup');await assert.rejects(cloud.list(true),/未配置/);assert.equal(calls,0);
 const saved={...config},auth=require('../miniprogram/services/auth');config.enabled=true;config.privacyReady=true;config.env='test-env';try{await assert.rejects(cloud.list(false),/同意/);wx.cloud={init(){},callFunction:async()=>({result:{openid:'owner-a'}}),database:()=>({collection:()=>({where:query=>{assert.equal(query._openid,'owner-a');return {get:async()=>({data:[{_id:'backup-example',_openid:'owner-b',fileID:'cloud://test-env.bucket/backups/owner-b/backup-example.douge',status:'ready'}]})};}})}),downloadFile:()=>assert.fail('foreign download called')};await auth.login(true,false);await assert.rejects(cloud.download('backup-example',true),/不属于/);}finally{auth.logout();Object.assign(config,saved);}
});


test('free creation complete backup restores editable text shapes pen strokes and selected palette',async()=>{
 let env=setup();populate();const base={x:50,y:50,size:60,rotation:33,flip:false};
 bench.mutate(s=>{const c=s.collages[0];c.background='white';c.paletteId='artkal-s-rgb-2024';c.layers.push({...base,id:'text-layer',type:'text',text:'名字和宠物',fontSize:90,color:'#123456'},{...base,id:'shape-layer',type:'shape',shape:'rect',fill:true,lineWidth:5,color:'#abdcfe'},{...base,id:'paint-layer',type:'paint',strokes:[{color:'#ff0000',width:9,erase:false,points:[[12,34],[56,78]]},{color:'#000000',width:4,erase:true,points:[[20,40]]}]});});
 const original=bench.load().collages[0],built=await backup.build(),bytes=Buffer.from(env.files.get(built.path));env=setup();env.files.set('/tmp/free.douge',bytes);await backup.restore('/tmp/free.douge');const restored=bench.load().collages[0];assert.equal(restored.background,'white');assert.equal(restored.paletteId,original.paletteId);assert.deepEqual(restored.layers.slice(2),original.layers.slice(2));assert.notEqual(restored.layers[0].material,original.layers[0].material);
});
