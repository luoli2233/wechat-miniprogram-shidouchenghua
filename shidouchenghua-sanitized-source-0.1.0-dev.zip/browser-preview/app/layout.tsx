import type { Metadata } from 'next';
import './globals.css';
import './ios.css';
export const metadata: Metadata = {
 icons:{icon:'/favicon.svg'},
 title:'豆格 · 浏览器拼豆工作室',description:'在本机将照片转为拼豆图纸，编辑颜色、保存作品和下载图纸，无需微信或 AppID。',
 openGraph:{title:'豆格 · 浏览器拼豆工作室',description:'把喜欢的瞬间，一颗颗留下来。照片在本机处理。',type:'website',images:[{url:'http://localhost:3000/og.png',width:1731,height:909,alt:'豆格 · 照片转拼豆 · 本机处理'}]},
 twitter:{card:'summary_large_image',title:'豆格 · 浏览器拼豆工作室',description:'无需微信的本地拼豆体验。',images:['http://localhost:3000/og.png']}
};
export default function Layout({children}:Readonly<{children:React.ReactNode}>){return <html lang="zh-CN"><body>{children}</body></html>;}
