export {styleRequest as POST} from '@/lib/style-runtime';
