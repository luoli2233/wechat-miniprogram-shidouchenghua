export {styleRequest as GET,styleRequest as DELETE} from '@/lib/style-runtime';
