export {styleRequest as POST,styleRequest as GET} from '@/lib/style-runtime';
