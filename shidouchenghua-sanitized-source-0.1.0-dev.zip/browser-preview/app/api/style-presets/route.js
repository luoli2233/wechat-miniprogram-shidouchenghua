export {styleRequest as GET} from '@/lib/style-runtime';
