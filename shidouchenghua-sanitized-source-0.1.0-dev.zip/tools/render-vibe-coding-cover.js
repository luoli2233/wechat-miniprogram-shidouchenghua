const fs=require('fs'),path=require('path'),sharp=require('sharp');
const root=path.resolve(__dirname,'..');
const out=path.join(root,'artifacts','xiaohongshu-launch-2026-09-10');
const bg=path.join(out,'vibe-coding-background.png');
const icon=path.join(out,'douge-avatar-pixel-landscape-144.png');
const screen=path.join(root,'artifacts','实机宣发素材-2026-09-10','01-首页-真实运行.png');
const target=path.join(out,'09-小红书封面-Vibe-Coding-v3.png');
const font="'Microsoft YaHei','PingFang SC','Noto Sans CJK SC',sans-serif";

async function run(){
  const background=await sharp(bg).resize(1080,1440,{fit:'cover'}).modulate({brightness:.93,saturation:.88}).png().toBuffer();
  const phone=await sharp(screen).resize(318,685,{fit:'cover',position:'top'}).composite([{input:Buffer.from('<svg width="318" height="685"><rect width="318" height="685" rx="34" fill="white"/></svg>'),blend:'dest-in'}]).png().toBuffer();
  const appIcon=await sharp(icon).resize(138,138).png().toBuffer();
  const overlay=`<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="1440">
  <defs><filter id="s" x="-30%" y="-30%" width="160%" height="160%"><feDropShadow dx="0" dy="18" stdDeviation="22" flood-color="#3f2630" flood-opacity=".2"/></filter></defs>
  <rect x="52" y="48" width="722" height="810" rx="48" fill="#fffaf7" fill-opacity=".94" filter="url(#s)"/>
  <g font-family="${font}">
    <text x="236" y="110" font-size="24" font-weight="800" fill="#ff466f">拾豆成画</text>
    <text x="88" y="280" font-size="64" font-weight="900" fill="#241d21">Vibe Coding</text>
    <text x="88" y="363" font-size="64" font-weight="900" fill="#241d21">做了一个</text>
    <rect x="82" y="397" width="605" height="104" rx="28" fill="#ff466f"/>
    <text x="385" y="470" text-anchor="middle" font-size="66" font-weight="900" fill="#fff">拼豆小程序</text>
    <text x="88" y="568" font-size="25" fill="#554c50">和 AI 边聊需求，边把想法</text>
    <text x="88" y="608" font-size="25" fill="#554c50">一点点做成能运行的产品。</text>
    <rect x="88" y="665" width="176" height="56" rx="28" fill="#fff" stroke="#edd8d2" stroke-width="2"/><text x="176" y="702" text-anchor="middle" font-size="20" fill="#241d21">照片转图纸</text>
    <rect x="282" y="665" width="160" height="56" rx="28" fill="#fff" stroke="#edd8d2" stroke-width="2"/><text x="362" y="702" text-anchor="middle" font-size="20" fill="#241d21">自由创作</text>
    <rect x="460" y="665" width="160" height="56" rx="28" fill="#fff" stroke="#edd8d2" stroke-width="2"/><text x="540" y="702" text-anchor="middle" font-size="20" fill="#241d21">图层编辑</text>
    <text x="88" y="790" font-size="19" font-weight="700" fill="#ff466f">一个人的产品开发记录  →</text>
    <rect x="654" y="520" width="356" height="772" rx="52" fill="#1d171a" filter="url(#s)"/>
    <rect x="758" y="532" width="148" height="30" rx="15" fill="#1d171a"/>
    <rect x="74" y="1184" width="520" height="114" rx="34" fill="#241d21" fill-opacity=".94"/>
    <text x="112" y="1234" font-size="24" font-weight="800" fill="#fff">真实运行界面</text>
    <text x="112" y="1270" font-size="19" fill="#f5e9e5">不是概念图 · 当前为开发预览</text>
    <text x="76" y="1378" font-size="18" fill="#4f4549">把喜欢，拼起来。</text>
  </g></svg>`;
  await sharp(background).composite([
    {input:Buffer.from(overlay)},
    {input:appIcon,left:82,top:78},
    {input:phone,left:673,top:570}
  ]).png().toFile(target);
  console.log(target);
}
run().catch(e=>{console.error(e);process.exit(1)});
