const fs = require('fs');
const path = require('path');
const automator = require('../tmp/miniprogram-automator/node_modules/miniprogram-automator');

const root = path.resolve(__dirname, '..');
const out = path.join(root, 'artifacts', 'wechat-runtime-screenshots-2026-09-10');
const pages = [
  ['home', '/pages/home/index'],
  ['library', '/pages/library/index'],
  ['history', '/pages/history/index'],
  ['account', '/pages/account/index'],
  ['workbench', '/pages/workbench/index'],
  ['help', '/pages/help/index'],
  ['editor', '/pages/editor/index'],
  ['make', '/pages/make/index'],
  ['export', '/pages/export/index'],
];

async function run() {
  fs.mkdirSync(out, { recursive: true });
  const miniProgram = await automator.connect({
    wsEndpoint: 'ws://127.0.0.1:9421',
  });
  try {
    for (const [name, route] of pages) {
      try {
        const page = await miniProgram.reLaunch(route);
        await page.waitFor(1200);
        const current = await miniProgram.currentPage();
        await miniProgram.screenshot({ path: path.join(out, `${name}.png`) });
        console.log(`captured ${name}: ${current.path}`);
      } catch (error) {
        console.error(`failed ${name}: ${error.message}`);
      }
    }
  } finally {
    await miniProgram.disconnect();
  }
}

run().catch(error => {
  console.error(error);
  process.exit(1);
});
