const fs=require('fs'),path=require('path');
const automator=require('../tmp/miniprogram-automator/node_modules/miniprogram-automator');
const root=path.resolve(__dirname,'..');
const out=path.join(root,'artifacts','wechat-runtime-screenshots-2026-09-10');

async function findByText(page,needle){
  for(const selector of ['button','text']){
    const els=await page.$$(selector);
    for(const el of els){
      const text=(await el.text()).trim();
      if(text===needle||text.includes(needle)) return el;
    }
  }
  return null;
}

async function run(){
  fs.mkdirSync(out,{recursive:true});
  const mini=await automator.connect({wsEndpoint:'ws://127.0.0.1:9422'});
  try{
    let page=await mini.switchTab('/pages/home/index');
    await page.waitFor(1000);
    const sample=await page.$('[data-kind="heart"]');
    if(!sample) throw new Error('未找到心形示例入口');
    await sample.tap();
    await new Promise(r=>setTimeout(r,1800));
    page=await mini.currentPage();
    await mini.screenshot({path:path.join(out,'demo-01-before-generate.png')});
    console.log('after sample:',page.path);
    if(page.path==='pages/crop/index'){
      const confirm=await page.$('.primary');
      if(!confirm) throw new Error('未找到确认裁剪按钮');
      await confirm.tap();
      await new Promise(r=>setTimeout(r,2500));
      page=await mini.currentPage();
    }
    await mini.mockWxMethod('showModal',{confirm:true,cancel:false,content:''});
    await page.callMethod('generate');
    await new Promise(r=>setTimeout(r,7000));
    await mini.screenshot({path:path.join(out,'demo-02-editor-pattern.png')});
    console.log('editor:',page.path);
    const preview=await page.$('[data-value="preview"]');
    if(preview){await preview.tap();await new Promise(r=>setTimeout(r,1000));await mini.screenshot({path:path.join(out,'demo-03-editor-preview.png')});}
    const make=await findByText(page,'开始制作');
    if(make){await make.tap();await new Promise(r=>setTimeout(r,1800));page=await mini.currentPage();await mini.screenshot({path:path.join(out,'demo-04-making.png')});console.log('making:',page.path);}
    await mini.restoreWxMethod('showModal');
  }finally{mini.disconnect();}
}
run().catch(e=>{console.error(e);process.exit(1)});
