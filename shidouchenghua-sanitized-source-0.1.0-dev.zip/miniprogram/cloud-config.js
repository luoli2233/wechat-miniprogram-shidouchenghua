// The environment ID is public configuration, never an AppSecret or access key.
// Cloud initialization is independent of the two cloud-backup safety switches.
// Enable backups only after verifying private database/storage rules and consent.
module.exports={env:'your-cloud-env-id',enabled:false,privacyReady:false};
