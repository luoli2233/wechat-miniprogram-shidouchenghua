const cloud=require('./services/cloud');
const auth=require('./services/auth');
App({
 globalData:{pendingImage:null,pendingSource:null,shareSource:null,cloudReady:false},
 onLaunch(){
  this.globalData.cloudReady=cloud.initialize();
  try{require('./services/transaction').recover();}catch(e){wx.showModal({title:'数据恢复需要重试',content:e.message,showCancel:false});}
  if(wx.onNeedPrivacyAuthorization)wx.onNeedPrivacyAuthorization(resolve=>{const pages=getCurrentPages(),page=pages[pages.length-1],guard=page&&page.selectComponent('#privacy');if(guard)guard.request(resolve);else resolve({event:'disagree'});});
  auth.restore();
 }
});
