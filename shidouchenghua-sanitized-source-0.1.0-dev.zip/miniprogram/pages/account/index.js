const auth=require('../../services/auth');
const ui=require('../../services/ui');
const PROFILE_KEY='douge-local-profile-v1';
function validName(value){return typeof value==='string'&&value.length>0&&value.length<=20&&/^[\u4e00-\u9fffA-Za-z0-9_\-\s]+$/.test(value);}
Page({
 data:{account:{loggedIn:false,busy:false,accountLabel:'未登录',error:''},profileName:'拼豆玩家',avatarText:'豆',consent:false,remember:true},
 onLoad(){try{const profile=wx.getStorageSync(PROFILE_KEY);if(profile&&profile.version===1&&validName(profile.name))this.applyName(profile.name);}catch(ignore){}this.off=auth.subscribe(account=>{if(!this.closed)this.setData({account});});},
 onShow(){this.setData({account:auth.snapshot()});},
 applyName(name){this.setData({profileName:name,avatarText:Array.from(name.replace(/\s/g,'')||'豆')[0]||'豆'});},
 async rename(){
  if(this.data.account.busy)return;
  const result=await ui.call('showModal',{title:'修改用户名称',editable:true,content:this.data.profileName,placeholderText:'输入1—20个字'});if(!result.confirm)return;
  const name=result.content.trim();if(!validName(name))return ui.error(Error('用户名称限1—20个中文、字母、数字、空格或连接符'));
  try{wx.setStorageSync(PROFILE_KEY,{version:1,name});this.applyName(name);}catch(e){ui.error(Error('名称保存失败，请检查微信存储空间后重试'));}
 },
 consent(e){if(!this.data.account.busy)this.setData({consent:e.detail.value.includes('login')});},
 remember(e){if(!this.data.account.busy)this.setData({remember:e.detail.value.includes('remember')});},
 async login(){
  if(this.data.account.busy)return;
  if(!this.data.consent)return ui.error(Error('请先阅读并同意登录说明'));
  this.startedLogin=true;
  try{await auth.login(true,this.data.remember);}
  catch(e){if(e.code==='AUTH_CONSENT'&&!this.closed)ui.error(e);}
  finally{this.startedLogin=false;}
 },
 async logout(){
  if(!await ui.modal('退出本小程序的登录状态并关闭自动恢复登录？不会退出微信，也不会删除本机作品或云备份。已提交的云操作不能撤回。','退出登录'))return;
  auth.logout();this.setData({consent:false});
 },
 guest(){if(this.data.account.busy)auth.logout();wx.switchTab({url:'/pages/home/index'});},
 help(){wx.navigateTo({url:'/pages/help/index'});},
 workbench(){wx.navigateTo({url:'/pages/workbench/index'});},
 onUnload(){this.closed=true;if(this.off)this.off();if(this.startedLogin&&auth.snapshot().busy)auth.logout();}
});
