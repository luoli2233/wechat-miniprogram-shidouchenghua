const model=require('../../core/model');const render=require('../../core/render');const ui=require('../../services/ui');const security=require('../../services/security');
Page({
 data:{busy:false,files:[],status:'选择需要导出的内容',total:0},
 onLoad(){this.project=getApp().globalData.exportProject;getApp().globalData.exportProject=null;if(this.project)this.setData({name:this.project.name,total:model.stats(this.project).total,paletteNote:require('../../core/palette-catalog').note(this.project.palette)});},
 async onReady(){try{if(!this.project)throw Error('请从编辑页重新进入导出');model.validate(this.project);this.canvas=(await ui.node(this,'export')).node;}catch(e){ui.error(e);}},
 async build(e){if(this.data.busy||!this.canvas)return;this.setData({busy:true,files:[],status:'正在生成导出图片…'});const files=[];
  try{const kind=e.currentTarget.dataset.kind,legendCount=render.legendPages(this.project);const legends=Array.from({length:legendCount},(_,page)=>({name:legendCount>1?`全局清单 ${page+1}`:'全局清单',type:'legend',page}));const tasks=kind==='overview'?[{name:'作品总览',type:'overview'}]:[...model.partitions(this.project).map(p=>({name:'分区 '+p.name,type:'part',part:p})),...legends];
   for(let i=0;i<tasks.length;i++){await ui.later();if(this.closed)return;const task=tasks[i];this.setData({status:`生成 ${i+1}/${tasks.length} · ${task.name}`});if(task.type==='overview')render.overview(this.canvas,this.project);else if(task.type==='legend')render.legendPage(this.canvas,this.project,task.page);else render.exportPage(this.canvas,this.project,task.part,i,tasks.length-legendCount);files.push({name:task.name,path:await ui.temp(this.canvas),saved:false,error:false});this.setData({files:files.slice()});}
   this.setData({status:`已生成 ${files.length} 张图片，预览后保存`});
  }catch(e){ui.error(e);this.setData({status:'生成中断，已完成的图片仍可保存'});}finally{if(!this.closed)this.setData({busy:false});}
 },
 preview(e){const index=Number(e.currentTarget.dataset.index);wx.previewImage({current:this.data.files[index].path,urls:this.data.files.map(f=>f.path)});},
 async saveAll(){if(this.data.busy||!this.data.files.length)return;this.setData({busy:true});const files=this.data.files.slice();
  try{for(let i=0;i<files.length;i++){if(files[i].saved)continue;this.setData({status:`内容安全校验 ${i+1}/${files.length}`});try{await security.image(files[i].path);await security.text(this.data.name+' · '+files[i].name);this.setData({status:`保存 ${i+1}/${files.length}`});await ui.call('saveImageToPhotosAlbum',{filePath:files[i].path});files[i]={...files[i],saved:true,error:false};}catch(e){files[i]={...files[i],error:true};this.setData({files:files.slice()});if(/auth|deny|denied/i.test(e.errMsg||'')){this.setData({needPermission:true});break;}throw e;}this.setData({files:files.slice()});}
   const n=files.filter(f=>f.saved).length;this.setData({files,status:n===files.length?`全部 ${n} 张已保存到相册`:`已保存 ${n}/${files.length} 张，可重试未成功项`});
  }catch(e){this.setData({status:'内容安全校验未通过，未保存相关图片'});ui.error(e);}finally{this.setData({busy:false});}
 },
 share(e){if(this.data.busy)return;const file=this.data.files[Number(e.currentTarget.dataset.index)];if(!file)return;getApp().globalData.shareSource={path:file.path,title:this.data.name+' · '+file.name,kind:'export',aiAssisted:Boolean(this.project.aiStyle)};ui.call('navigateTo',{url:'/pages/share/index'}).catch(err=>{getApp().globalData.shareSource=null;ui.error(err);});},
 settings(){wx.openSetting({});},
 async copy(){try{await ui.call('setClipboardData',{data:model.materialText(this.project)});}catch(e){ui.error(e);}},
 onUnload(){this.closed=true;}
});
