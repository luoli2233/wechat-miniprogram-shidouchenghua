const ui=require('../../services/ui');
const storage=require('../../services/storage');
const render=require('../../core/render');
Page({
 data:{recent:null},
 onShow(){try{this.setData({recent:storage.list()[0]||null});this.thumbnail();}catch(e){ui.error(e);}},
 async onReady(){try{this.thumb=(await ui.node(this,'recent-thumb')).node;this.thumbnail();}catch(e){}},
 async thumbnail(){const token=this.thumbToken=(this.thumbToken||0)+1,item=this.data.recent;if(!this.thumb||!item)return;try{const project=storage.read(item.id);this.thumb.width=120;this.thumb.height=120;const ctx=this.thumb.getContext('2d');ctx.fillStyle='#F2F5F9';ctx.fillRect(0,0,120,120);const cell=Math.min(120/project.columns,120/project.rows);render.grid(ctx,project,{cell,labels:false,lines:false,offsetX:(120-project.columns*cell)/2,offsetY:(120-project.rows*cell)/2});const thumbnail=await ui.temp(this.thumb);if(token===this.thumbToken&&this.data.recent&&this.data.recent.id===item.id)this.setData({recent:{...this.data.recent,thumbnail}});}catch(e){}},
 async choose(){try{const result=await ui.call('chooseMedia',{count:1,mediaType:['image'],sourceType:['album','camera'],sizeType:['original']});const file=result.tempFiles[0];if(file.size>20*1024*1024)throw Error('图片超过20MB，请先压缩');getApp().globalData.pendingImage=file.tempFilePath;wx.navigateTo({url:'/pages/crop/index'});}catch(e){if(!(e.errMsg||'').includes('cancel'))ui.error(e);}},
 example(e){const kind=e.currentTarget.dataset.kind;getApp().globalData.pendingSource=kind==='tulip'?{path:'/assets/inspiration-source.png'}:{example:kind};wx.navigateTo({url:'/pages/editor/index'});},
 resume(){if(this.data.recent)wx.navigateTo({url:'/pages/editor/index?id='+encodeURIComponent(this.data.recent.id)});},
 library(){wx.switchTab({url:'/pages/library/index'});},
 share(){getApp().globalData.shareSource=null;wx.navigateTo({url:'/pages/share/index'});},
 workbench(){wx.navigateTo({url:'/pages/workbench/index'});},
 history(){wx.switchTab({url:'/pages/history/index'});},help(){wx.navigateTo({url:'/pages/help/index'});},onUnload(){this.thumbToken=(this.thumbToken||0)+1;}
});
