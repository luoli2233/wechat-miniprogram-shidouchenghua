const editor=require('../../core/creative-editor');
const core=require('../../core/workbench');
const bench=require('../../services/workbench');
const creative=require('../../services/creative');
const palettes=require('../../core/palette-catalog');
const ui=require('../../services/ui');
const clone=v=>JSON.parse(JSON.stringify(v));
module.exports={
 async onReady(){try{
  const surface=await ui.node(this,'collage');this.canvas=surface.node;this.stage={left:0,top:0,width:surface.width,height:surface.height};this.output=(await ui.node(this,'composite')).node;this.scratch=(await ui.node(this,'paint-buffer')).node;
  this.canvas.width=this.canvas.height=512;this.images={};this.imageLoads={};this.setData({ready:true});await this.redraw();
 }catch(e){ui.error(e);}},
 reload(){
  const state=bench.load(),c=state.collages.find(c=>c.id===state.activeCollage)||state.collages[0];this.catalog();
  const options=palettes.list(state.profile);if(c.paletteSnapshot&&!options.some(p=>core.fingerprint(p)===core.fingerprint(c.paletteSnapshot)))options.push(c.paletteSnapshot);const index=Math.max(0,options.findIndex(p=>c.paletteSnapshot?core.fingerprint(p)===core.fingerprint(c.paletteSnapshot):p.id===c.paletteId));this.paletteOptions=options;
  this.history=new editor.History();this.gesture=null;this.pen=null;
  this.setData({collages:state.collages,collageNames:state.collages.map(c=>c.name),collageId:c.id,collageName:c.name,background:c.background||'transparent',paletteIndex:index,paletteNames:options.map(p=>p.brand+' / '+p.series+' · '+p.version),paletteNote:palettes.note(options[index]),mode:'move',hasUndo:false,hasRedo:false});
  this.sync(c.layers,'');this.baseline=this.snapshot();
 },
 snapshot(){return {layers:core.layers(this.data.layers,this.data.materials),background:this.data.background||'transparent',paletteId:this.paletteOptions[this.data.paletteIndex].id,paletteSnapshot:clone(this.paletteOptions[this.data.paletteIndex])};},
 sync(items,selected=this.data.selected){
  const layers=core.layers(items,this.data.materials),named=layers.map(l=>({...l,name:l.type==='image'?this.data.materials.find(m=>m.id===l.material).name:editor.label(l)})),layer=named.find(l=>l.id===selected)||null,index=layer?named.findIndex(l=>l.id===layer.id):-1;
  const layerRows=named.slice().reverse().map((l,row)=>({...l,stackPosition:named.length-row,stackNote:row===0?'最上层':row===named.length-1?'最底层':''}));
  const layerPositionOptions=named.map((l,i)=>'第 '+(i+1)+' 层'+(i===0?'（最底层）':i===named.length-1?'（最上层）':''));
  const overlapIds=(this.overlapIds||[]).filter(id=>named.some(l=>l.id===id&&!l.hidden&&!l.locked));this.overlapIds=overlapIds;
  this.setData({layers:named,layerRows,layerPositionOptions,layerPositionIndex:Math.max(0,index),canMoveUp:index>=0&&index<named.length-1,canMoveDown:index>0,overlapCount:overlapIds.length,selected:layer?selected:'',layer,canGenerate:layers.some(l=>!l.hidden)});
  this.redraw();
 },
 async redraw(){
  if(!this.canvas||!this.scratch)return;const token=this.renderToken=(this.renderToken||0)+1;
  try{
   const layers=core.layers(this.data.layers,this.data.materials);
   this.loadingImages=layers.some(l=>l.type==='image'&&!this.images[l.material]);
   const used=new Set(layers.filter(l=>l.type==='image').map(l=>l.material));for(const id of Object.keys(this.images))if(!used.has(id))delete this.images[id];
   for(const l of layers)if(l.type==='image'&&!this.images[l.material]){
    const m=this.data.materials.find(m=>m.id===l.material);this.imageLoads=this.imageLoads||{};
    if(!this.imageLoads[l.material])this.imageLoads[l.material]=ui.loadImage(this.canvas,m.src);
    try{this.images[l.material]=await this.imageLoads[l.material];}finally{delete this.imageLoads[l.material];}
   }
   if(token!==this.renderToken)return;
   editor.draw(this.canvas.getContext('2d'),layers,this.images,this.scratch,this.data.background==='white'?'#ffffff':'transparent');
   const l=layers.find(l=>l.id===this.data.selected);
   if(l&&!l.hidden&&this.data.mode==='move'){
    const ctx=this.canvas.getContext('2d'),box=editor.bounds(l,this.images),scale=l.size/100;ctx.save();ctx.translate(l.x*5.12,l.y*5.12);ctx.rotate(l.rotation*Math.PI/180);ctx.strokeStyle=l.locked?'#777777':'#007aff';ctx.lineWidth=2;ctx.setLineDash([6,4]);ctx.strokeRect(-box.width*scale/2,-box.height*scale/2,box.width*scale,box.height*scale);ctx.restore();
   }
   this.loadingImages=false;this.setData({renderError:false});
  }catch(e){if(token===this.renderToken){this.loadingImages=false;this.setData({renderError:true,status:'画布读取失败，请重试或移除失效素材'});ui.error(e);}}
 },
 commit(){
  if(!this.data.collageId)return false;
  try{const state=bench.load(),c=state.collages.find(c=>c.id===this.data.collageId);if(!c)throw Error('创作草稿不存在');Object.assign(c,this.snapshot(),{updatedAt:Date.now()});state.activeCollage=c.id;bench.save(state);this.dirty=false;
   if(wx.disableAlertBeforeUnload)wx.disableAlertBeforeUnload({});this.setData({status:'创作已保存在本机'});return true;
  }catch(e){this.dirty=true;if(wx.enableAlertBeforeUnload)wx.enableAlertBeforeUnload({message:'创作未保存，请先重试保存。'});this.setData({status:'保存失败，修改仍在此页，请重试保存'});ui.error(e);return false;}
 },
 changed(){
  const next=this.snapshot();this.history.push(this.baseline,next);this.baseline=clone(next);this.dirty=true;
  this.setData({hasUndo:!!this.history.past.length,hasRedo:!!this.history.future.length});return this.commit();
 },
 historyStep(e){
  if(this.data.busy)return;const next=e.currentTarget.dataset.action==='undo'?this.history.undo(this.snapshot()):this.history.redo(this.snapshot());if(!next)return;
  this.setData({background:next.background,paletteIndex:Math.max(0,this.paletteOptions.findIndex(p=>next.paletteSnapshot?core.fingerprint(p)===core.fingerprint(next.paletteSnapshot):p.id===next.paletteId))});this.sync(next.layers);this.baseline=this.snapshot();this.setData({hasUndo:!!this.history.past.length,hasRedo:!!this.history.future.length,paletteNote:palettes.note(this.paletteOptions[this.data.paletteIndex])});this.dirty=true;this.commit();
 },
 addLayer(extra){
  if(this.data.busy)return;if(this.data.layers.length>=12)return ui.error(Error('一幅创作最多12层，请先整理图层'));
  const id=bench.id('layer'),l={id,x:50,y:50,size:45,rotation:0,flip:false,hidden:false,locked:false,opacity:1,...extra};this.sync([...this.data.layers,l],id);this.changed();
 },
 add(e){this.addLayer({type:'image',material:e.currentTarget.dataset.id});this.setData({mode:'move'});},
 async addText(){if(this.data.busy)return;const r=await ui.call('showModal',{title:'添加文字（最多80字）',editable:true,placeholderText:'输入名字或一句话'});if(r.confirm&&r.content.trim())try{this.addLayer({type:'text',text:r.content.trim().slice(0,80),fontSize:80,color:this.data.ink});this.setData({mode:'move'});}catch(e){ui.error(e);}},
 async editText(){if(!this.editable()||this.data.layer.type!=='text')return;const r=await ui.call('showModal',{title:'修改文字',editable:true,content:this.data.layer.text});if(r.confirm&&r.content.trim())this.patch({text:r.content.trim().slice(0,80)});},
 addShape(e){this.addLayer({type:'shape',shape:e.currentTarget.dataset.shape,color:this.data.ink,fill:true,lineWidth:8});this.setData({mode:'move'});},
 addPaint(){if(this.data.busy)return;this.addLayer({type:'paint',size:100,strokes:[]});if(this.editable()&&this.data.layer.type==='paint')this.setData({mode:'draw'});},
 editable(){return !this.data.busy&&this.data.layer&&!this.data.layer.locked;},
 patch(patch){if(!this.editable())return;try{this.sync(this.data.layers.map(l=>l.id===this.data.selected?{...l,...patch}:l));this.changed();}catch(e){ui.error(e);}},
 scaleStep(e){if(!this.editable())return;this.patch({size:Math.max(10,Math.min(editor.MAX_SIZE,Math.round(this.data.layer.size+Number(e.currentTarget.dataset.step))))});},
 changing(e){if(!this.editable())return;const key=e.currentTarget.dataset.key;if(key!=='size')return;try{this.sync(this.data.layers.map(l=>l.id===this.data.selected?{...l,size:Number(e.detail.value)}:l));}catch(e){ui.error(e);}},
 select(e){if(this.data.busy)return;this.touchEnd();this.overlapIds=[];this.setData({mode:'move',overlapCount:0});this.sync(this.data.layers,e.currentTarget.dataset.id);},
 change(e){const key=e.currentTarget.dataset.key;if(['x','y','size','rotation','fontSize','lineWidth','opacity'].includes(key))this.patch({[key]:Number(e.detail.value)/(key==='opacity'?100:1)});},
 toggleLayer(e){if(this.data.busy||!this.data.layer)return;const key=e.currentTarget.dataset.key;if(!['hidden','locked'].includes(key))return;this.sync(this.data.layers.map(l=>l.id===this.data.selected?{...l,[key]:!l[key]}:l));this.changed();},
 toggleFill(){if(this.data.layer?.type==='shape')this.patch({fill:!this.data.layer.fill});},
 ink(e){const ink=e.currentTarget.dataset.color;this.setData({ink});if(['text','shape'].includes(this.data.layer?.type))this.patch({color:ink});},
 customInk(e){const value=e.detail.value.trim();if(!/^#[0-9a-f]{6}$/i.test(value))return ui.error(Error('颜色请输入#加六位十六进制，例如#336699'));this.ink({currentTarget:{dataset:{color:value}}});},
 brushWidth(e){this.setData({brushWidth:Number(e.detail.value)});},
 setMode(e){if(this.data.busy)return;const mode=e.currentTarget.dataset.mode;if(!['move','draw','erase'].includes(mode))return;this.touchEnd();if(mode!=='move'&&(!this.editable()||this.data.layer.type!=='paint'||this.data.layer.hidden)){if(mode==='erase')return ui.error(Error('请先选择可见、未锁定的绘画图层'));this.addPaint();if(!this.editable()||this.data.layer.type!=='paint'||this.data.layer.hidden)return;}this.setData({mode});this.redraw();},
 background(){if(this.data.busy)return;this.setData({background:this.data.background==='white'?'transparent':'white'});this.changed();this.redraw();},
 palette(e){if(this.data.busy)return;const index=Number(e.detail.value);if(!this.paletteOptions[index])return;this.setData({paletteIndex:index,paletteNote:palettes.note(this.paletteOptions[index])});this.changed();},
 duplicate(){if(!this.data.layer||this.data.busy)return;const l=clone(this.data.layer);delete l.id;this.addLayer({...l,locked:false,x:Math.min(100,l.x+4),y:Math.min(100,l.y+4)});},
 reorder(e){
  if(!this.editable())return;const layers=this.data.layers.slice(),i=layers.findIndex(l=>l.id===this.data.selected),action=e.currentTarget.dataset.action;let to=i+Number(e.currentTarget.dataset.delta||0);
  if(action==='top')to=layers.length-1;if(action==='bottom')to=0;if(i<0||to<0||to>=layers.length||to===i)return;
  const [layer]=layers.splice(i,1);layers.splice(to,0,layer);this.sync(layers,layer.id);this.changed();this.setData({status:'图层位置已调整'});
 },
 setLayerPosition(e){
  if(!this.editable())return;const layers=this.data.layers.slice(),i=layers.findIndex(l=>l.id===this.data.selected),to=Number(e.detail.value);if(i<0||to<0||to>=layers.length||to===i)return;
  const [layer]=layers.splice(i,1);layers.splice(to,0,layer);this.sync(layers,layer.id);this.changed();this.setData({status:'已移动到第 '+(to+1)+' 层'});
 },
 cycleOverlap(){
  if(this.data.busy||!this.overlapIds||this.overlapIds.length<2)return;const current=this.overlapIds.indexOf(this.data.selected),next=this.overlapIds[(current+1+this.overlapIds.length)%this.overlapIds.length];this.setData({mode:'move'});this.sync(this.data.layers,next);
 },
 remove(){if(!this.editable())return;this.sync(this.data.layers.filter(l=>l.id!==this.data.selected),'');this.changed();},
 touchStart(e){
  if(this.pendingTouches){this.pendingTouches.push(['touchStart',e]);return;}
  if(this.data.busy||!this.data.ready||this.loadingImages||this.data.renderError)return;
  if(this.pen||this.penPaused){if(e.touches.length>1){this.touchEnd();this.penPaused=true;}return;}
  if(this.gesture&&e.touches.length===2){this.gesture={layer:clone(this.data.layer),points:this.points(e)};return;}
  const p=e.touches[0];if(!p)return;this.touchEnded=false;
  // Prefer Canvas-local coordinates and cached dimensions so a quick tap is not lost.
  const begin=r=>{
   if(!r||this.touchEnded)return;this.stage=r;const point=this.canvasPoint(p);
   if(this.data.mode==='move'){
    const selected=this.data.layers.find(l=>l.id===this.data.selected),hits=editor.hits(this.data.layers,point[0],point[1],this.images);this.overlapIds=hits.map(l=>l.id);const picked=(selected&&!selected.locked&&!selected.hidden&&e.touches.length===2?selected:null)||(selected&&editor.hit([selected],point[0],point[1],this.images))||hits[0];this.sync(this.data.layers,picked?.id||'');if(picked)this.gesture={layer:clone(picked),points:this.points(e)};
   }else if(this.editable()&&this.data.layer.type==='paint'&&!this.data.layer.hidden){
    if(e.touches.length!==1)return;const l=this.data.layer;if(l.strokes.length>=editor.MAX_STROKES)return ui.error(Error('本绘画层已达120笔，请新建绘画层'));
    this.pen={id:l.id,stroke:{color:this.data.ink,width:this.data.brushWidth,erase:this.data.mode==='erase',points:[]}};this.penPoint(point);this.previewPen();
   }
  };if(p.x!==undefined&&p.y!==undefined&&this.stage?.width)begin(this.stage);else{const queue=this.pendingTouches=[];this.createSelectorQuery().select('#collage').boundingClientRect(r=>{if(this.pendingTouches!==queue)return;this.pendingTouches=null;begin(r);for(const [method,event] of queue)this[method](event);}).exec();}
 },
 points(e){return e.touches.slice(0,2).map(t=>({x:t.clientX===undefined?(t.pageX===undefined?t.x:t.pageX):t.clientX,y:t.clientY===undefined?(t.pageY===undefined?t.y:t.pageY):t.clientY}));},
 canvasPoint(t){return [Math.max(0,Math.min(512,(t.x===undefined?(t.clientX===undefined?t.pageX:t.clientX)-this.stage.left:t.x)/this.stage.width*512)),Math.max(0,Math.min(512,(t.y===undefined?(t.clientY===undefined?t.pageY:t.clientY)-this.stage.top:t.y)/this.stage.height*512))];},
 penPoint(point){
  if(!this.pen)return;const l=this.data.layers.find(l=>l.id===this.pen.id);const local=editor.localPoint(l,...point);if(local.some(n=>n<0||n>512))return;const p=local.map(n=>Math.round(n*10)/10),pts=this.pen.stroke.points;
  const total=this.data.layers.filter(l=>l.type==='paint').reduce((n,l)=>n+l.strokes.reduce((n,s)=>n+s.points.length,0),0);
  if(pts.length>=2000||total+pts.length>=editor.MAX_POINTS){this.setData({status:'笔迹已达容量上限，请另存或整理画布'});return;}
  if(!pts.length||Math.hypot(p[0]-pts[pts.length-1][0],p[1]-pts[pts.length-1][1])>=1.5)pts.push(p);
 },
 previewPen(){if(!this.pen||!this.pen.stroke.points.length)return;const items=this.data.layers.map(l=>l.id===this.pen.id?{...l,strokes:[...l.strokes,this.pen.stroke]}:l);editor.draw(this.canvas.getContext('2d'),items,this.images,this.scratch,this.data.background==='white'?'#ffffff':'transparent');},
 touchMove(e){
  if(this.pendingTouches){this.pendingTouches.push(['touchMove',e]);return;}
  if(this.data.busy||!this.stage)return;
  if(this.pen){if(e.touches.length!==1)return;this.penPoint(this.canvasPoint(e.touches[0]));this.previewPen();return;}
  if(!this.gesture)return;const points=this.points(e);if(points.length!==this.gesture.points.length){this.gesture={layer:clone(this.data.layer),points};return;}
  const next=core.gesture(this.gesture.layer,this.gesture.points,points,this.stage.width,this.stage.height,editor.MAX_SIZE);this.sync(this.data.layers.map(l=>l.id===next.id?next:l));
 },
 touchEnd(e){
  if(this.pendingTouches&&e){this.pendingTouches.push(['touchEnd',e]);return;}
  if(e&&e.touches&&e.touches.length){if(this.gesture)this.gesture={layer:clone(this.data.layer),points:this.points(e)};return;}
  this.penPaused=false;
  if(this.pen&&e&&e.changedTouches&&e.changedTouches.length===1)this.penPoint(this.canvasPoint(e.changedTouches[0]));
  this.touchEnded=true;try{if(this.pen?.stroke.points.length){this.sync(this.data.layers.map(l=>l.id===this.pen.id?{...l,strokes:[...l.strokes,this.pen.stroke]}:l));this.changed();}else if(this.gesture)this.changed();}catch(e){ui.error(e);}this.pen=null;this.gesture=null;this.redraw();
 },
 touchCancel(){this.pendingTouches=null;this.penPaused=false;this.touchEnded=true;this.pen=null;this.gesture=null;if(this.baseline)this.sync(this.baseline.layers);},
 async newDraft(e){
  if(this.data.busy||!this.commit())return;try{const state=bench.load();if(state.collages.length>=30)throw Error('最多保存30份创作');const duplicate=e.currentTarget.dataset.copy==='yes';const current=this.snapshot();const c={id:bench.id('collage'),name:duplicate?(this.data.collageName+' 副本').slice(0,40):'空白创作',updatedAt:Date.now(),...current,layers:duplicate?current.layers:[]};state.collages.push(c);state.activeCollage=c.id;bench.save(state);this.reload();}catch(e){ui.error(e);}
 },
 async image(){
  const layers=core.layers(this.data.layers,this.data.materials);for(const l of layers)if(l.type==='image'&&!this.images[l.material])this.images[l.material]=await ui.loadImage(this.canvas,this.data.materials.find(m=>m.id===l.material).src);
  this.output.width=this.output.height=512;editor.draw(this.output.getContext('2d'),layers,this.images,this.scratch,this.data.background==='white'?'#ffffff':'transparent');return ui.temp(this.output);
 },
 async generate(){
  if(this.data.busy)return;
  if(!this.data.ready)return ui.error(Error('创作画布还没有准备好，请稍后重试'));
  if(this.data.renderError)return ui.error(Error('画布渲染失败，请先重试或移除失效素材'));
  if(!this.data.layers.some(l=>!l.hidden))return ui.error(Error('请先添加并显示至少一个创作图层'));
  if(!this.commit())return;
  this.setData({busy:true});try{
   const p=this.paletteOptions[this.data.paletteIndex];
   getApp().globalData.pendingSource={path:await this.image(),kind:'collage',palette:clone(p)};await ui.call('navigateTo',{url:'/pages/editor/index'});
  }catch(e){ui.error(e);}finally{this.setData({busy:false});}
 },
 onHide(){this.pendingTouches=null;this.touchEnd();if(this.dirty)this.commit();},
 onUnload(){this.renderToken=(this.renderToken||0)+1;this.canvas=null;this.images={};}
};
