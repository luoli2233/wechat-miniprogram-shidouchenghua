const studio=require('./studio');
const creative=require('../../services/creative');
const bench=require('../../services/workbench');
const core=require('../../core/workbench');
const sharing=require('../../services/share');
const ui=require('../../services/ui');
Page({
 data:{panel:'create',ink:'#263c35',brushWidth:8,mode:'move',background:'transparent',paletteIndex:0,paletteNames:[],paletteNote:'',hasUndo:false,hasRedo:false,inkColors:['#263c35','#ffffff','#ff4f70','#ffc454','#69b59c','#558bd0','#9a70c1','#eab59d','#f08a4b','#c9425b','#9bc65c','#3c9b99','#39507a','#8b6b55','#a5abb5','#f3a7bd'],materials:[],filtered:[],categories:['全部'],category:'全部',query:'',layers:[],layerRows:[],layerPositionOptions:[],layerPositionIndex:0,canMoveUp:false,canMoveDown:false,overlapCount:0,selected:'',layer:null,canGenerate:false,busy:false,ready:false,status:'添加文字、形状、素材或绘画层开始创作',collages:[],collageNames:[],collageId:'',collageName:''},
 onLoad(){try{const s=bench.load();if(!s.collages.length){const legacy=creative.loadCollage();const first={id:bench.id('collage'),name:'我的拼贴',layers:legacy.layers,updatedAt:Date.now()};s.collages=[first];s.activeCollage=first.id;bench.save(s);}this.reload();}catch(e){ui.error(e);}},
 onShow(){if(this.data.collageId)try{this.catalog();}catch(e){ui.error(e);}},
 catalog(){const materials=bench.catalog(creative.materials);this.setData({materials,categories:['全部','收藏',...new Set(materials.map(m=>m.category))]});this.filter();},
 filter(){const query=this.data.query.trim();this.setData({filtered:this.data.materials.filter(m=>(this.data.category==='全部'||(this.data.category==='收藏'?m.favorite:m.category===this.data.category))&&m.name.includes(query))});},
 search(e){this.setData({query:e.detail.value});this.filter();},category(e){this.setData({category:e.currentTarget.dataset.value});this.filter();},
 selectPanel(e){if(!this.data.busy)this.setData({panel:e.currentTarget.dataset.panel});},
 select(e){if(!this.data.busy)this.sync(this.data.layers,e.currentTarget.dataset.id);},
 rotate(){if(this.data.layer&&!this.data.busy)this.patch({rotation:(this.data.layer.rotation+90)%360});},
 mirror(){if(this.data.layer&&!this.data.busy)this.patch({flip:!this.data.layer.flip});},
 center(){if(this.data.layer&&!this.data.busy)this.patch({x:50,y:50});},
 startGesture(e){if(this.data.layer)this.gesture={layer:{...this.data.layer},points:this.points(e)};},
 save(){if(!this.data.busy)this.commit();},
 async draft(e){if(this.data.busy||!this.commit())return;try{const c=this.data.collages[Number(e.detail.value)];if(!c)return;bench.mutate(s=>{s.activeCollage=c.id;});this.reload();}catch(e){ui.error(e);}},
 async renameDraft(){if(this.data.busy)return;const r=await ui.call('showModal',{title:'拼贴名称',editable:true,placeholderText:this.data.collageName});if(r.confirm&&r.content.trim())try{bench.mutate(s=>{s.collages.find(c=>c.id===this.data.collageId).name=r.content.trim().slice(0,40);});this.setData({collageName:r.content.trim().slice(0,40)});if(this.commit())this.reload();}catch(e){ui.error(e);}},
 async deleteDraft(){if(this.data.busy)return;if(!await ui.modal('删除当前拼贴草稿？素材文件与已生成的拼豆作品会保留。','删除拼贴'))return;try{bench.mutate(s=>{s.collages=s.collages.filter(c=>c.id!==this.data.collageId);if(!s.collages.length)s.collages.push({id:bench.id('collage'),name:'新拼贴',layers:[],updatedAt:Date.now()});s.activeCollage=s.collages[0].id;});this.reload();this.dirty=false;}catch(e){ui.error(e);}},
 async importMaterial(){if(this.data.busy||!this.data.ready)return;this.setData({busy:true});try{const r=await ui.call('chooseMedia',{count:1,mediaType:['image'],sourceType:['album','camera'],sizeType:['original']});const path=await sharing.photo(this.output,r.tempFiles[0]);const answer=await ui.call('showModal',{title:'保存到我的素材',editable:true,placeholderText:'素材名称（最多40字）'});if(!answer.confirm)return;const name=(answer.content.trim()||'我的素材').slice(0,40);bench.addMaterial(path,name);this.catalog();this.setData({status:'素材已保存在本机；分享前会另行进行内容安全校验'});}catch(e){if(!sharing.cancelled(e))ui.error(e);}finally{this.setData({busy:false});}},
 async materialAction(e){if(this.data.busy)return;const m=this.data.materials.find(m=>m.id===e.currentTarget.dataset.id);if(!m)return;this.setData({busy:true});try{const r=await ui.call('showActionSheet',{itemList:['分享素材图片',...(m.id.startsWith('mat-')?[m.favorite?'取消收藏':'收藏素材','重命名','设置分类','删除素材']:[])]});if(r.tapIndex===0){getApp().globalData.shareSource={path:m.src,title:m.name,kind:'material'};await ui.call('navigateTo',{url:'/pages/share/index'});}else if(r.tapIndex===1){bench.mutate(s=>{s.materials.find(x=>x.id===m.id).favorite=!m.favorite;});}else if(r.tapIndex===2||r.tapIndex===3){const name=r.tapIndex===2;const answer=await ui.call('showModal',{title:name?'素材名称':'素材分类',editable:true,placeholderText:name?m.name:m.category});if(answer.confirm&&answer.content.trim())bench.mutate(s=>{s.materials.find(x=>x.id===m.id)[name?'name':'category']=answer.content.trim().slice(0,name?40:20);});}else if(r.tapIndex===4&&await ui.modal('删除这个素材？被拼贴引用的素材不可删除。','删除素材')){if(this.data.layers.some(l=>l.material===m.id))throw Error('当前拼贴正在使用这个素材');bench.removeMaterial(m.id);delete this.images[m.id];}this.catalog();}catch(e){if(!sharing.cancelled(e))ui.error(e);}finally{this.setData({busy:false});}},
 async share(){if(this.data.busy||!this.data.ready||!this.data.layers.length)return;this.setData({busy:true});try{getApp().globalData.shareSource={path:await this.image(),title:this.data.collageName,kind:'collage'};await ui.call('navigateTo',{url:'/pages/share/index'});}catch(e){getApp().globalData.shareSource=null;ui.error(e);}finally{this.setData({busy:false});}},
 sharePhoto(){if(!this.data.busy){getApp().globalData.shareSource=null;wx.navigateTo({url:'/pages/share/index'});}},
 ...studio
});
