const model=require('../../core/model');
const render=require('../../core/render');
const core=require('../../core/workbench');
const bench=require('../../services/workbench');
const storage=require('../../services/storage');
const ui=require('../../services/ui');
Page({
 data:{ready:false,title:'',color:'',part:0,partNames:['整幅图纸'],colors:[],rows:[],done:0,total:0,percent:0,width:320,height:320,zoom:1,maxZoom:5,status:'正在读取制作进度'},
 onLoad(query){this.id=query.id;},
 async onReady(){try{this.project=storage.read(this.id);this.parts=model.partitions(this.project);this.canvas=(await ui.node(this,'make')).node;this.setData({title:this.project.name,partNames:['整幅图纸',...this.parts.map(p=>'分区 '+p.name)],ready:true});this.refresh();}catch(e){ui.error(e);}},
 indices(row){const p=this.project,part=this.data.part?this.parts[this.data.part-1]:{x:0,y:0,columns:p.columns,rows:p.rows};return p.cells.map((id,i)=>({id,i,x:i%p.columns,y:Math.floor(i/p.columns)})).filter(c=>c.id!==null&&(!this.data.color||c.id===this.data.color)&&c.x>=part.x&&c.x<part.x+part.columns&&c.y>=part.y&&c.y<part.y+part.rows&&(row===undefined||c.y===row)).map(c=>c.i);},
 refresh(){const s=bench.load(),progress=core.progress(this.project,s),done=new Set(progress.done),total=model.stats(this.project).total;this.completed=done;
  const rows=[];for(let y=0;y<this.project.rows;y++){const indices=this.indices(y);if(indices.length)rows.push({y,label:y+1,count:indices.length,done:indices.filter(i=>done.has(i)).length,complete:indices.every(i=>done.has(i))});}
  this.setData({rows,colors:core.supply(this.project,s),done:done.size,total,percent:total?Math.round(done.size/total*100):0,status:'进度保存在本机 · 修改颜色的格子会重新变为未完成'});this.draw();
 },
 draw(){if(!this.canvas||!this.project)return;const p=this.project,windowWidth=wx.getWindowInfo().windowWidth,viewportWidth=Math.ceil(windowWidth-30),viewportHeight=Math.ceil(650*windowWidth/750);this.origin=28;const fitWidth=(viewportWidth-this.origin)/p.columns,fitHeight=(viewportHeight-this.origin)/p.rows,base=Math.max(1.5,Math.min(fitWidth,fitHeight)),maxZoom=Math.max(1,Math.min(5,Math.floor(64/base*10)/10)),zoom=Math.max(1,Math.min(this.data.zoom,maxZoom));this.cell=base*zoom;this.viewportWidth=viewportWidth;this.viewportHeight=viewportHeight;this.contentWidth=p.columns*this.cell+this.origin;this.contentHeight=p.rows*this.cell+this.origin;this.panX=Math.max(0,Math.min(this.panX||0,Math.max(0,this.contentWidth-viewportWidth)));this.panY=Math.max(0,Math.min(this.panY||0,Math.max(0,this.contentHeight-viewportHeight)));this.canvas.width=viewportWidth;this.canvas.height=viewportHeight;this.setData({width:viewportWidth,height:viewportHeight,zoom,maxZoom});const offsetX=this.origin-this.panX,offsetY=this.origin-this.panY,ctx=this.canvas.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,viewportWidth,viewportHeight);render.grid(ctx,p,{cell:this.cell,offsetX,offsetY,highlight:this.data.color||null});render.axes(ctx,p,this.cell,offsetX,offsetY);ctx.strokeStyle='#FF3F64';ctx.lineWidth=Math.max(2,this.cell/10);for(const i of this.completed){const x=offsetX+(i%p.columns)*this.cell,y=offsetY+Math.floor(i/p.columns)*this.cell;if(x+this.cell<0||y+this.cell<0||x>viewportWidth||y>viewportHeight)continue;ctx.fillStyle='#ffffffaa';ctx.fillRect(x,y,this.cell,this.cell);ctx.beginPath();ctx.moveTo(x+this.cell*.2,y+this.cell*.5);ctx.lineTo(x+this.cell*.43,y+this.cell*.75);ctx.lineTo(x+this.cell*.83,y+this.cell*.2);ctx.stroke();}},
 color(e){this.setData({color:e.currentTarget.dataset.id});this.refresh();},
 part(e){this.setData({part:Number(e.detail.value)});this.refresh();},
 applyZoom(zoom){const oldWidth=this.contentWidth||1,oldHeight=this.contentHeight||1,centerX=((this.panX||0)+(this.viewportWidth||0)/2)/oldWidth,centerY=((this.panY||0)+(this.viewportHeight||0)/2)/oldHeight;this.setData({zoom:Math.max(1,Math.min(this.data.maxZoom,zoom))},()=>{this.draw();this.panX=centerX*this.contentWidth-this.viewportWidth/2;this.panY=centerY*this.contentHeight-this.viewportHeight/2;this.draw();});},
 zoom(e){this.applyZoom(Number(e.detail.value));},
 mark(indices,complete){try{const ids=new Set(storage.list().map(p=>p.id));if(!ids.has(this.project.id))throw Error('作品已被删除，请返回作品列表');bench.mutate(s=>{for(const id of Object.keys(s.progress))if(!ids.has(id))delete s.progress[id];core.mark(this.project,s,indices,complete);});this.refresh();}catch(e){ui.error(e);}},
 row(e){const row=this.data.rows.find(r=>r.y===Number(e.currentTarget.dataset.row));if(row)this.mark(this.indices(row.y),!row.complete);},
 async range(e){const complete=e.currentTarget.dataset.complete==='yes';if(!await ui.modal(complete?'将当前颜色和分区筛选范围标记为已完成？':'清除当前筛选范围的制作进度？图纸颜色不会改变。','制作进度'))return;this.mark(this.indices(),complete);},
 touchStart(e){
  if(e.touches.length===2){const [a,b]=e.touches;this.touch=null;this.pinch={distance:Math.max(1,Math.hypot(a.x-b.x,a.y-b.y)),zoom:this.data.zoom};return;}
  if(e.touches.length===1){const t=e.touches[0];this.touch={x:t.x,y:t.y,time:Date.now(),panX:this.panX||0,panY:this.panY||0,moved:false};}
 },
 touchMove(e){
  if(e.touches.length===2){const [a,b]=e.touches;if(!this.pinch)this.pinch={distance:Math.max(1,Math.hypot(a.x-b.x,a.y-b.y)),zoom:this.data.zoom};this.touch=null;const zoom=this.pinch.zoom*Math.hypot(a.x-b.x,a.y-b.y)/this.pinch.distance;if(!this.lastPinch||Date.now()-this.lastPinch>=50){this.lastPinch=Date.now();this.applyZoom(Math.round(zoom*10)/10);}return;}
  if(!this.touch||e.touches.length!==1)return;const dx=e.touches[0].x-this.touch.x,dy=e.touches[0].y-this.touch.y;if(Math.abs(dx)+Math.abs(dy)<=8)return;this.touch.moved=true;this.panX=this.touch.panX-dx;this.panY=this.touch.panY-dy;this.draw();
 },
 touchEnd(e){
  if(e&&e.touches&&e.touches.length){this.touch=null;this.pinch=null;return;}
  const t=this.touch,wasPinching=!!this.pinch;this.touch=null;this.pinch=null;if(wasPinching||!t||t.moved||Date.now()-t.time>600)return;const x=Math.floor((t.x+(this.panX||0)-this.origin)/this.cell),y=Math.floor((t.y+(this.panY||0)-this.origin)/this.cell);if(x<0||y<0||x>=this.project.columns||y>=this.project.rows)return;const i=y*this.project.columns+x;if(this.indices().includes(i))this.mark([i],!this.completed.has(i));
 },
 stock(e){try{if(!/^\d{1,7}$/.test(e.detail.value)||Number(e.detail.value)>1000000)throw Error('库存需0—1000000的整数');bench.mutate(s=>{s.inventory[core.inventoryKey(this.project.palette,e.currentTarget.dataset.id)]=Number(e.detail.value);});this.refresh();}catch(err){ui.error(err);this.refresh();}},
 async copy(){try{const colors=core.supply(this.project,bench.load());await ui.call('setClipboardData',{data:[this.project.name,'缺料参考（色板未实物核验，不作为采购依据）',...colors.map(c=>c.id+' '+c.name+'：需 '+c.purchase+' / 库存 '+c.stock+' / 缺 '+c.missing)].join('\n')});}catch(e){ui.error(e);}}
});
