const ui=require('../../services/ui');
const sharing=require('../../services/share');
const bench=require('../../services/workbench');
const core=require('../../core/workbench');
const codec=require('../../core/codec');
const backup=require('../../services/backup');
const cloud=require('../../services/cloud-backup');
const auth=require('../../services/auth');
const demo=require('../../core/palette');
Page({
 data:{busy:false,profileName:'',boardName:'',boardColumns:29,boardRows:29,pitch:5,backupConsent:false,cloudConsent:false,cloudAvailable:false,cloudItems:[],cloudNames:[],file:null,localFiles:[],status:'备份前请确认有足够的手机空间',materials:0,collages:0,account:{loggedIn:false,accountLabel:'未登录'}},
 onLoad(){this.off=auth.subscribe(account=>{this.update(account.loggedIn?{account}:{account,cloudItems:[],cloudNames:[],cloudConsent:false});});},
 account(){wx.switchTab({url:'/pages/account/index'});},
 onShow(){if(!this.data.busy)try{this.reload();}catch(e){ui.error(e);}},
 reload(){const s=bench.load();this.setData({materials:s.materials.length,collages:s.collages.length,profileName:s.profile?s.profile.brand+' / '+s.profile.series:'演示色板（不可采购）',boardName:s.board.name,boardColumns:s.board.columns,boardRows:s.board.rows,pitch:s.board.pitch,cloudAvailable:cloud.available(),localFiles:backup.localFiles()});},
 update(value){if(!this.closed)this.setData(value);},
 async run(fn){if(this.data.busy)return;this.update({busy:true});try{await fn();}catch(e){if(!sharing.cancelled(e)&&!this.closed)ui.error(e);}finally{try{this.update({localFiles:backup.localFiles()});}catch(ignore){}this.update({busy:false});}},
 field(e){if(!this.data.busy&&['boardName','boardColumns','boardRows','pitch'].includes(e.currentTarget.dataset.key))this.setData({[e.currentTarget.dataset.key]:e.detail.value});},
 backupConsent(e){if(!this.data.busy)this.setData({backupConsent:e.detail.value.includes('backup')});},
 cloudConsent(e){if(!this.data.busy)this.setData({cloudConsent:e.detail.value.includes('cloud')});},
 saveBoard(){if(this.data.busy)return;try{const value=core.board({name:this.data.boardName,columns:Number(this.data.boardColumns),rows:Number(this.data.boardRows),pitch:Number(this.data.pitch)});bench.mutate(s=>{s.board=value;});this.setData({status:'拼板设置已保存，只作用于下次新生成的作品；旧图纸规格不变'});}catch(e){ui.error(e);}},
 async importPalette(){await this.run(async()=>{const r=await ui.call('chooseMessageFile',{count:1,type:'file',extension:['json']});const file=r.tempFiles[0];if(!file||file.size>256*1024)throw Error('色表JSON需在256KiB以内');const value=core.profile(codec.parse(wx.getFileSystemManager().readFileSync(file.path,'utf8')));if(!await ui.modal('导入 '+value.brand+' / '+value.series+'，共'+value.colors.length+'色？该色表尚未实物核验，只用于下次生成。','导入个人色表'))return;bench.mutate(s=>{s.profile=value;});this.reload();this.update({status:'个人色表已导入，仍标为未核验；请用实物核验后再用于制作'});});},
 async resetPalette(){if(this.data.busy)return;if(await ui.modal('恢复演示色板？已有作品、库存和个人色表对应的旧作品保持不变。','恢复演示设置'))try{bench.mutate(s=>{s.profile=null;s.board={...demo.board};});this.reload();}catch(e){ui.error(e);}},
 async build(){if(!this.data.backupConsent)return ui.error(Error('请先确认备份包含工作照片与个人素材'));await this.run(async()=>{const file=await backup.build(status=>this.update({status}));this.update({file,status:'完整备份已生成，请保存到文件传输助手或电脑；仅留在本机仍会随微信数据清理而丢失'});});},
 async sendFile(e){if(this.data.busy)return;if(!this.data.backupConsent)return ui.error(Error('请先确认完整备份包含照片和个人素材'));const path=e.currentTarget.dataset.path||(this.data.file&&this.data.file.path);if(!path)return;await this.run(async()=>{if(typeof wx.shareFileMessage!=='function')throw Error('当前微信不支持文件分享，请使用手机新版微信');await backup.audit(path,status=>this.update({status}));await ui.call('shareFileMessage',{filePath:path,fileName:'拾豆成画完整备份-'+Date.now()+'.douge'});this.update({status:'备份内容已通过安全校验；请在微信中确认保存，应用无法确认是否送达'});});},
 async deleteLocal(e){if(this.data.busy)return;const path=e.currentTarget.dataset.path;if(!await ui.modal('确认已保存到外部或不再需要？只删除这份本机备份文件，不删除作品、素材或云备份。','清理本机备份'))return;await this.run(async()=>{backup.deleteLocal(path);if(this.data.file&&this.data.file.path===path)this.update({file:null});this.update({status:'已清理选中的本机备份副本'});});},
 async restoreFile(){await this.run(async()=>{const r=await ui.call('chooseMessageFile',{count:1,type:'file',extension:['douge']});const file=r.tempFiles[0];if(!file||file.size>backup.MAX)throw Error('备份不能超过128MiB');await this.restore(file.path);});},
 async restore(path){const {manifest:m}=backup.inspect(path);if(!await ui.modal('包含'+m.works.length+'件作品、'+m.state.materials.length+'份素材、'+m.state.collages.length+'份拼贴，以及进度与库存。将新增独立副本，不覆盖旧内容；同色库存保留本机数量。','恢复完整备份'))return;const result=await backup.restore(path,status=>this.update({status}));this.reload();this.update({status:'已恢复 '+result.works+' 件作品、'+result.materials+' 份素材、'+result.collages+' 份拼贴；现有内容保留'});},
 async cloudList(){await this.run(async()=>{const cloudItems=await cloud.list(this.data.cloudConsent);this.update({cloudItems,cloudNames:cloudItems.map(c=>c.name+(c.status==='deleting'?'（待删除）':'')),status:'已读取本人云备份'});});},
 async cloudUpload(){if(!this.data.backupConsent||!this.data.cloudConsent)return ui.error(Error('请确认完整备份范围及云上传'));await this.run(async()=>{const file=await backup.build(status=>this.update({status}));this.update({file,status:'正在上传本人私有云备份…'});await cloud.upload(file,this.data.cloudConsent);const cloudItems=await cloud.list(this.data.cloudConsent);this.update({cloudItems,status:'新的云备份已保存，旧备份未覆盖'});});},
 async cloudRestore(e){await this.run(async()=>{const path=await cloud.download(e.currentTarget.dataset.id,this.data.cloudConsent);await this.restore(path);});},
 async cloudDelete(e){if(this.data.busy)return;if(!await ui.modal('删除这份云备份？本机资料不变，删除后无法通过此快照恢复。','删除云备份'))return;await this.run(async()=>{await cloud.remove(e.currentTarget.dataset.id,this.data.cloudConsent);this.update({cloudItems:await cloud.list(this.data.cloudConsent),status:'云备份已删除'});});},
 onUnload(){this.closed=true;if(this.off)this.off();}
});
