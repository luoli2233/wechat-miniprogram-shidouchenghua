const ui=require('../../services/ui');
const sharing=require('../../services/share');
const storage=require('../../services/storage');
const creative=require('../../services/creative');
Page({
 data:{ready:false,busy:false,image:'',rawPath:'',cardPath:'',mode:'image',title:'我的创作',consent:false,works:[],workNames:[],legacy:[],legacyNames:[],status:'选择素材或作品，预览后分享给好友',needPermission:false},
 onLoad(query={}){
  this.initial=getApp().globalData.shareSource;getApp().globalData.shareSource=null;this.workId=query.id;
  try{const works=storage.list();this.setData({works,workNames:works.map(p=>p.name)});}catch(e){ui.error(e);}
  // Previous local drafts remain readable; removing the community never deletes user data.
  try{const legacy=creative.posts();this.setData({legacy,legacyNames:legacy.map(p=>p.title)});}catch(e){this.setData({status:'旧分享草稿索引无法读取，其他分享功能仍可使用'});}
 },
 update(value){if(!this.closed)this.setData(value);},
 async run(action){if(this.closed||this.data.busy||!this.canvas)return;this.update({busy:true});try{await action();}catch(e){if(sharing.cancelled(e))this.update({status:'已取消操作，原有预览保留'});else if(!this.closed)ui.error(e);}finally{this.update({busy:false});}},
 async onReady(){
  try{this.canvas=(await ui.node(this,'share')).node;this.update({ready:true});
   await this.run(async()=>{if(this.workId)await this.loadWork(this.workId);else if(this.initial){const source=this.initial;sharing.localPath(source.path);await ui.loadImage(this.canvas,source.path);this.accept(source.path,source.title||'我的素材',source.aiAssisted,source.kind==='export'?'已选择导出图纸，保持原始尺寸与标识':'已选择拼贴图片，不包含可编辑图层');}});
  }catch(e){if(!this.closed)ui.error(e);}finally{this.initial=null;}
 },
 accept(path,title,aiAssisted=false,status='图片已准备好，请确认内容后分享'){
  this.aiAssisted=aiAssisted===true;this.update({rawPath:path,image:path,cardPath:'',mode:'image',title:String(title).slice(0,40),consent:false,needPermission:false,status});
 },
 async loadWork(id){const p=storage.read(id);this.accept(await sharing.work(this.canvas,p),p.name,Boolean(p.aiStyle),'已生成最终作品图片，不包含原照片或工程数据');},
 async work(e){await this.run(async()=>{const p=this.data.works[Number(e.detail.value)];if(!p)throw Error('作品不存在，请重新选择');await this.loadWork(p.id);});},
 async legacy(e){await this.run(async()=>{const p=this.data.legacy[Number(e.detail.value)];if(!p)throw Error('旧草稿不存在');sharing.localPath(p.image);await ui.loadImage(this.canvas,p.image);this.accept(p.image,p.title,p.aiAssisted,'已读取旧分享图片，未修改或删除旧草稿');});},
 async photo(){await this.run(async()=>{const result=await ui.call('chooseMedia',{count:1,mediaType:['image'],sourceType:['album','camera'],sizeType:['original']});this.accept(await sharing.photo(this.canvas,result.tempFiles[0]),'我的素材 / 手作',false,'图片已在本机重新编码；只会分享下方预览的图片');});},
 title(e){if(this.data.busy)return;this.update({title:e.detail.value,cardPath:'',mode:'image',image:this.data.rawPath,consent:false});},
 consent(e){if(!this.data.busy)this.update({consent:e.detail.value.includes('rights')});},
 async mode(e){if(!this.data.rawPath)return;const mode=e.currentTarget.dataset.mode;if(!['image','card'].includes(mode))return;await this.run(async()=>{let cardPath=this.data.cardPath;if(mode==='card'&&!cardPath)cardPath=await sharing.card(this.canvas,this.data.rawPath,this.data.title,this.aiAssisted);this.update({mode,cardPath,image:mode==='card'?cardPath:this.data.rawPath,consent:false,status:mode==='card'?'分享卡已生成，请预览后发送':'将分享作品或素材图片'});});},
 preview(){if(this.data.image&&!this.data.busy)ui.call('previewImage',{current:this.data.image,urls:[this.data.image]}).catch(ui.error);},
 async send(){if(!this.data.image)return;await this.run(async()=>{this.update({status:'正在进行内容安全校验…'});this.update({status:await sharing.send(this.data.image,this.data.consent,this.data.title)});});},
 async save(){if(!this.data.image)return;await this.run(async()=>{try{this.update({status:'正在进行内容安全校验…'});await sharing.validate(this.data.image,this.data.title);await ui.call('saveImageToPhotosAlbum',{filePath:this.data.image});this.update({needPermission:false,status:'图片已通过内容安全校验并保存到相册'});}catch(e){if(/auth|deny|denied/i.test(e.errMsg||'')){this.update({needPermission:true,status:'未保存：请允许相册权限后重试，作品不受影响'});return;}throw e;}});},
 settings(){ui.call('openSetting').catch(ui.error);},
 onUnload(){this.closed=true;this.initial=null;}
});
