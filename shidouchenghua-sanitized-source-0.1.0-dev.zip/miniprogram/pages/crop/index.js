const ui=require('../../services/ui');
Page({
 data:{loading:true,ratio:'原比例',ratios:['原比例','1:1','3:4','4:3','自由'],size:100,hsize:100,x:50,y:50,previewWidth:300,previewHeight:300},
 async onReady(){try{
  const path=getApp().globalData.pendingImage;if(!path)throw Error('请返回首页重新选择照片');
  const info=await ui.call('getImageInfo',{src:path});if(!['jpg','jpeg','png'].includes(info.type.toLowerCase()))throw Error('请使用 JPEG 或 PNG 静态图片');if(info.width*info.height>24000000)throw Error('图片超过2400万像素，请先压缩');
  this.canvas=(await ui.node(this,'crop')).node;this.work=(await ui.node(this,'work')).node;
  const image=await ui.loadImage(this.work,path);const scale=Math.min(1,1600/Math.max(image.width,image.height));
  // Canvas image decoding normalizes EXIF on supported WeChat runtimes; explicitly
  // retain metadata for device verification rather than rotating a second time.
  this.info=info;this.image=image;this.baseW=Math.round(image.width*scale);this.baseH=Math.round(image.height*scale);this.rotation=0;this.mirror=false;
  this.setData({loading:false});this.draw();
  if(Math.min(info.width,info.height)<50)wx.showToast({title:'分辨率较低，可继续尝试',icon:'none'});
 }catch(e){this.setData({loading:false});ui.error(e);}},
 change(e){const key=e.currentTarget.dataset.key;this.setData({[key]:Number(e.detail.value)},()=>this.draw());},
 ratio(e){this.setData({ratio:e.currentTarget.dataset.value},()=>this.draw());},
 rotate(){this.rotation=(this.rotation+1)%4;this.draw();},mirror(){this.mirror=!this.mirror;this.draw();},
 draw(){if(!this.image)return;const swapped=this.rotation%2===1;const w=swapped?this.baseH:this.baseW,h=swapped?this.baseW:this.baseH;this.work.width=w;this.work.height=h;const ctx=this.work.getContext('2d');ctx.translate(w/2,h/2);ctx.rotate(this.rotation*Math.PI/2);ctx.scale(this.mirror?-1:1,1);ctx.drawImage(this.image,-this.baseW/2,-this.baseH/2,this.baseW,this.baseH);
  let ratio=w/h;if(this.data.ratio==='1:1')ratio=1;if(this.data.ratio==='3:4')ratio=3/4;if(this.data.ratio==='4:3')ratio=4/3;
  let cw=Math.min(w,h*ratio)*this.data.size/100,ch=cw/ratio;
  if(this.data.ratio==='自由'){cw=w*this.data.size/100;ch=h*this.data.hsize/100;}
  cw=Math.max(1,Math.round(cw));ch=Math.max(1,Math.round(ch));const x=Math.round((w-cw)*this.data.x/100),y=Math.round((h-ch)*this.data.y/100);this.crop={x,y,w:cw,h:ch};
  const width=Math.min(340,wx.getWindowInfo().windowWidth-48),height=Math.min(390,width*h/w),scale=Math.min(width/w,height/h),previewWidth=Math.max(1,Math.round(w*scale)),previewHeight=Math.max(1,Math.round(h*scale));
  const token=this.previewToken=(this.previewToken||0)+1;
  // Update the WXML box before resizing the 2D canvas. Resizing the native canvas
  // first can leave its visual layer at the previous position in DevTools.
  this.setData({previewWidth,previewHeight},()=>{if(token!==this.previewToken||!this.canvas)return;this.canvas.width=previewWidth;this.canvas.height=previewHeight;const p=this.canvas.getContext('2d');p.drawImage(this.work,0,0,previewWidth,previewHeight);p.fillStyle='#152b2baa';p.fillRect(0,0,previewWidth,y*scale);p.fillRect(0,(y+ch)*scale,previewWidth,(h-y-ch)*scale);p.fillRect(0,y*scale,x*scale,ch*scale);p.fillRect((x+cw)*scale,y*scale,(w-x-cw)*scale,ch*scale);p.strokeStyle='#f9e9b3';p.lineWidth=2;p.strokeRect(x*scale,y*scale,cw*scale,ch*scale);});
 },
 async confirm(){if(!this.crop||this.data.loading)return;this.setData({loading:true});try{const output=(await ui.node(this,'output')).node,c=this.crop;output.width=c.w;output.height=c.h;output.getContext('2d').drawImage(this.work,c.x,c.y,c.w,c.h,0,0,c.w,c.h);const path=await ui.temp(output);getApp().globalData.pendingSource={path,width:c.w,height:c.h,crop:c,orientation:this.info.orientation,rotation:this.rotation,mirror:this.mirror};await ui.call('redirectTo',{url:'/pages/editor/index'});}catch(e){ui.error(e);}finally{this.setData({loading:false});}}
});
