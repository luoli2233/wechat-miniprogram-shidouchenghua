const storage=require('../../services/storage');const ui=require('../../services/ui');
Page({async clear(){if(await ui.modal('这会删除所有本机作品，无法撤销。相册原图和已经导出的图片不受影响。','清空本机作品')){try{storage.clear();wx.showToast({title:'已清空',icon:'success'});}catch(e){ui.error(e);}}}});
