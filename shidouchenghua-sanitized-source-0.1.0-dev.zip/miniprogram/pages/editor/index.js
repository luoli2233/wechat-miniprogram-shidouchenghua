const model=require('../../core/model');
const {palette,board}=require('../../core/palette');
const {convertAsync}=require('../../core/quantize');
const render=require('../../core/render');
const examples=require('../../core/examples');
const storage=require('../../services/storage');
const ui=require('../../services/ui');
const bench=require('../../services/workbench');
const catalog=require('../../core/palette-catalog');
const fingerprint=require('../../core/workbench').fingerprint;
Page({
 data:{paletteChoices:[],paletteIndex:0,paletteNote:'',actualPalette:'未生成',colorWarning:catalog.warning,previewMode:false,settingsOpen:false,materialsOpen:false,ready:false,busy:false,status:'准备画布',widths:[16,32,48,64],limits:[8,12,16,24],columns:48,maxColors:16,zoom:1,maxZoom:5,mode:'browse',tool:'paint',selected:'',palette:palette.colors,colors:[],canvasWidth:320,canvasHeight:320,hasUndo:false,hasRedo:false,showOriginal:false,sourcePath:'',grid:true,highlight:'',reserve:0,reserves:[0,5,10]},
 back(){if(getCurrentPages().length>1)wx.navigateBack();else wx.switchTab({url:'/pages/home/index'});},
 viewMode(e){this.setData({previewMode:e.currentTarget.dataset.value==='preview',showOriginal:false},()=>this.draw());},
 toggleSettings(){this.setData({settingsOpen:!this.data.settingsOpen});},
 toggleMaterials(){this.setData({materialsOpen:!this.data.materialsOpen});},
 zoomStep(e){this.applyZoom(Math.round(Math.max(1,Math.min(this.data.maxZoom,this.data.zoom+Number(e.currentTarget.dataset.step)))*10)/10);},
 onLoad(query){this.workId=query.id;this.undoStack=[];this.redoStack=[];this.token=0;},
 async onReady(){try{this.canvas=(await ui.node(this,'beads')).node;this.input=(await ui.node(this,'input')).node;this.output=(await ui.node(this,'output')).node;
  if(this.workId){this.project=storage.read(this.workId);this.setupPalettes(this.project.palette);this.setData({sourcePath:this.project.sourcePath||'',columns:this.project.columns,maxColors:this.project.maxColors,reserve:this.project.reserve||0});this.refresh();this.setData({status:'已从本机恢复'});}
  else{const source=getApp().globalData.pendingSource;if(!source)throw Error('请选择图片或打开已有作品');getApp().globalData.pendingSource=null;this.sourceMeta=source;this.setupPalettes(source.palette);
   if(source.example){this.input.width=240;this.input.height=240;examples.draw(this.input.getContext('2d'),source.example,240,240);source.path=await ui.temp(this.input);}
   this.setData({sourcePath:source.path});await this.readSource();const rec=model.recommend(this.input.width,this.input.height);this.setData({columns:rec.columns,maxColors:rec.maxColors,settingsOpen:true,status:'请选择品牌色卡，再生成图纸'});this.drawSource();
  }
 }catch(e){this.setData({status:'无法打开作品'});ui.error(e);}},
 async readSource(){if(!this.data.sourcePath)throw Error('工作图片已丢失，只能编辑和导出现有网格');const image=await ui.loadImage(this.input,this.data.sourcePath);this.input.width=image.width;this.input.height=image.height;this.input.getContext('2d').drawImage(image,0,0);this.originalReady=true;},
 setupPalettes(preferred){
  const custom=bench.preferences().palette;this.paletteOptions=catalog.list(custom.id==='custom'?custom:null);
  if(preferred&&!this.paletteOptions.some(p=>fingerprint(p)===fingerprint(preferred)))this.paletteOptions.push(JSON.parse(JSON.stringify(preferred)));
  const i=preferred?this.paletteOptions.findIndex(p=>fingerprint(p)===fingerprint(preferred)):0;
  this.generationPalette=this.paletteOptions[Math.max(0,i)];
  this.setData({paletteChoices:this.paletteOptions.map(p=>p.brand+' / '+p.series),paletteIndex:Math.max(0,i),paletteNote:catalog.note(this.generationPalette)});
 },
 choosePalette(e){if(this.data.busy||this.confirming)return;const i=Number(e.detail.value);if(!Number.isInteger(i)||!this.paletteOptions[i])return;this.generationPalette=this.paletteOptions[i];this.setData({paletteIndex:i,paletteNote:catalog.note(this.generationPalette)});},
 drawSource(){if(!this.canvas||!this.input)return;const width=wx.getWindowInfo().windowWidth-80,height=540*wx.getWindowInfo().windowWidth/750;this.canvas.width=width;this.canvas.height=height;this.setData({canvasWidth:width,canvasHeight:height});const ctx=this.canvas.getContext('2d');ctx.fillStyle='#f2f5f9';ctx.fillRect(0,0,width,height);const scale=Math.min(width/this.input.width,height/this.input.height);ctx.drawImage(this.input,(width-this.input.width*scale)/2,(height-this.input.height*scale)/2,this.input.width*scale,this.input.height*scale);},
 async generate(){
  if(this.data.busy||this.confirming)return;
  const chosen=JSON.parse(JSON.stringify(this.generationPalette||bench.preferences().palette));
  const columns=this.data.columns,maxColors=this.data.maxColors,gate=this.token;
  this.confirming=true;
  try{if(!await ui.modal(chosen.brand+' / '+chosen.series+'\n'+catalog.note(chosen)+'\n\n'+catalog.warning+'\n文字、细线和渐变可能在减色后变化，请检查生成结果。'+(this.project?'\n新结果另存，保留当前作品。':''),'生成前确认'))return;}catch(e){ui.error(e);return;}finally{this.confirming=false;}
  if(gate!==this.token)return;
  if(this.project&&!this.save())return;
  this.setData({busy:true,status:'正在转换颜色…',showOriginal:false});const token=++this.token;
  try{await ui.later();await this.readSource();if(token!==this.token)return;const image=this.input.getContext('2d').getImageData(0,0,this.input.width,this.input.height);
   const preference=bench.preferences();const result=await convertAsync(image.data,this.input.width,this.input.height,columns,maxColors,chosen,()=>token!==this.token);
   if(token!==this.token)return;this.project=model.create(result,chosen,preference.board,this.data.sourcePath);this.project.sourceMeta=this.sourceMeta||null;this.undoStack=[];this.redoStack=[];this.setData({selected:''});this.refresh();this.save();
  }catch(e){if(token===this.token){ui.error(e);this.setData({status:this.project?'已保留原作品':'生成失败，请重新选图'});}}finally{if(token===this.token)this.setData({busy:false});}
 },
 cancel(){this.token++;this.setData({busy:false,status:this.project?'已取消，保留原作品':'已取消，可重新生成'});},
 width(e){if(this.data.busy)return;this.setData({columns:Number(e.currentTarget.dataset.value)});},
 limit(e){if(this.data.busy)return;this.setData({maxColors:Number(e.currentTarget.dataset.value)});},
 refresh(){if(!this.project)return;const s=model.stats(this.project);this.setData({ready:true,actualPalette:this.project.palette.brand+' / '+this.project.palette.series,actualPaletteNote:catalog.note(this.project.palette),colors:s.colors,summary:s,title:this.project.name,actualColumns:this.project.columns,rows:this.project.rows,actualColorCount:s.colors.length,selected:this.data.selected||s.colors[0]?.id||palette.colors[0].id,hasUndo:this.undoStack.length>0,hasRedo:this.redoStack.length>0,sourcePath:this.project.sourcePath||this.data.sourcePath,reserve:this.project.reserve||0,palette:this.project.palette.colors});this.draw();},
 draw(){if(!this.project||!this.canvas)return;const windowWidth=wx.getWindowInfo().windowWidth,width=windowWidth-80,viewportHeight=540*windowWidth/750;this.origin=26;const fitWidth=(width-this.origin)/this.project.columns,fitHeight=(viewportHeight-this.origin)/this.project.rows,base=Math.max(1.5,Math.min(fitWidth,fitHeight));const limit=Math.min(5,4000/(Math.max(this.project.columns,this.project.rows)*base),Math.sqrt(7500000/(this.project.columns*this.project.rows))/base),maxZoom=Math.max(1,Math.floor(limit*10)/10),zoom=Math.min(this.data.zoom,maxZoom);this.cell=base*zoom;this.viewportWidth=Math.ceil(width);this.viewportHeight=Math.ceil(viewportHeight);this.contentWidth=Math.ceil(this.project.columns*this.cell)+this.origin;this.contentHeight=Math.ceil(this.project.rows*this.cell)+this.origin;this.panX=Math.max(0,Math.min(this.panX||0,Math.max(0,this.contentWidth-this.viewportWidth)));this.panY=Math.max(0,Math.min(this.panY||0,Math.max(0,this.contentHeight-this.viewportHeight)));this.canvas.width=this.viewportWidth;this.canvas.height=this.viewportHeight;this.setData({zoom,maxZoom,canvasWidth:this.viewportWidth,canvasHeight:this.viewportHeight});const ctx=this.canvas.getContext('2d');ctx.fillStyle=this.data.showOriginal?'#F2F5F9':'#FFFFFF';ctx.fillRect(0,0,this.canvas.width,this.canvas.height);if(this.data.showOriginal&&this.input&&this.input.width&&this.input.height){const scale=Math.min(this.canvas.width/this.input.width,this.canvas.height/this.input.height),w=this.input.width*scale,h=this.input.height*scale;ctx.drawImage(this.input,(this.canvas.width-w)/2,(this.canvas.height-h)/2,w,h);return;}const offsetX=this.origin-this.panX,offsetY=this.origin-this.panY;render.grid(ctx,this.project,{cell:this.cell,offsetX,offsetY,lines:this.data.grid&&!this.data.previewMode,labels:!this.data.previewMode,highlight:this.data.highlight||null});if(!this.data.previewMode)render.axes(ctx,this.project,this.cell,offsetX,offsetY);},
 applyZoom(zoom){const oldWidth=this.contentWidth||1,oldHeight=this.contentHeight||1,centerX=((this.panX||0)+(this.viewportWidth||0)/2)/oldWidth,centerY=((this.panY||0)+(this.viewportHeight||0)/2)/oldHeight;this.setData({zoom},()=>{this.draw();this.panX=centerX*this.contentWidth-this.viewportWidth/2;this.panY=centerY*this.contentHeight-this.viewportHeight/2;this.draw();});},
 zoom(e){this.applyZoom(Number(e.detail.value));},
 mode(e){this.setData({mode:e.currentTarget.dataset.value});},
 tool(e){this.setData({tool:e.currentTarget.dataset.value,mode:'edit',showOriginal:false},()=>this.draw());},
 color(e){this.setData({selected:e.currentTarget.dataset.id,tool:'paint',mode:'edit'});},
 high(e){const id=e.currentTarget.dataset.id;this.setData({highlight:this.data.highlight===id?'':id},()=>this.draw());},
 toggleGrid(){this.setData({grid:!this.data.grid},()=>this.draw());},
 async original(){if(!this.data.sourcePath)return;try{if(!this.originalReady)await this.readSource();this.setData({showOriginal:!this.data.showOriginal},()=>this.draw());}catch(e){ui.error(e);}},
 touchStart(e){this.startTouch=e.touches.length===1?{x:e.touches[0].x,y:e.touches[0].y,time:Date.now(),panX:this.panX||0,panY:this.panY||0,moved:false}:null;if(e.touches.length===2){const [a,b]=e.touches;this.pinch={distance:Math.hypot(a.x-b.x,a.y-b.y),zoom:this.data.zoom};}},
 touchMove(e){if(e.touches.length===2&&this.pinch){this.startTouch=null;const [a,b]=e.touches,zoom=Math.max(1,Math.min(this.data.maxZoom,this.pinch.zoom*Math.hypot(a.x-b.x,a.y-b.y)/Math.max(1,this.pinch.distance)));if(!this.lastPinch||Date.now()-this.lastPinch>80){this.lastPinch=Date.now();this.applyZoom(Math.round(zoom*10)/10);}return;}if(!this.startTouch||e.touches.length!==1)return;const dx=e.touches[0].x-this.startTouch.x,dy=e.touches[0].y-this.startTouch.y;if(Math.abs(dx)+Math.abs(dy)<=8)return;if(this.data.mode==='browse'){this.startTouch.moved=true;this.panX=this.startTouch.panX-dx;this.panY=this.startTouch.panY-dy;this.draw();}else this.startTouch=null;},
 touchEnd(e){const start=this.startTouch;this.startTouch=null;this.pinch=null;if(!start||this.data.mode!=='edit'||this.data.busy||!this.project||Date.now()-start.time>600)return;
  const x=Math.floor((start.x+(this.panX||0)-this.origin)/this.cell),y=Math.floor((start.y+(this.panY||0)-this.origin)/this.cell);if(x<0||x>=this.project.columns||y<0||y>=this.project.rows)return;const index=y*this.project.columns+x;
  if(this.data.tool==='pick'){const id=this.project.cells[index];if(id)this.setData({selected:id,tool:'paint'});return;}
  try{const change=model.edit(this.project,index,this.data.tool==='erase'?null:this.data.selected);if(!change)return;this.undoStack.push(change);if(this.undoStack.length>50)this.undoStack.shift();this.redoStack=[];this.changed();}catch(e){ui.error(e);}
 },
 undo(){if(this.data.busy)return;const c=this.undoStack.pop();if(!c)return;this.project.cells[c.index]=c.before;model.touch(this.project);this.redoStack.push(c);this.changed();},
 redo(){if(this.data.busy)return;const c=this.redoStack.pop();if(!c)return;this.project.cells[c.index]=c.after;model.touch(this.project);this.undoStack.push(c);this.changed();},
 changed(){this.dirty=true;if(wx.enableAlertBeforeUnload)wx.enableAlertBeforeUnload({message:'修改尚未保存，返回可能丢失。请先保存作品。'});this.setData({status:'尚未保存'});this.refresh();clearTimeout(this.timer);this.timer=setTimeout(()=>this.save(false),800);},
 save(show=true){if(!this.project)return false;clearTimeout(this.timer);try{storage.save(this.project);this.dirty=false;if(wx.disableAlertBeforeUnload)wx.disableAlertBeforeUnload({});this.setData({status:'已保存在本机',sourcePath:this.project.sourcePath});return true;}catch(e){this.dirty=true;if(wx.enableAlertBeforeUnload)wx.enableAlertBeforeUnload({message:'作品未能保存，请先导出或清理本机历史。'});this.setData({status:'保存失败，请先清理历史或导出'});if(show)ui.error(e);return false;}},
 reserve(e){if(!this.project||this.data.busy)return;this.project.reserve=Number(e.currentTarget.dataset.value);model.touch(this.project);this.changed();},
 async rename(){if(!this.project||this.data.busy)return;const r=await ui.call('showModal',{title:'作品名称',editable:true,placeholderText:this.project.name});if(r.confirm&&r.content.trim()){this.project.name=r.content.trim().slice(0,24);model.touch(this.project);this.changed();}},
 make(){if(this.project&&!this.data.busy&&this.save())wx.navigateTo({url:'/pages/make/index?id='+encodeURIComponent(this.project.id)});},
 settings(){if(!this.data.busy)wx.navigateTo({url:'/pages/workbench/index'});},
 export(){if(!this.project||this.data.busy)return;if(!model.stats(this.project).total){ui.error(Error('请至少保留一格拼豆'));return;}this.save(false);getApp().globalData.exportProject=JSON.parse(JSON.stringify(this.project));wx.navigateTo({url:'/pages/export/index'});},
 onHide(){this.save(false);},onUnload(){this.token++;clearTimeout(this.timer);this.save(false);}
});
