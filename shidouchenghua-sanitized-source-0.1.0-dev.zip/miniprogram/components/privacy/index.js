Component({
 data:{visible:false},
 lifetimes:{detached(){(this.resolvers||[]).forEach(resolve=>resolve({event:'disagree'}));this.resolvers=[];}},
 methods:{request(resolve){this.resolvers=this.resolvers||[];this.resolvers.push(resolve);this.setData({visible:true});},agree(){const pending=this.resolvers||[];this.resolvers=[];this.setData({visible:false});pending.forEach(resolve=>resolve({event:'agree',buttonId:'privacy-agree'}));},decline(){const pending=this.resolvers||[];this.resolvers=[];this.setData({visible:false});pending.forEach(resolve=>resolve({event:'disagree'}));},contract(){wx.openPrivacyContract({fail:()=>wx.showModal({title:'隐私协议尚未配置',content:'开发预览仅本地处理照片。正式使用须由运营者在微信后台配置隐私协议；可拒绝授权并体验内置示例。',showCancel:false})});}}
});
