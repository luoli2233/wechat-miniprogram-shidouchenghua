const config=require('../cloud-config');
let initialized=null;

// Initializing the SDK does not read or upload any work or photo.
function initialize(){
 if(typeof config.env!=='string'||!/^[a-zA-Z0-9-]{4,100}$/.test(config.env))return false;
 if(typeof wx==='undefined'||!wx.cloud||typeof wx.cloud.init!=='function')return false;
 if(initialized&&initialized.api===wx.cloud&&initialized.env===config.env)return true;
 try{
  wx.cloud.init({env:config.env,traceUser:false});
  initialized={api:wx.cloud,env:config.env};
  return true;
 }catch(e){
  // Cloud failures must not prevent local creation, saving or recovery.
  initialized=null;
  return false;
 }
}

module.exports={initialize};
