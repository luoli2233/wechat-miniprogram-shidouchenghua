function call(name,args={}){return new Promise((resolve,reject)=>wx[name]({...args,success:resolve,fail:reject}));}
function modal(content,title='提示'){return call('showModal',{title,content}).then(r=>r.confirm);}
function error(e){
 let content=String(e&&(e.message||e.errMsg)||'请稍后重试');
 if(/cloud\.|errCode|errMsg|trace:|FUNCTION_NOT_FOUND|FunctionName parameter/i.test(content))content='云服务暂时不可用，请稍后重试或联系开发者';
 wx.showModal({title:'暂时无法完成',content,showCancel:false});
}
function node(page,id){return new Promise((resolve,reject)=>page.createSelectorQuery().select('#'+id).fields({node:true,size:true}).exec(r=>r[0]&&r[0].node?resolve(r[0]):reject(Error('Canvas 初始化失败，请使用支持 Canvas 2D 的微信版本'))));}
function loadImage(canvas,path){return new Promise((resolve,reject)=>{const img=canvas.createImage();img.onload=()=>resolve(img);img.onerror=()=>reject(Error('无法读取图片，请重新选择 JPEG 或 PNG'));img.src=path;});}
function temp(canvas){return call('canvasToTempFilePath',{canvas,fileType:'png',width:canvas.width,height:canvas.height,destWidth:canvas.width,destHeight:canvas.height}).then(r=>r.tempFilePath);}
function later(){return new Promise(resolve=>setTimeout(resolve,0));}
module.exports={call,modal,error,node,loadImage,temp,later};
