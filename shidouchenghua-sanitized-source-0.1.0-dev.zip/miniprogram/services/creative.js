// Local collage storage. Legacy draft helpers remain for old data compatibility;
// the community page is removed and the new sharing page never creates posts.
const materials=[
 {id:'flower',name:'郁金香',category:'花草',src:'/assets/material-flower.png'},
 {id:'heart',name:'一颗心',category:'图形',src:'/assets/material-heart.png'},
 {id:'cat',name:'小猫',category:'动物',src:'/assets/material-cat.png'}
];
const COLLAGE='douge-collage-v1',POSTS='douge-share-drafts-v1';
function validateCollage(value){
 if(!value||value.version!==1||!Array.isArray(value.layers)||value.layers.length>12)throw Error('拼贴格式错误或超过12层');
 const ids=new Set();
 return {version:1,layers:value.layers.map(l=>{
  if(!l||typeof l.id!=='string'||!l.id||ids.has(l.id)||!materials.some(m=>m.id===l.material)||typeof l.flip!=='boolean'||![0,90,180,270].includes(l.rotation)||!Number.isFinite(l.x)||l.x<0||l.x>100||!Number.isFinite(l.y)||l.y<0||l.y>100||!Number.isFinite(l.size)||l.size<10||l.size>80)throw Error('图层参数无效');
  ids.add(l.id);return {id:l.id,material:l.material,x:l.x,y:l.y,size:l.size,rotation:l.rotation,flip:l.flip};
 })};
}
function loadCollage(){require('./transaction').recover();return validateCollage(wx.getStorageSync(COLLAGE)||{version:1,layers:[]});}
function saveCollage(layers){const value=validateCollage({version:1,layers});wx.setStorageSync(COLLAGE,value);}
function root(){return wx.env.USER_DATA_PATH+'/douge-community';}
function fs(){return wx.getFileSystemManager();}
function owned(path){return typeof path==='string'&&path.startsWith(root()+'/')&&/^post-[a-z0-9-]+\.png$/.test(path.slice(root().length+1));}
function posts(){require('./transaction').recover();const list=wx.getStorageSync(POSTS)||[];if(!Array.isArray(list)||list.some(p=>!p||typeof p.id!=='string'||typeof p.title!=='string'||!owned(p.image)))throw Error('分享草稿索引损坏，请勿清空微信数据');return list;}
function unlink(path){if(owned(path))try{fs().unlinkSync(path);}catch(e){ /* Orphan files do not invalidate committed drafts. */ }}
function savePost({title,description,image,consent,aiAssisted=false}){
 if(consent!==true)throw Error('请确认图片分享权利');
 if(typeof title!=='string'||!title.trim()||title.trim().length>40||typeof description!=='string'||description.length>300)throw Error('标题需1—40字，说明最多300字');
 if(typeof image!=='string'||!image||/^https?:/i.test(image))throw Error('请先选择本机作品或照片');
 const list=posts();if(list.length>=30)throw Error('最多保存30份分享草稿');
 try{fs().accessSync(root());}catch(e){fs().mkdirSync(root(),true);}
 const size=fs().statSync(image).size;
 if(!Number.isFinite(size)||size<=0||size>6*1024*1024)throw Error('分享图片需在6MiB以内');
 const used=fs().readdirSync(root()).reduce((sum,name)=>sum+fs().statSync(root()+'/'+name).size,0);
 if(used+size>20*1024*1024)throw Error('分享草稿超过20MiB，请先删除不需要的草稿');
 const id='post-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,12),path=root()+'/'+id+'.png';
 try{fs().copyFileSync(image,path);const post={id,title:title.trim(),description:description.trim(),image:path,consent:true,aiAssisted:aiAssisted===true,status:'local-draft',updatedAt:Date.now()};wx.setStorageSync(POSTS,[post,...list]);return post;}
 catch(e){unlink(path);throw e;}
}
function removePost(id){const list=posts(),post=list.find(p=>p.id===id);wx.setStorageSync(POSTS,list.filter(p=>p.id!==id));if(post)unlink(post.image);}
module.exports={materials,validateCollage,loadCollage,saveCollage,posts,savePost,removePost};
