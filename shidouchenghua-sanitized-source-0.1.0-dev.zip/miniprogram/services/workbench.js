const core=require('../core/workbench');
const KEY='douge-workbench-v1';
const builtins=[{id:'flower'},{id:'heart'},{id:'cat'}];
function fs(){return wx.getFileSystemManager();}
function root(){return wx.env.USER_DATA_PATH+'/douge-workbench';}
function ensure(){try{fs().accessSync(root());}catch(e){fs().mkdirSync(root(),true);}return root();}
function id(prefix){return prefix+'-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,12);}
function owned(path){return typeof path==='string'&&path.startsWith(root()+'/')&&!path.slice(root().length+1).includes('/')&&!path.includes('..');}
function unlink(path){if(owned(path))try{fs().unlinkSync(path);}catch(e){}}
function validate(value){const s=core.validate(value,builtins);if(s.materials.some(m=>!owned(m.src)))throw Error('个人素材路径不属于工作台');return s;}
function read(path){return validate(JSON.parse(fs().readFileSync(path,'utf8')));}
function recoverState(missing){
 let names=[];try{names=fs().readdirSync(ensure());}catch(e){}
 const candidates=names.filter(name=>/^state-[a-z0-9-]+\.json$/.test(name)).map(name=>root()+'/'+name).filter(path=>path!==missing).sort().reverse();
 for(const path of candidates)try{const state=read(path);wx.setStorageSync(KEY,path);return state;}catch(e){}
 wx.removeStorageSync(KEY);return core.empty();
}
function load(){require('./transaction').recover();const file=wx.getStorageSync(KEY);if(!file)return core.empty();if(!owned(file))throw Error('工作台索引损坏，请先备份');try{fs().accessSync(file);}catch(e){return recoverState(file);}return read(file);}
function stage(value){const s=validate(value),path=ensure()+'/'+id('state')+'.json';const data=JSON.stringify(s);if(data.length>4000000)throw Error('工作台数据超过安全容量，请减少旧进度或库存');try{fs().writeFileSync(path,data,'utf8');return path;}catch(e){unlink(path);throw e;}}
function save(value){const old=wx.getStorageSync(KEY),path=stage(value);try{wx.setStorageSync(KEY,path);}catch(e){unlink(path);throw e;}if(old!==path)unlink(old);return value;}
function mutate(fn){const s=load();const result=fn(s);save(s);return result;}
function catalog(builtinMaterials){return [...builtinMaterials,...load().materials];}
function addMaterial(path,name,category='我的素材'){
 const s=load();if(s.materials.length>=50)throw Error('个人素材最多50份');
 const size=fs().statSync(path).size;if(!Number.isFinite(size)||size<=0||size>6*1024*1024)throw Error('单个素材需在6MiB以内');
 const used=s.materials.reduce((sum,m)=>sum+fs().statSync(m.src).size,0);if(used+size>30*1024*1024)throw Error('个人素材总量超过30MiB');
 const material={id:id('mat'),name,category,favorite:false};material.src=ensure()+'/'+material.id+'.png';
 try{fs().copyFileSync(path,material.src);s.materials.push(material);save(s);return material;}catch(e){unlink(material.src);throw e;}
}
function removeMaterial(id){const s=load(),m=s.materials.find(m=>m.id===id);if(!m)return;if(s.collages.some(c=>c.layers.some(l=>l.material===id)))throw Error('素材仍被拼贴引用，请先移除对应图层或草稿');s.materials=s.materials.filter(m=>m.id!==id);save(s);unlink(m.src);}
function preferences(){const s=load();return {palette:s.profile||require('../core/palette').palette,board:s.board};}
module.exports={KEY,builtins,root,ensure,id,owned,unlink,load,save,stage,validate,mutate,catalog,addMaterial,removeMaterial,preferences};
