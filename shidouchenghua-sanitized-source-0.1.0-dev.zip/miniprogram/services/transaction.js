const KEY='douge-restore-journal-v1';
const KEYS=['bead-studio-index-v1','douge-workbench-v1','douge-share-drafts-v1','douge-collage-v1'];
function owned(path){const root=wx.env.USER_DATA_PATH;return typeof path==='string'&&[root+'/bead-studio/',root+'/douge-workbench/',root+'/douge-community/'].some(prefix=>path.startsWith(prefix)&&/^[a-z0-9-]+\.(png|json)$/.test(path.slice(prefix.length)));}
function unlink(path){if(owned(path))try{wx.getFileSystemManager().unlinkSync(path);}catch(e){}}
function recover(){
 const path=wx.getStorageSync(KEY);if(!path)return;
 if(!owned(path))throw Error('恢复日志损坏，请保留应用数据并联系开发者');
 const journal=JSON.parse(wx.getFileSystemManager().readFileSync(path,'utf8'));
 if(!journal||!Array.isArray(journal.old)||journal.old.length!==KEYS.length||journal.old.some((v,i)=>v.key!==KEYS[i])||!Array.isArray(journal.files)||journal.files.some(p=>!owned(p)))throw Error('恢复日志无效，已停止数据写入');
 for(const item of journal.old)wx.setStorageSync(item.key,item.value);
 wx.removeStorageSync(KEY);for(const file of journal.files)unlink(file);unlink(path);
}
function commit(values,files){
 recover();const fs=wx.getFileSystemManager(),path=wx.env.USER_DATA_PATH+'/douge-workbench/restore-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,10)+'.json';
 const old=KEYS.map(key=>({key,value:wx.getStorageSync(key)||''}));fs.writeFileSync(path,JSON.stringify({old,files}),'utf8');
 try{wx.setStorageSync(KEY,path);}catch(e){unlink(path);throw e;}
 try{for(const key of KEYS)wx.setStorageSync(key,values[key]);wx.removeStorageSync(KEY);unlink(path);}catch(e){try{recover();}catch(rollback){throw Error('恢复中断，回滚未完成。请勿清理微信数据；下次打开会重试恢复。');}throw e;}
}
module.exports={KEY,KEYS,owned,unlink,recover,commit};
