const ui=require('./ui');
const model=require('../core/model');
const render=require('../core/render');
const security=require('./security');

function localPath(path){
 if(typeof path!=='string'||!path||path.startsWith('//')||/(^|\/)\.\.(\/|$)/.test(path))throw Error('请选择本机图片');
 const userRoot=wx.env&&wx.env.USER_DATA_PATH;
 if(!path.startsWith('/')&&!path.startsWith('wxfile://')&&!/^http:\/\/(tmp|usr)\//.test(path)&&!(userRoot&&path.startsWith(userRoot+'/')))throw Error('分享仅支持本机图片，不接受网络地址');
 return path;
}
function cancelled(error){return /cancel/i.test(error&& (error.errMsg||error.message)||'');}
async function validate(path,title=''){
 localPath(path);
 await security.image(path);
 if(String(title).trim())await security.text(title);
 return true;
}
async function send(path,consent,title=''){
 if(consent!==true)throw Error('请先确认图片分享权利及个人信息');
 await validate(path,title);
 if(typeof wx.showShareImageMenu!=='function'||(wx.canIUse&&!wx.canIUse('showShareImageMenu'))){
  await ui.call('previewImage',{current:path,urls:[path]});
  return '当前微信不支持直接分享菜单，请在大图中长按发送；也可保存相册后发送。';
 }
 try{
  // Never attach a local work ID or temporary path as a recipient page link.
  await ui.call('showShareImageMenu',{path,needShowEntrance:false});
  return '分享菜单已调用，请在微信中选择好友并确认；应用无法确认是否送达。';
 }catch(error){
  if(cancelled(error))return '已取消分享，图片仍可预览或重新分享。';
  throw Error('微信未能打开图片分享菜单。请在手机微信重试，或保存相册后手动发送。');
 }
}
async function photo(canvas,file){
 if(!file||!Number.isFinite(file.size)||file.size<=0||file.size>20*1024*1024)throw Error('请选择20MB以内的图片');
 localPath(file.tempFilePath);
 const info=await ui.call('getImageInfo',{src:file.tempFilePath});
 if(!['png','jpg','jpeg'].includes(String(info.type).toLowerCase())||!Number.isFinite(info.width)||!Number.isFinite(info.height)||info.width<=0||info.height<=0||info.width*info.height>24000000)throw Error('仅支持2400万像素以内的JPEG/PNG');
 const image=await ui.loadImage(canvas,file.tempFilePath),scale=Math.min(1,1200/Math.max(image.width,image.height));
 canvas.width=Math.max(1,Math.round(image.width*scale));canvas.height=Math.max(1,Math.round(image.height*scale));
 const ctx=canvas.getContext('2d');ctx.clearRect(0,0,canvas.width,canvas.height);ctx.drawImage(image,0,0,canvas.width,canvas.height);
 return ui.temp(canvas);
}
async function work(canvas,project){
 model.validate(project);
 if(!model.stats(project).total)throw Error('空白作品暂不能分享，请至少保留一格拼豆');
 canvas.width=1200;canvas.height=1280;
 const ctx=canvas.getContext('2d');ctx.fillStyle='#FFFFFF';ctx.fillRect(0,0,1200,1280);
 const cell=Math.min(1120/project.columns,1120/project.rows);
 // Draw the final grid only. Never read or include the private source photo.
 render.grid(ctx,project,{cell,labels:false,lines:false,offsetX:(1200-cell*project.columns)/2,offsetY:(1200-cell*project.rows)/2});
 ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillStyle='#636366';ctx.font='24px sans-serif';
 ctx.fillText('拾豆成画 · 拼豆作品展示 · 演示色号不用于采购',600,1230);
 return ui.temp(canvas);
}
async function card(canvas,path,title,aiAssisted=false){
 localPath(path);const image=await ui.loadImage(canvas,path);
 canvas.width=900;canvas.height=1120;const ctx=canvas.getContext('2d');
 ctx.fillStyle='#EBEEF4';ctx.fillRect(0,0,900,1120);ctx.textAlign='left';ctx.textBaseline='top';
 ctx.fillStyle='#1C1C1E';ctx.font='bold 32px sans-serif';ctx.fillText('拾豆成画 · 把喜欢分享给你',48,42);
 ctx.fillStyle='#FFFFFF';ctx.fillRect(40,108,820,800);
 const scale=Math.min(772/image.width,752/image.height);ctx.drawImage(image,450-image.width*scale/2,508-image.height*scale/2,image.width*scale,image.height*scale);
 ctx.fillStyle='#1C1C1E';ctx.font='bold 28px sans-serif';const chars=Array.from(String(title).trim()||'我的创作').slice(0,40);
 ctx.fillText(chars.slice(0,20).join(''),48,942);ctx.fillText(chars.slice(20).join(''),48,982);
 ctx.fillStyle='#636366';ctx.font='21px sans-serif';ctx.fillText('素材与作品 · 分享创作的快乐',48,1052);
 return ui.temp(canvas);
}
module.exports={localPath,cancelled,validate,send,photo,work,card};
