const cloud=require('./cloud');
const config=require('../cloud-config');
const MAX=1024*1024;

function rejected(message='图片可能包含不适宜内容，已停止处理，请更换图片'){
 const error=Error(message);error.code='CONTENT_REJECTED';return error;
}
async function call(data){
 if(!cloud.initialize())throw Error('内容安全服务暂不可用，请联网后重试');
 let response;
 try{response=await wx.cloud.callFunction({name:'dougeSecurity',data,config:{env:config.env}});}
 catch(error){
  const detail=String(error&&(error.errMsg||error.message)||'');
  if(/-5010001|FUNCTION_NOT_FOUND|FunctionName parameter could not be found/i.test(detail))throw Error('内容安全服务尚未部署，请联系开发者完成配置后重试');
  throw Error('内容安全服务连接失败，请检查网络后重试');
 }
 const result=response&&response.result;
 if(!result||result.pass!==true){
  if(result&&result.risky)throw rejected(data.action==='text'?'文字可能包含不适宜内容，请修改后重试':undefined);
  if(result&&result.reason==='permission_not_ready')throw Error('内容安全接口权限正在生效，请约10分钟后重试');
  if(result&&result.reason==='account_permission')throw Error('小程序暂未获得内容安全接口权限，请联系管理员检查公众平台配置');
  if(result&&result.reason==='service_error')throw Error('微信内容安全服务暂时异常，请稍后重试');
  throw Error('内容安全校验未完成，请稍后重试');
 }
 return true;
}
async function image(filePath){
 if(!cloud.initialize())throw Error('内容安全服务暂不可用，请联网后重试');
 const fileInfo=path=>new Promise((resolve,reject)=>wx.getFileSystemManager().getFileInfo({filePath:path,success:resolve,fail:reject}));
 let path=filePath,info=await fileInfo(path);
 if(info.size>MAX&&typeof wx.compressImage==='function'){
  const output=await wx.compressImage({src:filePath,quality:30});path=output.tempFilePath;
  info=await fileInfo(path);
 }
 if(info.size>MAX)throw Error('图片过大，无法完成内容安全校验，请先压缩到1MB以内');
 const cloudPath='security-check/'+Date.now()+'-'+Math.random().toString(36).slice(2)+'.jpg';
 const uploaded=await wx.cloud.uploadFile({cloudPath,filePath:path});
 try{return await call({action:'image',fileID:uploaded.fileID});}
 finally{try{await wx.cloud.deleteFile({fileList:[uploaded.fileID]});}catch(ignore){}}
}
function text(content){return call({action:'text',content:String(content||'').slice(0,500)});}
module.exports={image,text,rejected};
