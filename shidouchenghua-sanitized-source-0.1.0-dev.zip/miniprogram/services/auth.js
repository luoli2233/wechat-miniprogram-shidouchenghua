const config=require('../cloud-config');
const cloud=require('./cloud');
const KEY='douge-auth-preference-v1';
const listeners=new Set();
let session=null,pending=null,generation=0,restoreChecked=false;
let state={status:'guest',remembered:false,error:''};

function error(code,message){const e=new Error(message);e.code=code;return e;}
function validSession(){return session&&session.env===config.env&&typeof wx!=='undefined'&&session.api===wx.cloud;}
function snapshot(){
 const loggedIn=state.status==='authenticated'&&!!validSession();
 return {status:loggedIn?'authenticated':state.status==='authenticated'?'guest':state.status,loggedIn,busy:state.status==='logging-in'||state.status==='restoring',accountLabel:loggedIn?'微信用户 · '+session.openid.slice(-6):'未登录',remembered:loggedIn&&state.remembered,error:state.error};
}
function notify(){const value=snapshot();listeners.forEach(fn=>{try{fn(value);}catch(ignore){}});}
function subscribe(fn){listeners.add(fn);fn(snapshot());return ()=>listeners.delete(fn);}
function clearPreference(){
 try{wx.removeStorageSync(KEY);return true;}catch(ignore){
  try{wx.setStorageSync(KEY,{version:1,restore:false});return true;}catch(failed){return false;}
 }
}
function failMessage(e){
 const message=String(e&&(e.message||e.errMsg)||'');
 if(e&&e.code==='AUTH_CANCELLED')return '';
 if(e&&e.code==='AUTH_TIMEOUT')return '登录超时，请检查网络后重试；本机创作仍可使用。';
 if(/function not exists|FUNCTION_NOT_FOUND|-501000|-501005/i.test(message))return '身份云函数尚未就绪，请稍后重试。';
 if(/WECHAT_IDENTITY_REQUIRED|AUTH_INVALID/i.test(message))return '未能核验微信身份，请用已登录微信的真机重试。';
 if(e&&e.code==='CLOUD_UNAVAILABLE')return '云开发暂不可用，请检查微信版本和网络；本机创作仍可使用。';
 return '登录未完成，请检查网络后重试；本机作品不受影响。';
}
function begin(remember,restoring){
 if(pending)return pending.promise;
 session=null;state={status:restoring?'restoring':'logging-in',remembered:false,error:''};
 const epoch=++generation,env=config.env,api=typeof wx==='undefined'?null:wx.cloud;
 const request={promise:null,cancel:null};
 pending=request;notify();
 request.promise=new Promise((resolve,reject)=>{
  let finished=false;
  const timer=setTimeout(()=>finish(error('AUTH_TIMEOUT','登录超时')),15000);
  function finish(failure,result){
   if(finished)return;finished=true;clearTimeout(timer);
   if(pending===request)pending=null;
   if(epoch!==generation)return reject(error('AUTH_CANCELLED','登录已取消'));
   if(env!==config.env||api!==(typeof wx==='undefined'?null:wx.cloud)){session=null;state={status:'guest',remembered:false,error:'登录环境已变化，请重新登录。'};notify();return reject(error('AUTH_CANCELLED','登录环境已变化'));}
   if(failure){session=null;clearPreference();state={status:'guest',remembered:false,error:failMessage(failure)};notify();return reject(failure);}
   if(!result||typeof result.openid!=='string'||!/^[-_a-zA-Z0-9]{1,128}$/.test(result.openid)){
    session=null;clearPreference();state={status:'guest',remembered:false,error:'未能核验微信身份，请稍后重试。'};notify();return reject(error('AUTH_INVALID','未能核验微信身份'));
   }
   session={openid:result.openid,env,api,epoch};
   let remembered=false,warning='';
   if(remember){try{wx.setStorageSync(KEY,{version:1,env,restore:true});remembered=true;}catch(ignore){clearPreference();warning='已登录，但未能记住登录选择；下次打开请重新登录。';}}
   else if(!clearPreference())warning='已登录，但未能清除之前的登录记忆，请检查微信存储空间。';
   state={status:'authenticated',remembered,error:warning};notify();resolve(snapshot());
  }
  request.cancel=()=>{if(!finished){finished=true;clearTimeout(timer);reject(error('AUTH_CANCELLED','登录已取消'));}};
  Promise.resolve().then(()=>{
   if(finished||epoch!==generation)return;
   if(!cloud.initialize()||!api||typeof api.callFunction!=='function')throw error('CLOUD_UNAVAILABLE','云开发不可用');
   return api.callFunction({name:'dougeIdentity',config:{env},data:{}});
  }).then(value=>{if(!finished)finish(null,value&&value.result);},e=>finish(e));
 });
 return request.promise;
}
function login(consent,remember=true){
 if(consent!==true)return Promise.reject(error('AUTH_CONSENT','请先阅读并同意登录说明'));
 restoreChecked=true;
 if(snapshot().loggedIn)return Promise.resolve(snapshot());
 return begin(remember===true,false);
}
function restore(){
 if(restoreChecked)return pending?pending.promise.catch(()=>snapshot()):Promise.resolve(snapshot());
 restoreChecked=true;
 let preference;try{preference=wx.getStorageSync(KEY);}catch(ignore){return Promise.resolve(snapshot());}
 // A local preference can request a fresh check; it can never authenticate a user.
 if(!preference||preference.version!==1||preference.restore!==true||preference.env!==config.env)return Promise.resolve(snapshot());
 return begin(true,true).catch(()=>snapshot());
}
function logout(){
 ++generation;restoreChecked=true;session=null;
 const request=pending;pending=null;if(request&&request.cancel)request.cancel();
 const cleared=clearPreference();
 state={status:'guest',remembered:false,error:cleared?'':'本次已退出，但未能清除登录记忆；重新打开时可能再次核验微信身份。'};
 notify();return snapshot();
}
function requireIdentity(){
 if(!snapshot().loggedIn)throw error('AUTH_REQUIRED','请先在“我的账号”中登录微信');
 return {openid:session.openid,env:session.env,generation:session.epoch};
}
function assertCurrent(ticket){
 if(!snapshot().loggedIn||!ticket||ticket.generation!==session.epoch||ticket.env!==session.env||ticket.openid!==session.openid)throw error('AUTH_REQUIRED','登录状态已改变，请重新操作');
}
module.exports={KEY,snapshot,subscribe,login,restore,logout,requireIdentity,assertCurrent};
