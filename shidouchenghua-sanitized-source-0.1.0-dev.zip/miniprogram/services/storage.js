const {validate,stats}=require('../core/model');
const KEY='bead-studio-index-v1';
function fs(){return wx.getFileSystemManager();}
function directory(){const path=wx.env.USER_DATA_PATH+'/bead-studio';try{fs().accessSync(path);}catch(e){fs().mkdirSync(path,true);}return path;}
function owned(path){const root=directory();return typeof path==='string'&&path.startsWith(root+'/')&&!path.slice(root.length+1).includes('/')&&/^[a-z0-9-]+\.json$/.test(path.slice(root.length+1));}
function readFile(path){if(!owned(path))throw Error('作品索引包含非法路径');return validate(JSON.parse(fs().readFileSync(path,'utf8')));}
function item(project,file){const s=stats(project);return {id:project.id,name:project.name,updatedAt:project.updatedAt,columns:project.columns,rows:project.rows,total:s.total,colors:s.colors.length,file,sourcePath:project.sourcePath};}
function repair(items){
 const root=directory();let names=[];try{names=fs().readdirSync(root).filter(name=>/^[a-z0-9-]+\.json$/.test(name)).sort().reverse();}catch(e){}
 let changed=false;const result=[];
 for(const current of items){if(!current||typeof current.id!=='string'||!owned(current.file))throw Error('历史索引损坏，请勿清理应用数据，联系开发人员恢复');let project=null,file=current.file;try{project=readFile(file);}catch(e){for(const name of names){const candidate=root+'/'+name;try{const value=readFile(candidate);if(value.id===current.id&&(!project||value.updatedAt>project.updatedAt)){project=value;file=candidate;}}catch(ignore){}}}
  if(project){const normalized=item(project,file);result.push(normalized);if(JSON.stringify(normalized)!==JSON.stringify(current))changed=true;}else changed=true;
 }
 if(changed)wx.setStorageSync(KEY,result);return result;
}
function list(){require('./transaction').recover();const items=wx.getStorageSync(KEY);if(!items)return [];if(!Array.isArray(items))throw Error('历史索引损坏，请勿清理应用数据，联系开发人员恢复');return repair(items);}
function safeUnlink(path){if(!path)return;try{fs().unlinkSync(path);}catch(e){}}
function usage(){const root=directory();return fs().readdirSync(root).reduce((sum,name)=>{try{return sum+fs().statSync(root+'/'+name).size;}catch(e){return sum;}},0);}
function save(project){
 validate(project);const root=directory(),items=list(),old=items.find(x=>x.id===project.id);
 if(!old&&items.length>=30)throw Error('已达30个作品上限，请先删除不需要的作品');
 const source=root+'/'+project.id+'-source.png';let newSource=false;
 const file=root+'/'+project.id+'-r'+project.revision+'-'+Date.now()+'-'+Math.random().toString(36).slice(2,10)+'.json';
 const data=JSON.parse(JSON.stringify(project));
 try{
  if(data.sourcePath&&data.sourcePath!==source){fs().copyFileSync(data.sourcePath,source);newSource=true;data.sourcePath=source;}
  fs().writeFileSync(file+'.tmp',JSON.stringify(data),'utf8');fs().renameSync(file+'.tmp',file);
  if(usage()>40*1024*1024)throw Error('本地作品超过40MiB，请先清理历史');
  const saved=item(data,file);
  wx.setStorageSync(KEY,[saved,...items.filter(x=>x.id!==saved.id)]);
  project.sourcePath=data.sourcePath;
  if(old&&old.file!==file)safeUnlink(old.file);
  return saved;
 }catch(e){safeUnlink(file+'.tmp');safeUnlink(file);if(newSource&&!old)safeUnlink(source);throw Error(e.message||'保存失败，请检查可用存储空间');}
}
function read(id){const entry=list().find(x=>x.id===id);if(!entry)throw Error('作品文件已丢失，已从列表移除，请重新选择照片');return readFile(entry.file);}
function remove(id){const items=list(),item=items.find(x=>x.id===id);wx.setStorageSync(KEY,items.filter(x=>x.id!==id));if(item){safeUnlink(item.file);safeUnlink(directory()+'/'+id+'-source.png');}}
function clear(){const items=list();wx.setStorageSync(KEY,[]);items.forEach(x=>{safeUnlink(x.file);safeUnlink(directory()+'/'+x.id+'-source.png');});}
module.exports={list,save,read,remove,clear,usage};
