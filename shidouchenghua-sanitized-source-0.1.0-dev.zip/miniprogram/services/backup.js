const codec=require('../core/codec');
const model=require('../core/model');
const core=require('../core/workbench');
const storage=require('./storage');
const bench=require('./workbench');
const creative=require('./creative');
const transaction=require('./transaction');
const ui=require('./ui');
const security=require('./security');
const MAX=128*1024*1024,MANIFEST_MAX=4*1024*1024,CHUNK=256*1024,HEADER=28;
function fs(){return wx.getFileSystemManager();}
function directory(name){const path=wx.env.USER_DATA_PATH+'/'+name;try{fs().accessSync(path);}catch(e){fs().mkdirSync(path,true);}return path;}
function read(fd,position,length){const buffer=new ArrayBuffer(length),r=fs().readSync({fd,arrayBuffer:buffer,offset:0,length,position});if(r.bytesRead!==length)throw Error('备份文件不完整');return new Uint8Array(buffer);}
function write(fd,bytes){let offset=0;while(offset<bytes.byteLength){const r=fs().writeSync({fd,data:bytes.buffer,offset:bytes.byteOffset+offset,length:bytes.byteLength-offset});if(!r.bytesWritten)throw Error('备份写入失败');offset+=r.bytesWritten;}}
async function stream(fd,position,size,consume){let crc=0xffffffff;for(let offset=0;offset<size;offset+=CHUNK){const chunk=read(fd,position+offset,Math.min(CHUNK,size-offset));crc=codec.crc(chunk,crc);if(consume)consume(chunk,offset);await ui.later();}return ((crc^0xffffffff)>>>0).toString(16).padStart(8,'0');}
function cleanProject(p){model.validate(p);if(![p.createdAt,p.updatedAt].every(t=>Number.isFinite(t)&&t>=0&&t<=8640000000000000)||![8,12,16,24].includes(p.maxColors))throw Error('作品时间或颜色参数损坏');core.board(p.board);const result={};for(const key of ['id','name','schemaVersion','algorithmVersion','revision','createdAt','updatedAt','columns','rows','maxColors','cells','palette','board','labels','reserve','aiStyle'])if(p[key]!==undefined)result[key]=core.clone(p[key]);result.sourcePath='';result.palette.verified=false;result.board.verified=false;
 if(p.sourceMeta&&typeof p.sourceMeta==='object'&&!Array.isArray(p.sourceMeta)){result.sourceMeta={};for(const key of ['width','height','crop','orientation','rotation','mirror','kind','example'])if(p.sourceMeta[key]!==undefined)result.sourceMeta[key]=core.clone(p.sourceMeta[key]);}
 if(result.palette.colors.some(c=>Object.getOwnPropertyNames(Object.prototype).includes(c.id)))throw Error('色板存在不安全的颜色编号');return model.validate(result);
}
async function build(report=()=>{}){
 transaction.recover();const sources=[],assets=[];const add=path=>{if(!path)return null;let i=sources.indexOf(path);if(i===-1){const size=fs().statSync(path).size;if(!Number.isInteger(size)||size<=0||size>32*1024*1024)throw Error('备份图片缺失或超过32MiB');i=sources.length;sources.push(path);assets.push({id:'a'+i,size,crc:''});}return assets[i].id;};
 const works=storage.list().map(item=>{const p=storage.read(item.id);return {project:cleanProject(p),source:add(p.sourcePath)};});const state=bench.load();state.materials=state.materials.map(m=>({...m,src:add(m.src)}));
 const legacy=creative.posts().map(p=>({id:p.id,title:p.title,description:p.description||'',image:add(p.image),aiAssisted:p.aiAssisted===true,consent:p.consent===true,updatedAt:p.updatedAt}));
 const legacyCollage=creative.loadCollage();const manifest={format:'douge-backup',version:2,createdAt:Date.now(),works,state,legacy,legacyCollage,assets};
 if(assets.reduce((sum,a)=>sum+a.size,0)>MAX-MANIFEST_MAX)throw Error('完整备份超过128MiB，请先整理本机资料');
 for(let i=0;i<assets.length;i++){report('校验图片 '+(i+1)+'/'+assets.length);const fd=fs().openSync({filePath:sources[i],flag:'r'});try{assets[i].crc=await stream(fd,0,assets[i].size);}finally{fs().closeSync({fd});}}
 const bytes=codec.encode(JSON.stringify(manifest));if(bytes.length>MANIFEST_MAX)throw Error('作品描述超过4MiB，无法完整备份');
 const path=directory('douge-backups')+'/'+bench.id('backup')+'.douge';let output;
 try{output=fs().openSync({filePath:path,flag:'wx'});write(output,codec.encode('DOUGE02\n'+String(bytes.length).padStart(10,'0')+'\n'+codec.checksum(bytes)+'\n'));write(output,bytes);
  for(let i=0;i<assets.length;i++){report('打包图片 '+(i+1)+'/'+assets.length);const fd=fs().openSync({filePath:sources[i],flag:'r'});try{const crc=await stream(fd,0,assets[i].size,chunk=>write(output,chunk));if(crc!==assets[i].crc)throw Error('图片在备份时发生变化，请重试');}finally{fs().closeSync({fd});}}
  fs().closeSync({fd:output});output=null;return {path,size:fs().statSync(path).size,works:works.length,materials:state.materials.length,collages:state.collages.length};
 }catch(e){if(output)try{fs().closeSync({fd:output});}catch(ignore){}try{fs().unlinkSync(path);}catch(ignore){}throw e;}
}
function validateManifest(m){
 if(!m||m.format!=='douge-backup'||m.version!==2||!Array.isArray(m.works)||m.works.length>30||!Array.isArray(m.legacy)||m.legacy.length>30||!Array.isArray(m.assets)||m.assets.length>200)throw Error('不是受支持的豆格完整备份');
 const assets=new Map(),refs=new Set(),workIds=new Set();for(const a of m.assets){if(!a||!/^a\d{1,3}$/.test(a.id)||assets.has(a.id)||!Number.isInteger(a.size)||a.size<=0||a.size>32*1024*1024||! /^[0-9a-f]{8}$/.test(a.crc))throw Error('图片目录损坏');assets.set(a.id,a);}
 const ref=id=>{if(!assets.has(id))throw Error('备份缺少图片文件');refs.add(id);return id;};
 m.works=m.works.map(w=>{const p=cleanProject(w.project);if(workIds.has(p.id))throw Error('作品ID重复');workIds.add(p.id);return {project:p,source:w.source===null?null:ref(w.source)};});
 m.state=core.validate(m.state,bench.builtins);for(const material of m.state.materials)ref(material.src);
 const posts=new Set();m.legacy=m.legacy.map(p=>{if(!p||!/^post-[a-z0-9-]+$/.test(p.id)||posts.has(p.id)||typeof p.title!=='string'||p.title.length>40||typeof p.description!=='string'||p.description.length>300)throw Error('旧分享草稿损坏');posts.add(p.id);return {...p,image:ref(p.image)};});
 m.legacyCollage=creative.validateCollage(m.legacyCollage);if(refs.size!==assets.size)throw Error('备份包含未引用文件');
 return m;
}
function inspect(path){const size=fs().statSync(path).size;if(!Number.isInteger(size)||size<HEADER||size>MAX)throw Error('备份文件需在128MiB以内');const fd=fs().openSync({filePath:path,flag:'r'});try{const header=codec.decode(read(fd,0,HEADER));if(!/^DOUGE02\n\d{10}\n[0-9a-f]{8}\n$/.test(header))throw Error('请选择.douge完整备份文件');const length=Number(header.slice(8,18));if(length<=0||length>MANIFEST_MAX||HEADER+length>size)throw Error('备份目录长度错误');const bytes=read(fd,HEADER,length);if(codec.checksum(bytes)!==header.slice(19,27))throw Error('备份目录校验失败');const manifest=validateManifest(codec.parse(codec.decode(bytes)));if(HEADER+length+manifest.assets.reduce((sum,a)=>sum+a.size,0)!==size)throw Error('备份文件长度不匹配');return {manifest,start:HEADER+length,size,path};}finally{fs().closeSync({fd});}}
function auditText(m){
 const values=[];const add=value=>{const text=String(value||'').trim();if(text)values.push(text);};
 for(const w of m.works){const p=w.project;add(p.name);add(p.palette.brand);add(p.palette.series);add(p.board.name);for(const c of p.palette.colors){add(c.id);add(c.name);}}
 if(m.state.profile){add(m.state.profile.brand);add(m.state.profile.series);for(const c of m.state.profile.colors){add(c.id);add(c.name);}}
 add(m.state.board.name);for(const item of m.state.materials){add(item.name);add(item.category);}for(const item of m.state.collages){add(item.name);if(item.paletteSnapshot){add(item.paletteSnapshot.brand);add(item.paletteSnapshot.series);for(const c of item.paletteSnapshot.colors){add(c.id);add(c.name);}}for(const layer of item.layers)if(layer.type==='text')add(layer.text);}for(const item of m.legacy){add(item.title);add(item.description);}
 const chunks=[];let current='';for(const value of [...new Set(values)])for(let offset=0;offset<value.length;offset+=400){const part=value.slice(offset,offset+400);if(current&&current.length+part.length+1>500){chunks.push(current);current='';}current+=(current?'\n':'')+part;}if(current)chunks.push(current);return chunks;
}
async function audit(path,report=()=>{}){
 const {manifest:m,start}=inspect(path),texts=auditText(m);for(let i=0;i<texts.length;i++){report('校验备份文字 '+(i+1)+'/'+texts.length);await security.text(texts[i]);}
 const root=directory('douge-security-audit'),made=[];let source;
 try{source=fs().openSync({filePath:path,flag:'r'});let position=start;for(let i=0;i<m.assets.length;i++){const asset=m.assets[i],temp=root+'/'+bench.id('audit')+'.img';made.push(temp);report('校验备份图片 '+(i+1)+'/'+m.assets.length);const output=fs().openSync({filePath:temp,flag:'wx'});try{const crc=await stream(source,position,asset.size,chunk=>write(output,chunk));if(crc!==asset.crc)throw Error('备份图片校验失败');}finally{fs().closeSync({fd:output});}await security.image(temp);fs().unlinkSync(temp);made.pop();position+=asset.size;}return true;
 }finally{if(source)try{fs().closeSync({fd:source});}catch(ignore){}for(const file of made)try{fs().unlinkSync(file);}catch(ignore){}}
}
async function restore(path,report=()=>{}){
 transaction.recover();const {manifest:m,start}=inspect(path);const old=bench.load();if(storage.list().length+m.works.length>30||old.materials.length+m.state.materials.length>50||old.collages.length+m.state.collages.length>30||creative.posts().length+m.legacy.length>30)throw Error('恢复后的数量超过上限，请先备份并整理现有资料；不会覆盖旧内容');
 const made=[],staged={},token=bench.id('import');let source;
 try{
  bench.ensure();source=fs().openSync({filePath:path,flag:'r'});let position=start;
  for(const a of m.assets){report('校验并恢复图片 '+a.id);const dest=bench.root()+'/'+token+'-'+a.id+'.png';made.push(dest);const out=fs().openSync({filePath:dest,flag:'wx'});try{let validImage=false;const crc=await stream(source,position,a.size,(chunk,offset)=>{if(offset===0){validImage=(chunk[0]===137&&chunk[1]===80&&chunk[2]===78&&chunk[3]===71&&chunk[4]===13&&chunk[5]===10&&chunk[6]===26&&chunk[7]===10)||(chunk[0]===255&&chunk[1]===216&&chunk[2]===255);if(!validImage)throw Error('备份图片格式不支持');}write(out,chunk);});if(crc!==a.crc)throw Error('备份图片校验失败');}finally{fs().closeSync({fd:out});}staged[a.id]=dest;position+=a.size;
  }fs().closeSync({fd:source});source=null;
  for(const file of Object.values(staged)){const info=await ui.call('getImageInfo',{src:file});if(!['png','jpg','jpeg'].includes(String(info.type).toLowerCase())||!Number.isFinite(info.width)||!Number.isFinite(info.height)||info.width<=0||info.height<=0||info.width*info.height>24000000)throw Error('备份图片无法读取或超过2400万像素');}
  // Read current data again after the asynchronous staging phase. Commit below is synchronous.
  const state=bench.load(),items=storage.list(),posts=creative.posts(),materials=new Map(),workMap=new Map(),collageMap=new Map();
  if(items.length+m.works.length>30||state.materials.length+m.state.materials.length>50||state.collages.length+m.state.collages.length>30||posts.length+m.legacy.length>30)throw Error('本机资料数量已变化，请重新恢复');
  const copy=(asset,dest)=>{made.push(dest);fs().copyFileSync(staged[asset],dest);return dest;};
  for(const material of m.state.materials){const id=bench.id('mat');materials.set(material.id,id);state.materials.push({...material,id,src:copy(material.src,bench.root()+'/'+id+'.png')});}
  for(const c of m.state.collages){const id=bench.id('collage');collageMap.set(c.id,id);state.collages.push({...c,id,name:(c.name+' 恢复').slice(0,40),layers:c.layers.map(l=>({...l,material:materials.get(l.material)||l.material}))});}
  if(!state.activeCollage)state.activeCollage=collageMap.get(m.state.activeCollage)||state.collages[0]?.id||'';
  const workDir=directory('bead-studio');for(const w of m.works){const p=cleanProject(w.project),id=bench.id('work');workMap.set(p.id,id);p.id=id;p.name=(p.name+' 恢复').slice(0,24);p.sourcePath=w.source?copy(w.source,workDir+'/'+id+'-source.png'):'';const file=workDir+'/'+id+'-restored.json';made.push(file);fs().writeFileSync(file,JSON.stringify(p),'utf8');const stats=model.stats(p);items.push({id,name:p.name,updatedAt:p.updatedAt,columns:p.columns,rows:p.rows,total:stats.total,colors:stats.colors.length,file,sourcePath:p.sourcePath});}
  for(const [id,p] of Object.entries(m.state.progress))if(workMap.has(id))state.progress[workMap.get(id)]=p;
  for(const [key,qty] of Object.entries(m.state.inventory))if(!Object.prototype.hasOwnProperty.call(state.inventory,key))state.inventory[key]=qty;
  if(!wx.getStorageSync(bench.KEY)){state.profile=m.state.profile;state.board=m.state.board;}
  const postDir=directory('douge-community');for(const p of m.legacy){const id=bench.id('post');posts.push({id,title:p.title,description:p.description,image:copy(p.image,postDir+'/'+id+'.png'),aiAssisted:p.aiAssisted===true,consent:p.consent===true,status:'local-draft',updatedAt:Number(p.updatedAt)||Date.now()});}
  if(storage.usage()>40*1024*1024||state.materials.reduce((n,m)=>n+fs().statSync(m.src).size,0)>30*1024*1024||posts.reduce((n,p)=>n+fs().statSync(p.image).size,0)>20*1024*1024)throw Error('恢复后的资料超过本地容量预算');
  const stateFile=bench.stage(state);made.push(stateFile);const legacy=wx.getStorageSync('douge-collage-v1')||m.legacyCollage;
  transaction.commit({'bead-studio-index-v1':items,[bench.KEY]:stateFile,'douge-share-drafts-v1':posts,'douge-collage-v1':legacy},made);
  for(const file of Object.values(staged))bench.unlink(file);
  return {works:m.works.length,materials:m.state.materials.length,collages:m.state.collages.length};
 }catch(e){if(source)try{fs().closeSync({fd:source});}catch(ignore){}if(!wx.getStorageSync(transaction.KEY))for(const file of made)transaction.unlink(file);throw e;}
}
function localFiles(){const root=directory('douge-backups');return fs().readdirSync(root).filter(name=>/^backup-[a-z0-9-]+\.douge$/.test(name)).sort().reverse().map(name=>({path:root+'/'+name,name,size:Math.ceil(fs().statSync(root+'/'+name).size/1024),date:new Date(parseInt(name.split('-')[1],36)).toLocaleString()}));}
function deleteLocal(path){const root=directory('douge-backups')+'/';if(typeof path!=='string'||!path.startsWith(root)||!/^backup-[a-z0-9-]+\.douge$/.test(path.slice(root.length)))throw Error('只能删除本应用生成的本机备份');fs().unlinkSync(path);}
module.exports={build,inspect,audit,restore,validateManifest,localFiles,deleteLocal,MAX};
