const config=require('../cloud-config');
const bench=require('./workbench');
const runtime=require('./cloud');
const auth=require('./auth');
function available(){return config.enabled===true&&config.privacyReady===true&&typeof config.env==='string'&&/^[a-zA-Z0-9-]{4,100}$/.test(config.env);}
function account(consent){
 if(consent!==true)throw Error('请先明确同意云备份上传');if(!available())throw Error('云环境与私有权限尚未配置，当前可使用本地完整备份');
 if(!runtime.initialize())throw Error('云开发初始化失败，请检查微信版本与云环境配置');
 return auth.requireIdentity();
}
async function listFor(ticket){auth.assertCurrent(ticket);const r=await wx.cloud.database().collection('douge_backups').where({_openid:ticket.openid}).orderBy('createdAt','desc').limit(20).get();auth.assertCurrent(ticket);return r.data;}
async function list(consent){return listFor(account(consent));}
function ownFile(record,owner){if(!record||record._openid!==owner||!/^backup-[a-z0-9-]+$/.test(record._id)||typeof record.fileID!=='string'||!record.fileID.startsWith('cloud://'+config.env+'.')||!record.fileID.endsWith('/backups/'+owner+'/'+record._id+'.douge'))throw Error('备份文件不属于当前账号或环境');return record;}
async function record(id,ticket){auth.assertCurrent(ticket);if(!/^backup-[a-z0-9-]+$/.test(id))throw Error('备份编号错误');const r=await wx.cloud.database().collection('douge_backups').where({_id:id,_openid:ticket.openid}).get();auth.assertCurrent(ticket);return ownFile(r.data[0],ticket.openid);}
async function upload(file,consent){
 const ticket=account(consent),owner=ticket.openid;if((await listFor(ticket)).length>=5)throw Error('当前保留5份云备份，请先删除不需要的备份');
 const id=bench.id('backup'),cloudPath='backups/'+owner+'/'+id+'.douge';const result=await wx.cloud.uploadFile({cloudPath,filePath:file.path});
 auth.assertCurrent(ticket);const data={fileID:result.fileID,size:file.size,createdAt:Date.now(),name:'完整备份 '+new Date().toLocaleString(),status:'ready'};
 // Unique immutable snapshot: never replace the user's previous cloud backup.
 try{await wx.cloud.database().collection('douge_backups').doc(id).set({data});}
 catch(e){try{const r=await record(id,ticket);if(r.fileID===result.fileID)return r;}catch(ignore){}throw Error('图片文件已上传，但云端记录未能确认。旧备份不受影响，请检查云控制台后再重试，避免重复占用容量。');}
 auth.assertCurrent(ticket);return {_id:id,_openid:owner,...data};
}
async function download(id,consent){const ticket=account(consent),r=await record(id,ticket);if(r.status!=='ready')throw Error('此备份正在删除，不能恢复');const file=await wx.cloud.downloadFile({fileID:r.fileID});auth.assertCurrent(ticket);return file.tempFilePath;}
async function remove(id,consent){const ticket=account(consent),r=await record(id,ticket),doc=wx.cloud.database().collection('douge_backups').doc(id);await doc.update({data:{status:'deleting'}});auth.assertCurrent(ticket);const result=await wx.cloud.deleteFile({fileList:[r.fileID]});auth.assertCurrent(ticket);if(result.fileList.some(f=>f.status!==0))throw Error('云文件清理失败，记录已保留为待删除，请重试');await doc.remove();auth.assertCurrent(ticket);}
module.exports={available,list,upload,download,remove};
