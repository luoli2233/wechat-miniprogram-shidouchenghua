const model=require('./model');
const demo=require('./palette');
function clone(v){return JSON.parse(JSON.stringify(v));}
function integer(v,min,max){return Number.isInteger(v)&&v>=min&&v<=max;}
function text(v,max){return typeof v==='string'&&v.trim().length>0&&v.length<=max;}
function board(v){
 if(!v||!text(v.name,40)||!integer(v.columns,8,100)||!integer(v.rows,8,100)||!Number.isFinite(v.pitch)||v.pitch<1||v.pitch>20)throw Error('拼板需8—100行/列，孔距1—20毫米');
 return {name:v.name.trim(),columns:v.columns,rows:v.rows,pitch:v.pitch,verified:false};
}
function profile(v){
 if(!v||!text(v.brand,40)||!text(v.series,60)||!text(String(v.version||''),20)||!Array.isArray(v.colors)||v.colors.length<2||v.colors.length>256)throw Error('色板需品牌、系列、版本及2—256个颜色');
 const ids=new Set();const colors=v.colors.map(c=>{if(!c||!text(c.id,40)||!text(c.name,40)||!/^#[0-9a-f]{6}$/i.test(c.hex)||ids.has(c.id)||Object.getOwnPropertyNames(Object.prototype).includes(c.id)||c.id==='prototype')throw Error('色号需唯一，颜色使用#RRGGBB');ids.add(c.id);return {id:c.id,name:c.name,hex:c.hex.toLowerCase()};});
 // Imported data cannot certify itself as a physically verified brand palette.
 return {id:'custom',brand:v.brand.trim(),series:v.series.trim(),version:String(v.version),verified:false,colors};
}
function paletteSnapshot(value){if(!value)return null;if(typeof value.id!=='string'||!/^[-a-z0-9]{1,80}$/.test(value.id))throw Error('创作色卡标识无效');return {...profile(value),id:value.id};}
function fingerprint(palette){return JSON.stringify([palette.brand,palette.series,palette.version,palette.colors.map(c=>[c.id,c.hex.toLowerCase()])]);}
function inventoryKey(palette,id){return JSON.stringify([fingerprint(palette),id]);}
function supply(p,state){return model.stats(p).colors.map(c=>({...c,stock:state.inventory[inventoryKey(p.palette,c.id)]||0,missing:Math.max(0,c.purchase-(state.inventory[inventoryKey(p.palette,c.id)]||0))}));}
function progress(p,state){
 const old=state.progress[p.id];const compatible=old&&old.columns===p.columns&&old.rows===p.rows&&old.palette===fingerprint(p.palette);
 const done=compatible?old.done.filter(i=>p.cells[i]!==null&&p.cells[i]===old.cells[i]):[];
 return {columns:p.columns,rows:p.rows,palette:fingerprint(p.palette),cells:p.cells.slice(),done,updatedAt:Date.now()};
}
function mark(p,state,indices,complete){
 const next=progress(p,state),done=new Set(next.done);
 for(const i of indices){if(!integer(i,0,p.cells.length-1))throw Error('制作位置无效');if(p.cells[i]!==null){if(complete)done.add(i);else done.delete(i);}}
 next.done=[...done].sort((a,b)=>a-b);state.progress[p.id]=next;return next;
}
function layers(items,materials){return require('./creative-editor').layers(items,materials);}
function empty(){return {version:1,materials:[],collages:[],activeCollage:'',progress:{},inventory:{},profile:null,board:{...demo.board}};}
function validate(s,builtins=[]){
 if(!s||s.version!==1||!Array.isArray(s.materials)||s.materials.length>50||!Array.isArray(s.collages)||s.collages.length>30||typeof s.activeCollage!=='string')throw Error('工作台数据格式或容量无效');
 const ids=new Set();const materials=s.materials.map(m=>{if(!m||!/^mat-[a-z0-9-]+$/.test(m.id)||ids.has(m.id)||!text(m.name,40)||!text(m.category,20)||typeof m.src!=='string'||!m.src||typeof m.favorite!=='boolean')throw Error('个人素材信息损坏');ids.add(m.id);return {id:m.id,name:m.name,category:m.category,src:m.src,favorite:m.favorite};});
 const collageIds=new Set();const collages=s.collages.map(c=>{if(!c||!/^collage-[a-z0-9-]+$/.test(c.id)||collageIds.has(c.id)||!text(c.name,40)||!Number.isFinite(c.updatedAt))throw Error('拼贴草稿信息损坏');collageIds.add(c.id);return {id:c.id,name:c.name,updatedAt:c.updatedAt,background:c.background==='white'?'white':'transparent',paletteId:typeof c.paletteId==='string'&&c.paletteId.length<=80?c.paletteId:'',paletteSnapshot:paletteSnapshot(c.paletteSnapshot),layers:layers(c.layers,[...builtins,...materials])};});
 if(s.activeCollage&&!collageIds.has(s.activeCollage))throw Error('当前拼贴草稿不存在');
 if(!s.progress||Array.isArray(s.progress)||typeof s.progress!=='object'||Object.keys(s.progress).length>60||!s.inventory||Array.isArray(s.inventory)||typeof s.inventory!=='object'||Object.keys(s.inventory).length>2000)throw Error('进度或库存数据超出范围');
 const progressData={};for(const [id,p] of Object.entries(s.progress)){
  if(!/^work-[a-z0-9-]+$/.test(id)||!p||!model.WIDTHS.includes(p.columns)||!integer(p.rows,1,96)||typeof p.palette!=='string'||p.palette.length>100000||!Array.isArray(p.cells)||p.cells.length!==p.columns*p.rows||p.cells.some(c=>c!==null&&typeof c!=='string')||!Array.isArray(p.done)||p.done.some(i=>!integer(i,0,p.cells.length-1))||new Set(p.done).size!==p.done.length)throw Error('制作进度损坏');
  progressData[id]={columns:p.columns,rows:p.rows,palette:p.palette,cells:p.cells.slice(),done:p.done.slice(),updatedAt:Number(p.updatedAt)||0};
 }
 const inventory={};for(const [key,qty] of Object.entries(s.inventory)){let parsed;try{parsed=JSON.parse(key);}catch(e){throw Error('库存色号损坏');}if(!Array.isArray(parsed)||parsed.length!==2||parsed.some(x=>typeof x!=='string')||key.length>100000||!integer(qty,0,1000000))throw Error('库存数量需0—1000000整数');inventory[key]=qty;}
 return {version:1,materials,collages,activeCollage:s.activeCollage,progress:progressData,inventory,profile:s.profile?profile(s.profile):null,board:board(s.board)};
}
function gesture(layer,start,now,width,height,maxSize=80){
 const next={...layer};if(!start.length||!now.length||!Number.isFinite(width)||!Number.isFinite(height)||width<=0||height<=0||[...start,...now].some(p=>!Number.isFinite(p.x)||!Number.isFinite(p.y)))return next;
 const center=points=>({x:points.reduce((n,p)=>n+p.x,0)/points.length,y:points.reduce((n,p)=>n+p.y,0)/points.length});
 const a=center(start),b=center(now);next.x=Math.max(0,Math.min(100,layer.x+(b.x-a.x)/width*100));next.y=Math.max(0,Math.min(100,layer.y+(b.y-a.y)/height*100));
 if(start.length===2&&now.length===2){const distance=p=>Math.hypot(p[0].x-p[1].x,p[0].y-p[1].y);next.size=Math.max(10,Math.min(maxSize,layer.size*distance(now)/Math.max(1,distance(start))));}return next;
}
module.exports={clone,board,profile,fingerprint,inventoryKey,supply,progress,mark,layers,empty,validate,gesture};
