const WIDTHS=[16,32,48,64];
function dimensions(w,h,c){
 if(!Number.isFinite(w)||!Number.isFinite(h)||w<=0||h<=0||!WIDTHS.includes(c))throw Error('图片或宽度参数无效');
 const rows=Math.max(1,Math.round(c*h/w));
 if(rows>96||rows*c>6144)throw Error('画面过长，请选择更小的格数或重新裁剪');
 return {columns:c,rows};
}
function recommend(w,h){ for(const c of (Math.min(w,h)<96?[32,16]:[48,32,16])){try{return {...dimensions(w,h,c),maxColors:Math.min(w,h)<96?12:16};}catch(e){}}throw Error('图片比例过长，请重新裁剪'); }
function validate(p){
 if(!p||p.schemaVersion!==1||!p.palette||!Array.isArray(p.palette.colors))throw Error('作品格式不兼容');
 if(p.palette.colors.length<1||p.palette.colors.length>1000||!p.palette.colors.every(c=>c&&typeof c.name==='string')||![0,5,10].includes(p.reserve??0))throw Error('色板或采购参数损坏');
 if(typeof p.id!=='string'||!/^work-[a-z0-9-]+$/.test(p.id)||typeof p.name!=='string'||p.name.length>24||!Number.isInteger(p.revision)||p.revision<1)throw Error('作品元数据损坏');
 if(!Number.isInteger(p.columns)||!Number.isInteger(p.rows)||!WIDTHS.includes(p.columns)||p.rows<1||p.rows>96||p.columns*p.rows>6144)throw Error('作品尺寸无效');
 if(!Array.isArray(p.cells)||p.cells.length!==p.columns*p.rows)throw Error('作品网格损坏');
 const ids=p.palette.colors.map(x=>x.id);
 if(new Set(ids).size!==ids.length||p.palette.colors.some(c=>typeof c.id!=='string'||!/^#[0-9a-f]{6}$/i.test(c.hex)))throw Error('色板数据无效');
 if(p.cells.some(c=>c!==null&&!ids.includes(c)))throw Error('作品包含无法识别的色号');
 if(!p.labels||typeof p.labels!=='object')throw Error('作品缺少颜色标识');
 const used=[...new Set(p.cells.filter(c=>c!==null))];
 if(used.some(c=>!/^\d{2,}$/.test(p.labels[c]||''))||new Set(Object.values(p.labels)).size!==Object.values(p.labels).length)throw Error('颜色标识损坏');
 if(!p.board||!Number.isInteger(p.board.columns)||p.board.columns<=0||!Number.isInteger(p.board.rows)||p.board.rows<=0||!Number.isFinite(p.board.pitch)||p.board.pitch<=0)throw Error('拼板参数无效');
 return p;
}
function labelsFor(cells,old={}){const labels={...old};let next=Math.max(0,...Object.values(labels).map(Number))+1;cells.forEach(id=>{if(id!==null&&!labels[id])labels[id]=String(next++).padStart(2,'0');});return labels;}
function create(grid,palette,board,sourcePath=''){
 const now=Date.now();return validate({id:'work-'+now+'-'+Math.random().toString(36).slice(2,8),name:'我的拼豆作品',schemaVersion:1,algorithmVersion:'lab-medoid-v1',revision:1,createdAt:now,updatedAt:now,...grid,palette:JSON.parse(JSON.stringify(palette)),board:{...board},sourcePath,labels:labelsFor(grid.cells),reserve:0});
}
function stats(p,reserve=p.reserve||0){
 if(![0,5,10].includes(reserve))throw Error('采购余量无效');
 const counts={};let minX=p.columns,minY=p.rows,maxX=-1,maxY=-1;
 p.cells.forEach((id,i)=>{if(id===null)return;counts[id]=(counts[id]||0)+1;const x=i%p.columns,y=Math.floor(i/p.columns);minX=Math.min(minX,x);minY=Math.min(minY,y);maxX=Math.max(maxX,x);maxY=Math.max(maxY,y);});
 const colors=p.palette.colors.filter(c=>counts[c.id]).map(c=>({...c,label:p.labels[c.id],count:counts[c.id],purchase:Math.ceil(counts[c.id]*(100+reserve)/100)}));
 const pitch=p.board.pitch/10;
 return {colors,total:colors.reduce((a,c)=>a+c.count,0),purchase:colors.reduce((a,c)=>a+c.purchase,0),blank:p.cells.length-Object.values(counts).reduce((a,b)=>a+b,0),width:(p.columns*pitch).toFixed(1),height:(p.rows*pitch).toFixed(1),effectiveWidth:(Math.max(0,maxX-minX+1)*pitch).toFixed(1),effectiveHeight:(Math.max(0,maxY-minY+1)*pitch).toFixed(1),boardsX:Math.ceil(p.columns/p.board.columns),boardsY:Math.ceil(p.rows/p.board.rows)};
}
function edit(p,index,id){
 if(!Number.isInteger(index)||index<0||index>=p.cells.length)throw Error('格子位置无效');
 if(id!==null&&!p.palette.colors.some(c=>c.id===id))throw Error('未知色号');
 if(p.cells[index]===id)return null;
 const cells=p.cells.slice();cells[index]=id;
 const change={index,before:p.cells[index],after:id};p.cells=cells;p.labels=labelsFor(cells,p.labels);touch(p);return change;
}
function touch(p){p.revision++;p.updatedAt=Date.now();}
function partitions(p){const pages=[];for(let y=0;y<p.rows;y+=p.board.rows)for(let x=0;x<p.columns;x+=p.board.columns){pages.push({name:String.fromCharCode(65+Math.floor(x/p.board.columns))+(Math.floor(y/p.board.rows)+1),x,y,columns:Math.min(p.board.columns,p.columns-x),rows:Math.min(p.board.rows,p.rows-y)});}return pages;}
function materialText(p){const s=stats(p);return [p.name,'品牌材料参考清单',require('./palette-catalog').note(p.palette),`${p.columns}×${p.rows}格 | ${p.palette.brand} / ${p.palette.series} v${p.palette.version}`,`实际 ${s.total}颗 / 余量 ${p.reserve||0}% / 建议 ${s.purchase}颗`,...s.colors.map(c=>`${c.label} · ${c.id} ${c.name}：实际 ${c.count} / 建议 ${c.purchase}`),`名义占位 ${s.width}×${s.height}cm；有效区域 ${s.effectiveWidth}×${s.effectiveHeight}cm`,`${p.board.name}：横向${s.boardsX}×纵向${s.boardsY}块（整幅同时铺板）`,'图纸与实物可能有色差；请按品牌、系列和色号核对材料。','尺寸依配置孔距估算，不代表熨烫后尺寸。'].join('\n');}
module.exports={WIDTHS,dimensions,recommend,validate,labelsFor,create,stats,edit,touch,partitions,materialText};
