// Editable local documents. Old image-only layers remain readable.
const MAX_LAYERS=12,MAX_POINTS=6000,MAX_STROKES=120,MAX_SIZE=300;
const copy=v=>JSON.parse(JSON.stringify(v));
const number=(v,min,max)=>Number.isFinite(v)&&v>=min&&v<=max;
const color=v=>typeof v==='string'&&/^#[0-9a-f]{6}$/i.test(v);
function layers(items,materials=[]){
 if(!Array.isArray(items)||items.length>MAX_LAYERS)throw Error('一幅创作最多12层');
 const ids=new Set(),known=new Set(materials.map(m=>m.id));let points=0;
 return items.map(l=>{
  const type=l&&l.type||'image';
  if(!l||typeof l.id!=='string'||!l.id||l.id.length>80||ids.has(l.id)||!['image','text','shape','paint'].includes(type)||!number(l.x,0,100)||!number(l.y,0,100)||!number(l.size,10,MAX_SIZE)||!number(l.rotation,0,360)||typeof l.flip!=='boolean')throw Error('创作图层参数无效');
  ids.add(l.id);
  const out={id:l.id,type,x:l.x,y:l.y,size:l.size,rotation:l.rotation,flip:l.flip,hidden:l.hidden===undefined?false:l.hidden,locked:l.locked===undefined?false:l.locked,opacity:l.opacity===undefined?1:l.opacity};
  if(typeof out.hidden!=='boolean'||typeof out.locked!=='boolean'||!number(out.opacity,0,1))throw Error('图层显示参数无效');
  if(type==='image'){if(!known.has(l.material))throw Error('素材不存在');out.material=l.material;}
  if(type==='text'){
   if(typeof l.text!=='string'||!l.text.trim()||l.text.length>80||!color(l.color)||!number(l.fontSize,8,160))throw Error('文字需1—80字，字号8—160');
   Object.assign(out,{text:l.text,color:l.color,fontSize:l.fontSize});
  }
  if(type==='shape'){
   if(!['rect','circle','line'].includes(l.shape)||!color(l.color)||!number(l.lineWidth,1,40)||typeof l.fill!=='boolean')throw Error('形状参数无效');
   Object.assign(out,{shape:l.shape,color:l.color,lineWidth:l.lineWidth,fill:l.fill});
  }
  if(type==='paint'){
   if(!Array.isArray(l.strokes)||l.strokes.length>MAX_STROKES)throw Error('每个绘画层最多120笔');
   out.strokes=l.strokes.map(s=>{
    if(!s||!color(s.color)||!number(s.width,1,40)||typeof s.erase!=='boolean'||!Array.isArray(s.points)||!s.points.length||s.points.length>2000)throw Error('笔画参数无效');
    points+=s.points.length;if(points>MAX_POINTS)throw Error('当前画布笔迹过多，请另存后简化');
    return {color:s.color,width:s.width,erase:s.erase,points:s.points.map(p=>{if(!Array.isArray(p)||p.length!==2||!p.every(n=>number(n,0,512)))throw Error('笔迹位置无效');return p.slice();})};
   });
  }
  return out;
 });
}
function label(l){return l.type==='text'?l.text:l.type==='shape'?({rect:'矩形',circle:'圆形',line:'直线'})[l.shape]:l.type==='paint'?'绘画图层':'图片素材';}
function localPoint(l,x,y){
 const dx=x-l.x*5.12,dy=y-l.y*5.12,a=-l.rotation*Math.PI/180,s=l.size/100;
 return [((dx*Math.cos(a)-dy*Math.sin(a))*(l.flip?-1:1))/s+256,(dx*Math.sin(a)+dy*Math.cos(a))/s+256];
}
function bounds(l,images={}){
 if((l.type||'image')==='image'){
  const image=images[l.material];
  if(image&&Number.isFinite(image.width)&&image.width>0&&Number.isFinite(image.height)&&image.height>0){
   const ratio=Math.min(512/image.width,512/image.height);return {width:image.width*ratio,height:image.height*ratio};
  }
 }
 if(l.type==='shape'&&l.shape==='line')return {width:480,height:Math.max(24,l.lineWidth||1)};
 return {width:512,height:512};
}
function hits(items,x,y,images={}){return items.slice().reverse().filter(l=>{
 if(l.hidden||l.locked)return false;const [px,py]=localPoint(l,x,y),box=bounds(l,images),left=(512-box.width)/2,top=(512-box.height)/2;
 return px>=left&&px<=left+box.width&&py>=top&&py<=top+box.height;
});}
function hit(items,x,y,images={}){return hits(items,x,y,images)[0];}
function paint(ctx,strokes){
 ctx.clearRect(0,0,512,512);ctx.lineCap='round';ctx.lineJoin='round';
 for(const s of strokes){ctx.globalCompositeOperation=s.erase?'destination-out':'source-over';ctx.strokeStyle=s.color;ctx.fillStyle=s.color;ctx.lineWidth=s.width;
  ctx.beginPath();if(s.points.length===1){ctx.arc(s.points[0][0],s.points[0][1],s.width/2,0,Math.PI*2);ctx.fill();}else{s.points.forEach((p,i)=>i?ctx.lineTo(p[0],p[1]):ctx.moveTo(p[0],p[1]));ctx.stroke();}
 }ctx.globalCompositeOperation='source-over';
}
function draw(ctx,items,images,scratch,background='transparent'){
 ctx.clearRect(0,0,512,512);if(background!=='transparent'){ctx.fillStyle=background;ctx.fillRect(0,0,512,512);}
 for(const l of items){if(l.hidden)continue;ctx.save();ctx.globalAlpha=l.opacity===undefined?1:l.opacity;ctx.translate(l.x*5.12,l.y*5.12);ctx.rotate(l.rotation*Math.PI/180);ctx.scale(l.size/100*(l.flip?-1:1),l.size/100);
  if((l.type||'image')==='image'){
   const image=images[l.material];if(!image){ctx.restore();throw Error('素材尚未加载');}
   const ratio=Math.min(512/image.width,512/image.height),w=image.width*ratio,h=image.height*ratio;ctx.drawImage(image,-w/2,-h/2,w,h);
  }else if(l.type==='text'){
   ctx.fillStyle=l.color;ctx.textAlign='center';ctx.textBaseline='middle';ctx.font=l.fontSize+'px sans-serif';const lines=l.text.split('\n'),height=l.fontSize*1.2;
   lines.forEach((line,i)=>ctx.fillText(line,0,(i-(lines.length-1)/2)*height,500));
  }else if(l.type==='shape'){
   ctx.fillStyle=l.color;ctx.strokeStyle=l.color;ctx.lineWidth=l.lineWidth;ctx.beginPath();
   if(l.shape==='circle')ctx.arc(0,0,240,0,Math.PI*2);else if(l.shape==='rect')ctx.rect(-240,-240,480,480);else{ctx.moveTo(-240,0);ctx.lineTo(240,0);}
   if(l.fill&&l.shape!=='line')ctx.fill();else ctx.stroke();
  }else if(l.type==='paint'){scratch.width=scratch.height=512;paint(scratch.getContext('2d'),l.strokes);ctx.drawImage(scratch,-256,-256,512,512);}
  ctx.restore();
 }
}
class History{
 constructor(){this.past=[];this.future=[];}
 push(before,after){if(JSON.stringify(before)===JSON.stringify(after))return;this.past.push(copy(before));this.future=[];while(this.past.length>30||JSON.stringify(this.past).length>1500000)this.past.shift();}
 undo(current){if(!this.past.length)return null;this.future.push(copy(current));return this.past.pop();}
 redo(current){if(!this.future.length)return null;this.past.push(copy(current));return this.future.pop();}
}
module.exports={layers,label,localPoint,bounds,hits,hit,paint,draw,History,MAX_LAYERS,MAX_POINTS,MAX_STROKES,MAX_SIZE};
