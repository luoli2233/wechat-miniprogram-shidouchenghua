const table=Array.from({length:256},(_,n)=>{let c=n;for(let k=0;k<8;k++)c=c&1?0xedb88320^(c>>>1):c>>>1;return c>>>0;});
function crc(bytes,value=0xffffffff){let c=value;for(const b of bytes)c=table[(c^b)&255]^(c>>>8);return c>>>0;}
function checksum(bytes){return ((crc(bytes)^0xffffffff)>>>0).toString(16).padStart(8,'0');}
function encode(text){const binary=unescape(encodeURIComponent(text));const bytes=new Uint8Array(binary.length);for(let i=0;i<binary.length;i++)bytes[i]=binary.charCodeAt(i);return bytes;}
function decode(bytes){let text='';for(let i=0;i<bytes.length;i+=8192)text+=String.fromCharCode(...bytes.subarray(i,i+8192));return decodeURIComponent(escape(text));}
function parse(text){return JSON.parse(text,(key,value)=>{if(['__proto__','constructor','prototype'].includes(key))throw Error('文件含不安全字段');return value;});}
module.exports={crc,checksum,encode,decode,parse};
