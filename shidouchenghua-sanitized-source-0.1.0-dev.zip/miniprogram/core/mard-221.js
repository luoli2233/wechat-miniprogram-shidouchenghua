// Runtime module for the native mini-program; data source: mard-221.json
module.exports = {
  "id": "mard-221-reference",
  "brand": "MARD",
  "series": "221色 · 社区RGB参考",
  "version": "2026-05-19",
  "verified": false,
  "physicalVerified": false,
  "source": "https://raw.githubusercontent.com/HansBug/pindou-color-data/178dafbc9e77d3de556550dbd058270200129186/mard-221-github/colors.json",
  "checkedAt": "2026-09-09",
  "colors": [
    {
      "id": "A1",
      "name": "A1",
      "hex": "#faf5cd"
    },
    {
      "id": "A2",
      "name": "A2",
      "hex": "#fcfed6"
    },
    {
      "id": "A3",
      "name": "A3",
      "hex": "#fcff92"
    },
    {
      "id": "A4",
      "name": "A4",
      "hex": "#f7ec5c"
    },
    {
      "id": "A5",
      "name": "A5",
      "hex": "#ffe44b"
    },
    {
      "id": "A6",
      "name": "A6",
      "hex": "#fda951"
    },
    {
      "id": "A7",
      "name": "A7",
      "hex": "#fa8c4f"
    },
    {
      "id": "A8",
      "name": "A8",
      "hex": "#f9e045"
    },
    {
      "id": "A9",
      "name": "A9",
      "hex": "#f99c5f"
    },
    {
      "id": "A10",
      "name": "A10",
      "hex": "#f47e36"
    },
    {
      "id": "A11",
      "name": "A11",
      "hex": "#fedb99"
    },
    {
      "id": "A12",
      "name": "A12",
      "hex": "#fda276"
    },
    {
      "id": "A13",
      "name": "A13",
      "hex": "#fec667"
    },
    {
      "id": "A14",
      "name": "A14",
      "hex": "#f85842"
    },
    {
      "id": "A15",
      "name": "A15",
      "hex": "#fbf65e"
    },
    {
      "id": "A16",
      "name": "A16",
      "hex": "#feff97"
    },
    {
      "id": "A17",
      "name": "A17",
      "hex": "#fde173"
    },
    {
      "id": "A18",
      "name": "A18",
      "hex": "#fcbf80"
    },
    {
      "id": "A19",
      "name": "A19",
      "hex": "#fd7e77"
    },
    {
      "id": "A20",
      "name": "A20",
      "hex": "#f9d66e"
    },
    {
      "id": "A21",
      "name": "A21",
      "hex": "#fae393"
    },
    {
      "id": "A22",
      "name": "A22",
      "hex": "#edf878"
    },
    {
      "id": "A23",
      "name": "A23",
      "hex": "#e1c9bd"
    },
    {
      "id": "A24",
      "name": "A24",
      "hex": "#f3f6a9"
    },
    {
      "id": "A25",
      "name": "A25",
      "hex": "#ffd785"
    },
    {
      "id": "A26",
      "name": "A26",
      "hex": "#fec832"
    },
    {
      "id": "B1",
      "name": "B1",
      "hex": "#dff139"
    },
    {
      "id": "B2",
      "name": "B2",
      "hex": "#64f343"
    },
    {
      "id": "B3",
      "name": "B3",
      "hex": "#9ff685"
    },
    {
      "id": "B4",
      "name": "B4",
      "hex": "#5fdf34"
    },
    {
      "id": "B5",
      "name": "B5",
      "hex": "#39e158"
    },
    {
      "id": "B6",
      "name": "B6",
      "hex": "#64e0a4"
    },
    {
      "id": "B7",
      "name": "B7",
      "hex": "#3fae7c"
    },
    {
      "id": "B8",
      "name": "B8",
      "hex": "#1d9e54"
    },
    {
      "id": "B9",
      "name": "B9",
      "hex": "#2a5037"
    },
    {
      "id": "B10",
      "name": "B10",
      "hex": "#9ad1ba"
    },
    {
      "id": "B11",
      "name": "B11",
      "hex": "#627032"
    },
    {
      "id": "B12",
      "name": "B12",
      "hex": "#1a6e3d"
    },
    {
      "id": "B13",
      "name": "B13",
      "hex": "#c8e87d"
    },
    {
      "id": "B14",
      "name": "B14",
      "hex": "#ace84c"
    },
    {
      "id": "B15",
      "name": "B15",
      "hex": "#305335"
    },
    {
      "id": "B16",
      "name": "B16",
      "hex": "#c0ed9c"
    },
    {
      "id": "B17",
      "name": "B17",
      "hex": "#9eb33e"
    },
    {
      "id": "B18",
      "name": "B18",
      "hex": "#e6ed4f"
    },
    {
      "id": "B19",
      "name": "B19",
      "hex": "#26b78e"
    },
    {
      "id": "B20",
      "name": "B20",
      "hex": "#caedcf"
    },
    {
      "id": "B21",
      "name": "B21",
      "hex": "#176268"
    },
    {
      "id": "B22",
      "name": "B22",
      "hex": "#0a4241"
    },
    {
      "id": "B23",
      "name": "B23",
      "hex": "#343b1a"
    },
    {
      "id": "B24",
      "name": "B24",
      "hex": "#e8faa6"
    },
    {
      "id": "B25",
      "name": "B25",
      "hex": "#4e846d"
    },
    {
      "id": "B26",
      "name": "B26",
      "hex": "#907c35"
    },
    {
      "id": "B27",
      "name": "B27",
      "hex": "#d0e0af"
    },
    {
      "id": "B28",
      "name": "B28",
      "hex": "#9ee5bb"
    },
    {
      "id": "B29",
      "name": "B29",
      "hex": "#c6df5f"
    },
    {
      "id": "B30",
      "name": "B30",
      "hex": "#e3fbb1"
    },
    {
      "id": "B31",
      "name": "B31",
      "hex": "#b2e694"
    },
    {
      "id": "B32",
      "name": "B32",
      "hex": "#92ad60"
    },
    {
      "id": "C1",
      "name": "C1",
      "hex": "#e8ffe7"
    },
    {
      "id": "C2",
      "name": "C2",
      "hex": "#abf8fe"
    },
    {
      "id": "C3",
      "name": "C3",
      "hex": "#9ee0f8"
    },
    {
      "id": "C4",
      "name": "C4",
      "hex": "#44cdfb"
    },
    {
      "id": "C5",
      "name": "C5",
      "hex": "#06abe3"
    },
    {
      "id": "C6",
      "name": "C6",
      "hex": "#54a7e9"
    },
    {
      "id": "C7",
      "name": "C7",
      "hex": "#3977cc"
    },
    {
      "id": "C8",
      "name": "C8",
      "hex": "#0f52bd"
    },
    {
      "id": "C9",
      "name": "C9",
      "hex": "#3349c3"
    },
    {
      "id": "C10",
      "name": "C10",
      "hex": "#3dbbe3"
    },
    {
      "id": "C11",
      "name": "C11",
      "hex": "#2aded3"
    },
    {
      "id": "C12",
      "name": "C12",
      "hex": "#1e334e"
    },
    {
      "id": "C13",
      "name": "C13",
      "hex": "#cde7fe"
    },
    {
      "id": "C14",
      "name": "C14",
      "hex": "#d6fdfc"
    },
    {
      "id": "C15",
      "name": "C15",
      "hex": "#21c5c4"
    },
    {
      "id": "C16",
      "name": "C16",
      "hex": "#1858a2"
    },
    {
      "id": "C17",
      "name": "C17",
      "hex": "#02d1f3"
    },
    {
      "id": "C18",
      "name": "C18",
      "hex": "#213244"
    },
    {
      "id": "C19",
      "name": "C19",
      "hex": "#188690"
    },
    {
      "id": "C20",
      "name": "C20",
      "hex": "#1a70a9"
    },
    {
      "id": "C21",
      "name": "C21",
      "hex": "#beddfc"
    },
    {
      "id": "C22",
      "name": "C22",
      "hex": "#6bb1bb"
    },
    {
      "id": "C23",
      "name": "C23",
      "hex": "#c8e2f9"
    },
    {
      "id": "C24",
      "name": "C24",
      "hex": "#7ec5f9"
    },
    {
      "id": "C25",
      "name": "C25",
      "hex": "#a9e8e0"
    },
    {
      "id": "C26",
      "name": "C26",
      "hex": "#42add1"
    },
    {
      "id": "C27",
      "name": "C27",
      "hex": "#d0deef"
    },
    {
      "id": "C28",
      "name": "C28",
      "hex": "#bdceed"
    },
    {
      "id": "C29",
      "name": "C29",
      "hex": "#364a89"
    },
    {
      "id": "D1",
      "name": "D1",
      "hex": "#acb7ef"
    },
    {
      "id": "D2",
      "name": "D2",
      "hex": "#868dd3"
    },
    {
      "id": "D3",
      "name": "D3",
      "hex": "#3653af"
    },
    {
      "id": "D4",
      "name": "D4",
      "hex": "#162c7e"
    },
    {
      "id": "D5",
      "name": "D5",
      "hex": "#b34ec6"
    },
    {
      "id": "D6",
      "name": "D6",
      "hex": "#b37bdc"
    },
    {
      "id": "D7",
      "name": "D7",
      "hex": "#8758a9"
    },
    {
      "id": "D8",
      "name": "D8",
      "hex": "#e3d2fe"
    },
    {
      "id": "D9",
      "name": "D9",
      "hex": "#d6baf5"
    },
    {
      "id": "D10",
      "name": "D10",
      "hex": "#301a49"
    },
    {
      "id": "D11",
      "name": "D11",
      "hex": "#bcbae2"
    },
    {
      "id": "D12",
      "name": "D12",
      "hex": "#dc99ce"
    },
    {
      "id": "D13",
      "name": "D13",
      "hex": "#b5038f"
    },
    {
      "id": "D14",
      "name": "D14",
      "hex": "#882893"
    },
    {
      "id": "D15",
      "name": "D15",
      "hex": "#2f1e8e"
    },
    {
      "id": "D16",
      "name": "D16",
      "hex": "#e2e4f0"
    },
    {
      "id": "D17",
      "name": "D17",
      "hex": "#c7d3f9"
    },
    {
      "id": "D18",
      "name": "D18",
      "hex": "#9a64b8"
    },
    {
      "id": "D19",
      "name": "D19",
      "hex": "#d8c2d9"
    },
    {
      "id": "D20",
      "name": "D20",
      "hex": "#9c34ad"
    },
    {
      "id": "D21",
      "name": "D21",
      "hex": "#940595"
    },
    {
      "id": "D22",
      "name": "D22",
      "hex": "#383995"
    },
    {
      "id": "D23",
      "name": "D23",
      "hex": "#fadbf8"
    },
    {
      "id": "D24",
      "name": "D24",
      "hex": "#768ae1"
    },
    {
      "id": "D25",
      "name": "D25",
      "hex": "#4950c2"
    },
    {
      "id": "D26",
      "name": "D26",
      "hex": "#d6c6eb"
    },
    {
      "id": "E1",
      "name": "E1",
      "hex": "#f6d4cb"
    },
    {
      "id": "E2",
      "name": "E2",
      "hex": "#fcc1dd"
    },
    {
      "id": "E3",
      "name": "E3",
      "hex": "#f6bde8"
    },
    {
      "id": "E4",
      "name": "E4",
      "hex": "#e9639e"
    },
    {
      "id": "E5",
      "name": "E5",
      "hex": "#f1559f"
    },
    {
      "id": "E6",
      "name": "E6",
      "hex": "#ec4072"
    },
    {
      "id": "E7",
      "name": "E7",
      "hex": "#c63674"
    },
    {
      "id": "E8",
      "name": "E8",
      "hex": "#fddbe9"
    },
    {
      "id": "E9",
      "name": "E9",
      "hex": "#e575c7"
    },
    {
      "id": "E10",
      "name": "E10",
      "hex": "#d33997"
    },
    {
      "id": "E11",
      "name": "E11",
      "hex": "#f7dad4"
    },
    {
      "id": "E12",
      "name": "E12",
      "hex": "#f893bf"
    },
    {
      "id": "E13",
      "name": "E13",
      "hex": "#b5026a"
    },
    {
      "id": "E14",
      "name": "E14",
      "hex": "#fad4bf"
    },
    {
      "id": "E15",
      "name": "E15",
      "hex": "#f5c9ca"
    },
    {
      "id": "E16",
      "name": "E16",
      "hex": "#fbf4ec"
    },
    {
      "id": "E17",
      "name": "E17",
      "hex": "#f7e3ec"
    },
    {
      "id": "E18",
      "name": "E18",
      "hex": "#fbcbdb"
    },
    {
      "id": "E19",
      "name": "E19",
      "hex": "#f6bbd1"
    },
    {
      "id": "E20",
      "name": "E20",
      "hex": "#d7c6ce"
    },
    {
      "id": "E21",
      "name": "E21",
      "hex": "#c09da4"
    },
    {
      "id": "E22",
      "name": "E22",
      "hex": "#b58b9f"
    },
    {
      "id": "E23",
      "name": "E23",
      "hex": "#937d8a"
    },
    {
      "id": "E24",
      "name": "E24",
      "hex": "#debee5"
    },
    {
      "id": "F1",
      "name": "F1",
      "hex": "#ff9280"
    },
    {
      "id": "F2",
      "name": "F2",
      "hex": "#f73d48"
    },
    {
      "id": "F3",
      "name": "F3",
      "hex": "#ef4d3e"
    },
    {
      "id": "F4",
      "name": "F4",
      "hex": "#f92b40"
    },
    {
      "id": "F5",
      "name": "F5",
      "hex": "#e30328"
    },
    {
      "id": "F6",
      "name": "F6",
      "hex": "#913635"
    },
    {
      "id": "F7",
      "name": "F7",
      "hex": "#911932"
    },
    {
      "id": "F8",
      "name": "F8",
      "hex": "#bb0126"
    },
    {
      "id": "F9",
      "name": "F9",
      "hex": "#e0677a"
    },
    {
      "id": "F10",
      "name": "F10",
      "hex": "#874628"
    },
    {
      "id": "F11",
      "name": "F11",
      "hex": "#6f321d"
    },
    {
      "id": "F12",
      "name": "F12",
      "hex": "#f8516d"
    },
    {
      "id": "F13",
      "name": "F13",
      "hex": "#f45c45"
    },
    {
      "id": "F14",
      "name": "F14",
      "hex": "#fcadb2"
    },
    {
      "id": "F15",
      "name": "F15",
      "hex": "#d50527"
    },
    {
      "id": "F16",
      "name": "F16",
      "hex": "#f8c0a9"
    },
    {
      "id": "F17",
      "name": "F17",
      "hex": "#e89b7d"
    },
    {
      "id": "F18",
      "name": "F18",
      "hex": "#d07e4a"
    },
    {
      "id": "F19",
      "name": "F19",
      "hex": "#be454a"
    },
    {
      "id": "F20",
      "name": "F20",
      "hex": "#c69495"
    },
    {
      "id": "F21",
      "name": "F21",
      "hex": "#f2bbc6"
    },
    {
      "id": "F22",
      "name": "F22",
      "hex": "#f7c3d0"
    },
    {
      "id": "F23",
      "name": "F23",
      "hex": "#ec806d"
    },
    {
      "id": "F24",
      "name": "F24",
      "hex": "#e09daf"
    },
    {
      "id": "F25",
      "name": "F25",
      "hex": "#e84854"
    },
    {
      "id": "G1",
      "name": "G1",
      "hex": "#ffe4d3"
    },
    {
      "id": "G2",
      "name": "G2",
      "hex": "#fcc6ac"
    },
    {
      "id": "G3",
      "name": "G3",
      "hex": "#f1c4a5"
    },
    {
      "id": "G4",
      "name": "G4",
      "hex": "#dcb387"
    },
    {
      "id": "G5",
      "name": "G5",
      "hex": "#e7b34e"
    },
    {
      "id": "G6",
      "name": "G6",
      "hex": "#f3a014"
    },
    {
      "id": "G7",
      "name": "G7",
      "hex": "#98503a"
    },
    {
      "id": "G8",
      "name": "G8",
      "hex": "#4b2b1c"
    },
    {
      "id": "G9",
      "name": "G9",
      "hex": "#e4b685"
    },
    {
      "id": "G10",
      "name": "G10",
      "hex": "#da8c42"
    },
    {
      "id": "G11",
      "name": "G11",
      "hex": "#dac898"
    },
    {
      "id": "G12",
      "name": "G12",
      "hex": "#fec993"
    },
    {
      "id": "G13",
      "name": "G13",
      "hex": "#b2714b"
    },
    {
      "id": "G14",
      "name": "G14",
      "hex": "#8b684c"
    },
    {
      "id": "G15",
      "name": "G15",
      "hex": "#fcf9e0"
    },
    {
      "id": "G16",
      "name": "G16",
      "hex": "#f2d8c1"
    },
    {
      "id": "G17",
      "name": "G17",
      "hex": "#79544e"
    },
    {
      "id": "G18",
      "name": "G18",
      "hex": "#ffe4d6"
    },
    {
      "id": "G19",
      "name": "G19",
      "hex": "#dd7d41"
    },
    {
      "id": "G20",
      "name": "G20",
      "hex": "#a5452f"
    },
    {
      "id": "G21",
      "name": "G21",
      "hex": "#b38561"
    },
    {
      "id": "H1",
      "name": "H1",
      "hex": "#fbfbfb"
    },
    {
      "id": "H2",
      "name": "H2",
      "hex": "#ffffff"
    },
    {
      "id": "H3",
      "name": "H3",
      "hex": "#b4b4b4"
    },
    {
      "id": "H4",
      "name": "H4",
      "hex": "#878787"
    },
    {
      "id": "H5",
      "name": "H5",
      "hex": "#464648"
    },
    {
      "id": "H6",
      "name": "H6",
      "hex": "#2c2c2c"
    },
    {
      "id": "H7",
      "name": "H7",
      "hex": "#010101"
    },
    {
      "id": "H8",
      "name": "H8",
      "hex": "#e7d6dc"
    },
    {
      "id": "H9",
      "name": "H9",
      "hex": "#efedee"
    },
    {
      "id": "H10",
      "name": "H10",
      "hex": "#eceaeb"
    },
    {
      "id": "H11",
      "name": "H11",
      "hex": "#cdcdcd"
    },
    {
      "id": "H12",
      "name": "H12",
      "hex": "#fdf6ee"
    },
    {
      "id": "H13",
      "name": "H13",
      "hex": "#f4efd1"
    },
    {
      "id": "H14",
      "name": "H14",
      "hex": "#ced7d4"
    },
    {
      "id": "H15",
      "name": "H15",
      "hex": "#98a6a6"
    },
    {
      "id": "H16",
      "name": "H16",
      "hex": "#1b1213"
    },
    {
      "id": "H17",
      "name": "H17",
      "hex": "#f0eeef"
    },
    {
      "id": "H18",
      "name": "H18",
      "hex": "#fcfff8"
    },
    {
      "id": "H19",
      "name": "H19",
      "hex": "#f2eee5"
    },
    {
      "id": "H20",
      "name": "H20",
      "hex": "#96a09f"
    },
    {
      "id": "H21",
      "name": "H21",
      "hex": "#fffbe1"
    },
    {
      "id": "H22",
      "name": "H22",
      "hex": "#cacada"
    },
    {
      "id": "H23",
      "name": "H23",
      "hex": "#9b9c94"
    },
    {
      "id": "M1",
      "name": "M1",
      "hex": "#bbc6b6"
    },
    {
      "id": "M2",
      "name": "M2",
      "hex": "#909994"
    },
    {
      "id": "M3",
      "name": "M3",
      "hex": "#697e80"
    },
    {
      "id": "M4",
      "name": "M4",
      "hex": "#e0d4bc"
    },
    {
      "id": "M5",
      "name": "M5",
      "hex": "#d0cbae"
    },
    {
      "id": "M6",
      "name": "M6",
      "hex": "#b0aa86"
    },
    {
      "id": "M7",
      "name": "M7",
      "hex": "#b0a796"
    },
    {
      "id": "M8",
      "name": "M8",
      "hex": "#ae8082"
    },
    {
      "id": "M9",
      "name": "M9",
      "hex": "#a88764"
    },
    {
      "id": "M10",
      "name": "M10",
      "hex": "#c6b2bb"
    },
    {
      "id": "M11",
      "name": "M11",
      "hex": "#9d7693"
    },
    {
      "id": "M12",
      "name": "M12",
      "hex": "#644b51"
    },
    {
      "id": "M13",
      "name": "M13",
      "hex": "#c79266"
    },
    {
      "id": "M14",
      "name": "M14",
      "hex": "#c37463"
    },
    {
      "id": "M15",
      "name": "M15",
      "hex": "#747d7a"
    }
  ]
};
