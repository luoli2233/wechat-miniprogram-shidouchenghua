const {stats}=require('./model');
function contrast(hex){const n=[1,3,5].map(i=>parseInt(hex.slice(i,i+2),16));return n[0]*.299+n[1]*.587+n[2]*.114>150?'#22382f':'#ffffff';}
function grid(ctx,p,options={}){
 const {x=0,y=0,columns=p.columns,rows=p.rows,cell=20,offsetX=0,offsetY=0,labels=true,lines=true,highlight=null}=options;
 const palette=Object.fromEntries(p.palette.colors.map(c=>[c.id,c]));
 ctx.textAlign='center';ctx.textBaseline='middle';ctx.font=`${Math.max(10,Math.floor(cell*.4))}px sans-serif`;
 for(let r=0;r<rows;r++)for(let c=0;c<columns;c++){
  const id=p.cells[(r+y)*p.columns+c+x],left=offsetX+c*cell,top=offsetY+r*cell;
  ctx.globalAlpha=(highlight && id!==highlight) ? 0.2 : 1;
  ctx.fillStyle=id?palette[id].hex:((c+x+r+y)%2?'#e8ece5':'#f5f6f1');ctx.fillRect(left,top,cell,cell);
  if(id&&labels&&cell>=18){ctx.fillStyle=contrast(palette[id].hex);ctx.fillText(p.labels[id],left+cell/2,top+cell/2);}
 }
 ctx.globalAlpha=1;
 if(lines){for(let c=0;c<=columns;c++){ctx.strokeStyle=(c+x)%5===0?'#263c3577':'#263c3527';ctx.lineWidth=(c+x)%5===0?1.3:.6;ctx.beginPath();ctx.moveTo(offsetX+c*cell,offsetY);ctx.lineTo(offsetX+c*cell,offsetY+rows*cell);ctx.stroke();}for(let r=0;r<=rows;r++){ctx.strokeStyle=(r+y)%5===0?'#263c3577':'#263c3527';ctx.lineWidth=(r+y)%5===0?1.3:.6;ctx.beginPath();ctx.moveTo(offsetX,offsetY+r*cell);ctx.lineTo(offsetX+columns*cell,offsetY+r*cell);ctx.stroke();}}
}
function header(ctx,p,title,width,page){ctx.fillStyle='#263c35';ctx.textAlign='left';ctx.textBaseline='top';ctx.font='bold 30px sans-serif';ctx.fillText(title,40,30);ctx.font='20px sans-serif';ctx.fillText(`${p.palette.brand} / ${p.palette.series} · v${p.palette.version} · ${page}`,40,76,width-80);ctx.fillStyle='#976338';ctx.font='20px sans-serif';ctx.fillText(require('./palette-catalog').official(p.palette)?'官方RGB参考 · 实物可能有色差 · 非1:1打印':'参考色表 · 实物可能有色差，请核对色卡 · 非1:1打印',40,110);ctx.fillStyle='#758277';ctx.font='17px sans-serif';ctx.fillText(new Date(p.updatedAt).toISOString().slice(0,10),width-150,38);}
function exportPage(canvas,p,part,index,count){
 const localCounts={};for(let y=part.y;y<part.y+part.rows;y++)for(let x=part.x;x<part.x+part.columns;x++){const id=p.cells[y*p.columns+x];if(id)localCounts[id]=(localCounts[id]||0)+1;}
 const local=p.palette.colors.filter(c=>localCounts[c.id]);
 const shown=local.slice(0,40),cell=36,margin=70;let width=Math.max(960,part.columns*cell+margin*2),height=part.rows*cell+420+Math.max(120,Math.ceil(shown.length/2)*32);
 if(width>4096||height>4096||width*height>8000000)throw Error('导出分区超出安全预算');
 canvas.width=width;canvas.height=height;const ctx=canvas.getContext('2d');ctx.fillStyle='#ffffff';ctx.fillRect(0,0,width,height);
 header(ctx,p,`制作分区 ${part.name}`,width,`${index+1}/${count}`);
 ctx.fillStyle='#52685b';ctx.font='20px sans-serif';ctx.fillText(`列 ${part.x+1}—${part.x+part.columns} / 行 ${part.y+1}—${part.y+part.rows} · 标识请对应清单页`,40,151);
 grid(ctx,p,{...part,cell,offsetX:margin,offsetY:210});
 ctx.fillStyle='#52685b';ctx.font='16px sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';
 for(let c=0;c<part.columns;c++)ctx.fillText(String(part.x+c+1),margin+(c+.5)*cell,194);
 for(let r=0;r<part.rows;r++)ctx.fillText(String(part.y+r+1),margin-23,210+(r+.5)*cell);
 const bottom=210+part.rows*cell+32;ctx.textAlign='left';ctx.font='20px sans-serif';ctx.fillText(local.length?(local.length>shown.length?'本区颜色（显示前40色，完整色号见全局清单）':'本区颜色（局部数量，不另加至全局清单）'):'本区无豆 · 保留位置对应关系',40,bottom);
 ctx.font='18px sans-serif';shown.forEach((c,i)=>{const x=40+(i%2)*340,y=bottom+35+Math.floor(i/2)*32;ctx.fillStyle=c.hex;ctx.fillRect(x,y-6,20,20);ctx.strokeStyle='#cbd2c6';ctx.strokeRect(x,y-6,20,20);ctx.fillStyle='#52685b';ctx.fillText(`${p.labels[c.id]}  ${c.id}  ${localCounts[c.id]}颗`,x+30,y+4);});
 const mapCell=Math.min(120/p.columns,120/p.rows),mapX=width-175,mapY=bottom+30;grid(ctx,p,{cell:mapCell,labels:false,lines:false,offsetX:mapX,offsetY:mapY});ctx.strokeStyle='#bd6547';ctx.lineWidth=3;ctx.strokeRect(mapX+part.x*mapCell,mapY+part.y*mapCell,part.columns*mapCell,part.rows*mapCell);
 ctx.textAlign='left';ctx.textBaseline='middle';ctx.font='17px sans-serif';ctx.fillStyle='#52685b';ctx.fillText('空格不放豆。右侧红框为当前分区位置。',40,height-48);
}
function axes(ctx,p,cell,x,y){ctx.fillStyle='#52685b';ctx.font='11px sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';for(let c=0;c<p.columns;c++)if(c===0||(c+1)%5===0)ctx.fillText(String(c+1),x+(c+.5)*cell,y-12);for(let r=0;r<p.rows;r++)if(r===0||(r+1)%5===0)ctx.fillText(String(r+1),x-18,y+(r+.5)*cell);}
function overview(canvas,p){const cell=14;canvas.width=Math.max(960,p.columns*cell+100);canvas.height=p.rows*cell+260;const ctx=canvas.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,canvas.width,canvas.height);header(ctx,p,'作品总览',canvas.width,'总览');grid(ctx,p,{cell,labels:false,offsetX:50,offsetY:170});axes(ctx,p,cell,50,170);ctx.fillStyle='#52685b';ctx.textAlign='left';ctx.font='18px sans-serif';ctx.fillText('总览用于定位；制作请使用带标识的分区图及清单。',40,canvas.height-40);}
const LEGEND_PAGE_SIZE=70;
function legendPages(p){return Math.max(1,Math.ceil(stats(p).colors.length/LEGEND_PAGE_SIZE));}
function legendPage(canvas,p,page=0){const s=stats(p),pages=legendPages(p);if(!Number.isInteger(page)||page<0||page>=pages)throw Error('材料清单页码无效');const colors=s.colors.slice(page*LEGEND_PAGE_SIZE,(page+1)*LEGEND_PAGE_SIZE);canvas.width=1080;canvas.height=340+colors.length*47;const ctx=canvas.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,canvas.width,canvas.height);header(ctx,p,require('./palette-catalog').official(p.palette)?'全局材料参考清单':'全局材料清单 · 未核验',canvas.width,`清单 ${page+1}/${pages}`);ctx.fillStyle='#263c35';ctx.font='23px sans-serif';ctx.fillText(`实际 ${s.total}颗 · ${s.colors.length}色 · 余量 ${p.reserve||0}% · 建议 ${s.purchase}颗`,40,166);ctx.font='19px sans-serif';ctx.fillText('标识',86,210);ctx.fillText('色号 / 名称',168,210);ctx.fillText('实际',740,210);ctx.fillText('建议',900,210);
 colors.forEach((c,i)=>{const y=250+i*47;ctx.fillStyle=c.hex;ctx.fillRect(40,y,28,28);ctx.strokeStyle='#cbd2c6';ctx.strokeRect(40,y,28,28);ctx.fillStyle='#263c35';ctx.fillText(c.label,86,y+3);ctx.fillText(c.id+' / '+c.name,168,y+3);ctx.fillText(String(c.count),740,y+3);ctx.fillText(String(c.purchase),900,y+3);});ctx.fillStyle='#758277';ctx.font='18px sans-serif';ctx.fillText(`${s.width}×${s.height}cm 名义占位 · ${p.board.name} ${s.boardsX}×${s.boardsY}块 · 非熨烫后尺寸`,40,canvas.height-44);
}
function legend(canvas,p){legendPage(canvas,p,0);}
module.exports={grid,axes,overview,exportPage,legend,legendPage,legendPages};
