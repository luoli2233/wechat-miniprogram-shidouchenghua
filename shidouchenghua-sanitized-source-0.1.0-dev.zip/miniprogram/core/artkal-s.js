// Runtime module for the native mini-program; data source: artkal-s.json
module.exports = {
  "id": "artkal-s-rgb-2024",
  "brand": "Artkal",
  "series": "S 5mm · 官方RGB参考173色",
  "version": "2024-rgb",
  "verified": false,
  "source": "https://cdn.shopify.com/s/files/1/1323/8195/files/S_MIDI_Beads_RGB_Color_Chart_2024.pdf?v=1744686607",
  "sourcePage": "https://www.artkalfusebeads.com/pages/s-color-chart",
  "checkedAt": "2026-09-09",
  "physicalVerified": false,
  "excludedCodes": [
    "S41",
    "S42",
    "S63"
  ],
  "colors": [
    {
      "id": "S01",
      "name": "S01",
      "hex": "#ffffff"
    },
    {
      "id": "S02",
      "name": "S02",
      "hex": "#ffa38b"
    },
    {
      "id": "S03",
      "name": "S03",
      "hex": "#ff8200"
    },
    {
      "id": "S04",
      "name": "S04",
      "hex": "#fa4616"
    },
    {
      "id": "S05",
      "name": "S05",
      "hex": "#ee2737"
    },
    {
      "id": "S06",
      "name": "S06",
      "hex": "#ef64a2"
    },
    {
      "id": "S07",
      "name": "S07",
      "hex": "#97999b"
    },
    {
      "id": "S08",
      "name": "S08",
      "hex": "#26d07c"
    },
    {
      "id": "S09",
      "name": "S09",
      "hex": "#007371"
    },
    {
      "id": "S10",
      "name": "S10",
      "hex": "#56b7e6"
    },
    {
      "id": "S11",
      "name": "S11",
      "hex": "#0050b5"
    },
    {
      "id": "S12",
      "name": "S12",
      "hex": "#9063cd"
    },
    {
      "id": "S13",
      "name": "S13",
      "hex": "#000000"
    },
    {
      "id": "S14",
      "name": "S14",
      "hex": "#fdda24"
    },
    {
      "id": "S15",
      "name": "S15",
      "hex": "#a72b2a"
    },
    {
      "id": "S16",
      "name": "S16",
      "hex": "#674736"
    },
    {
      "id": "S17",
      "name": "S17",
      "hex": "#7b4d35"
    },
    {
      "id": "S18",
      "name": "S18",
      "hex": "#eaa794"
    },
    {
      "id": "S19",
      "name": "S19",
      "hex": "#f8c1b8"
    },
    {
      "id": "S20",
      "name": "S20",
      "hex": "#249e6b"
    },
    {
      "id": "S21",
      "name": "S21",
      "hex": "#93c90e"
    },
    {
      "id": "S22",
      "name": "S22",
      "hex": "#483698"
    },
    {
      "id": "S23",
      "name": "S23",
      "hex": "#7d55c7"
    },
    {
      "id": "S24",
      "name": "S24",
      "hex": "#1164c9"
    },
    {
      "id": "S25",
      "name": "S25",
      "hex": "#ef60a3"
    },
    {
      "id": "S26",
      "name": "S26",
      "hex": "#f04e98"
    },
    {
      "id": "S27",
      "name": "S27",
      "hex": "#ffc72c"
    },
    {
      "id": "S28",
      "name": "S28",
      "hex": "#ef95cf"
    },
    {
      "id": "S29",
      "name": "S29",
      "hex": "#fbdb65"
    },
    {
      "id": "S30",
      "name": "S30",
      "hex": "#a4e6e8"
    },
    {
      "id": "S31",
      "name": "S31",
      "hex": "#b5e3d8"
    },
    {
      "id": "S32",
      "name": "S32",
      "hex": "#fecb8b"
    },
    {
      "id": "S33",
      "name": "S33",
      "hex": "#c5b4e3"
    },
    {
      "id": "S34",
      "name": "S34",
      "hex": "#d50032"
    },
    {
      "id": "S35",
      "name": "S35",
      "hex": "#f7ced7"
    },
    {
      "id": "S36",
      "name": "S36",
      "hex": "#e06287"
    },
    {
      "id": "S37",
      "name": "S37",
      "hex": "#8bd3e6"
    },
    {
      "id": "S38",
      "name": "S38",
      "hex": "#bc204b"
    },
    {
      "id": "S39",
      "name": "S39",
      "hex": "#ff7f41"
    },
    {
      "id": "S40",
      "name": "S40",
      "hex": "#f99fc9"
    },
    {
      "id": "S43",
      "name": "S43",
      "hex": "#75787b"
    },
    {
      "id": "S44",
      "name": "S44",
      "hex": "#9bcbeb"
    },
    {
      "id": "S45",
      "name": "S45",
      "hex": "#00b2a9"
    },
    {
      "id": "S46",
      "name": "S46",
      "hex": "#8edd65"
    },
    {
      "id": "S47",
      "name": "S47",
      "hex": "#a6631b"
    },
    {
      "id": "S48",
      "name": "S48",
      "hex": "#ffc845"
    },
    {
      "id": "S49",
      "name": "S49",
      "hex": "#973961"
    },
    {
      "id": "S50",
      "name": "S50",
      "hex": "#ffb3ab"
    },
    {
      "id": "S51",
      "name": "S51",
      "hex": "#fff8db"
    },
    {
      "id": "S52",
      "name": "S52",
      "hex": "#f8e08e"
    },
    {
      "id": "S53",
      "name": "S53",
      "hex": "#62a0e6"
    },
    {
      "id": "S54",
      "name": "S54",
      "hex": "#0090da"
    },
    {
      "id": "S55",
      "name": "S55",
      "hex": "#addc91"
    },
    {
      "id": "S56",
      "name": "S56",
      "hex": "#ff6a39"
    },
    {
      "id": "S57",
      "name": "S57",
      "hex": "#b33d26"
    },
    {
      "id": "S58",
      "name": "S58",
      "hex": "#ba0c2f"
    },
    {
      "id": "S59",
      "name": "S59",
      "hex": "#5949a7"
    },
    {
      "id": "S60",
      "name": "S60",
      "hex": "#9678d3"
    },
    {
      "id": "S61",
      "name": "S61",
      "hex": "#e6de77"
    },
    {
      "id": "S62",
      "name": "S62",
      "hex": "#007c58"
    },
    {
      "id": "S64",
      "name": "S64",
      "hex": "#2c2d65"
    },
    {
      "id": "S65",
      "name": "S65",
      "hex": "#f0ec74"
    },
    {
      "id": "S66",
      "name": "S66",
      "hex": "#ee5340"
    },
    {
      "id": "S67",
      "name": "S67",
      "hex": "#ecc3b2"
    },
    {
      "id": "S68",
      "name": "S68",
      "hex": "#e7b78a"
    },
    {
      "id": "S69",
      "name": "S69",
      "hex": "#212721"
    },
    {
      "id": "S70",
      "name": "S70",
      "hex": "#babc16"
    },
    {
      "id": "S71",
      "name": "S71",
      "hex": "#008522"
    },
    {
      "id": "S72",
      "name": "S72",
      "hex": "#67d9df"
    },
    {
      "id": "S73",
      "name": "S73",
      "hex": "#48a9c5"
    },
    {
      "id": "S74",
      "name": "S74",
      "hex": "#04a9c7"
    },
    {
      "id": "S75",
      "name": "S75",
      "hex": "#0085ad"
    },
    {
      "id": "S76",
      "name": "S76",
      "hex": "#00a7b5"
    },
    {
      "id": "S77",
      "name": "S77",
      "hex": "#d9d9d6"
    },
    {
      "id": "S78",
      "name": "S78",
      "hex": "#c8c9c7"
    },
    {
      "id": "S79",
      "name": "S79",
      "hex": "#b1b3b3"
    },
    {
      "id": "S80",
      "name": "S80",
      "hex": "#a2a569"
    },
    {
      "id": "S81",
      "name": "S81",
      "hex": "#d5a286"
    },
    {
      "id": "S82",
      "name": "S82",
      "hex": "#c58b68"
    },
    {
      "id": "S83",
      "name": "S83",
      "hex": "#b15533"
    },
    {
      "id": "S84",
      "name": "S84",
      "hex": "#ab5c57"
    },
    {
      "id": "S85",
      "name": "S85",
      "hex": "#8a2a2b"
    },
    {
      "id": "S86",
      "name": "S86",
      "hex": "#f29d04"
    },
    {
      "id": "S87",
      "name": "S87",
      "hex": "#ff808b"
    },
    {
      "id": "S88",
      "name": "S88",
      "hex": "#da1884"
    },
    {
      "id": "S89",
      "name": "S89",
      "hex": "#53565a"
    },
    {
      "id": "S90",
      "name": "S90",
      "hex": "#ffc56e"
    },
    {
      "id": "S91",
      "name": "S91",
      "hex": "#183028"
    },
    {
      "id": "S92",
      "name": "S92",
      "hex": "#c69214"
    },
    {
      "id": "S93",
      "name": "S93",
      "hex": "#edc8a3"
    },
    {
      "id": "S94",
      "name": "S94",
      "hex": "#eaa794"
    },
    {
      "id": "S95",
      "name": "S95",
      "hex": "#e8927c"
    },
    {
      "id": "S96",
      "name": "S96",
      "hex": "#ff8d6d"
    },
    {
      "id": "S97",
      "name": "S97",
      "hex": "#e35205"
    },
    {
      "id": "S98",
      "name": "S98",
      "hex": "#80b6e8"
    },
    {
      "id": "S99",
      "name": "S99",
      "hex": "#5ca9cc"
    },
    {
      "id": "S100",
      "name": "S100",
      "hex": "#5db3cb"
    },
    {
      "id": "S101",
      "name": "S101",
      "hex": "#00a3e1"
    },
    {
      "id": "S102",
      "name": "S102",
      "hex": "#0077cf"
    },
    {
      "id": "S103",
      "name": "S103",
      "hex": "#0067b9"
    },
    {
      "id": "S104",
      "name": "S104",
      "hex": "#007dba"
    },
    {
      "id": "S105",
      "name": "S105",
      "hex": "#00859b"
    },
    {
      "id": "S106",
      "name": "S106",
      "hex": "#0076a8"
    },
    {
      "id": "S107",
      "name": "S107",
      "hex": "#007096"
    },
    {
      "id": "S108",
      "name": "S108",
      "hex": "#e6c78a"
    },
    {
      "id": "S109",
      "name": "S109",
      "hex": "#ceb888"
    },
    {
      "id": "S110",
      "name": "S110",
      "hex": "#c6aa76"
    },
    {
      "id": "S111",
      "name": "S111",
      "hex": "#a08629"
    },
    {
      "id": "S112",
      "name": "S112",
      "hex": "#897630"
    },
    {
      "id": "S113",
      "name": "S113",
      "hex": "#c3c6a8"
    },
    {
      "id": "S114",
      "name": "S114",
      "hex": "#c0bb87"
    },
    {
      "id": "S115",
      "name": "S115",
      "hex": "#b0aa7e"
    },
    {
      "id": "S116",
      "name": "S116",
      "hex": "#a3aa83"
    },
    {
      "id": "S117",
      "name": "S117",
      "hex": "#77744d"
    },
    {
      "id": "S118",
      "name": "S118",
      "hex": "#5e6738"
    },
    {
      "id": "S119",
      "name": "S119",
      "hex": "#98dbce"
    },
    {
      "id": "S120",
      "name": "S120",
      "hex": "#9be3bf"
    },
    {
      "id": "S121",
      "name": "S121",
      "hex": "#6bbbae"
    },
    {
      "id": "S122",
      "name": "S122",
      "hex": "#00bb7e"
    },
    {
      "id": "S123",
      "name": "S123",
      "hex": "#31b700"
    },
    {
      "id": "S124",
      "name": "S124",
      "hex": "#035f1d"
    },
    {
      "id": "S125",
      "name": "S125",
      "hex": "#007864"
    },
    {
      "id": "S126",
      "name": "S126",
      "hex": "#00685e"
    },
    {
      "id": "S127",
      "name": "S127",
      "hex": "#decde7"
    },
    {
      "id": "S128",
      "name": "S128",
      "hex": "#c98bdb"
    },
    {
      "id": "S129",
      "name": "S129",
      "hex": "#dcb6c9"
    },
    {
      "id": "S130",
      "name": "S130",
      "hex": "#dd74a1"
    },
    {
      "id": "S131",
      "name": "S131",
      "hex": "#ad96dc"
    },
    {
      "id": "S132",
      "name": "S132",
      "hex": "#ef426f"
    },
    {
      "id": "S133",
      "name": "S133",
      "hex": "#c724b1"
    },
    {
      "id": "S134",
      "name": "S134",
      "hex": "#8031a7"
    },
    {
      "id": "S135",
      "name": "S135",
      "hex": "#9faee5"
    },
    {
      "id": "S136",
      "name": "S136",
      "hex": "#b4b2e4"
    },
    {
      "id": "S137",
      "name": "S137",
      "hex": "#5f8dda"
    },
    {
      "id": "S138",
      "name": "S138",
      "hex": "#5780d2"
    },
    {
      "id": "S139",
      "name": "S139",
      "hex": "#5576d1"
    },
    {
      "id": "S140",
      "name": "S140",
      "hex": "#3c62c3"
    },
    {
      "id": "S141",
      "name": "S141",
      "hex": "#466cca"
    },
    {
      "id": "S142",
      "name": "S142",
      "hex": "#365abd"
    },
    {
      "id": "S143",
      "name": "S143",
      "hex": "#1e22aa"
    },
    {
      "id": "S144",
      "name": "S144",
      "hex": "#002d72"
    },
    {
      "id": "S145",
      "name": "S145",
      "hex": "#e9e186"
    },
    {
      "id": "S146",
      "name": "S146",
      "hex": "#8c243d"
    },
    {
      "id": "S147",
      "name": "S147",
      "hex": "#86c8bc"
    },
    {
      "id": "S148",
      "name": "S148",
      "hex": "#724736"
    },
    {
      "id": "S149",
      "name": "S149",
      "hex": "#fcd299"
    },
    {
      "id": "S150",
      "name": "S150",
      "hex": "#8b84d7"
    },
    {
      "id": "S151",
      "name": "S151",
      "hex": "#335525"
    },
    {
      "id": "S152",
      "name": "S152",
      "hex": "#a7a4e0"
    },
    {
      "id": "S153",
      "name": "S153",
      "hex": "#c6c4ea"
    },
    {
      "id": "S154",
      "name": "S154",
      "hex": "#ebc29d"
    },
    {
      "id": "S155",
      "name": "S155",
      "hex": "#c58b68"
    },
    {
      "id": "S156",
      "name": "S156",
      "hex": "#63666a"
    },
    {
      "id": "S157",
      "name": "S157",
      "hex": "#46494c"
    },
    {
      "id": "S158",
      "name": "S158",
      "hex": "#191d19"
    },
    {
      "id": "S159",
      "name": "S159",
      "hex": "#88888d"
    },
    {
      "id": "SE01",
      "name": "SE01",
      "hex": "#d1dde6"
    },
    {
      "id": "SE02",
      "name": "SE02",
      "hex": "#9bb8e3"
    },
    {
      "id": "SE03",
      "name": "SE03",
      "hex": "#5e8ab4"
    },
    {
      "id": "SE04",
      "name": "SE04",
      "hex": "#6ad1e3"
    },
    {
      "id": "SE05",
      "name": "SE05",
      "hex": "#03c1aa"
    },
    {
      "id": "SE06",
      "name": "SE06",
      "hex": "#126ad4"
    },
    {
      "id": "SE07",
      "name": "SE07",
      "hex": "#bfa5b8"
    },
    {
      "id": "SE08",
      "name": "SE08",
      "hex": "#9b7793"
    },
    {
      "id": "SE09",
      "name": "SE09",
      "hex": "#693c5e"
    },
    {
      "id": "SE10",
      "name": "SE10",
      "hex": "#c964cf"
    },
    {
      "id": "SE11",
      "name": "SE11",
      "hex": "#ad1aac"
    },
    {
      "id": "SE12",
      "name": "SE12",
      "hex": "#ffb25b"
    },
    {
      "id": "SE13",
      "name": "SE13",
      "hex": "#e6a65d"
    },
    {
      "id": "SE14",
      "name": "SE14",
      "hex": "#d38235"
    },
    {
      "id": "SE15",
      "name": "SE15",
      "hex": "#c16c18"
    },
    {
      "id": "SE16",
      "name": "SE16",
      "hex": "#f5b6cd"
    },
    {
      "id": "SE17",
      "name": "SE17",
      "hex": "#5d2a2c"
    }
  ]
};
