// Deliberately synthetic: these IDs must never be presented as real brand codes.
const values = [
 ['奶白','#f8f3e7'],['雪白','#ffffff'],['墨黑','#202525'],['石灰','#a7aaa2'],
 ['深灰','#595e5c'],['浅灰','#d5d9d0'],['樱粉','#eab4b6'],['珊瑚','#db7768'],
 ['朱红','#ba403d'],['酒红','#722f3e'],['桃粉','#f0cbbb'],['肤色','#e6b38c'],
 ['米杏','#d5bb93'],['棕褐','#96704b'],['深棕','#574133'],['焦糖','#bc8651'],
 ['柠黄','#f4d765'],['金黄','#e6b943'],['橙色','#eb9848'],['赭色','#b86539'],
 ['嫩绿','#becd83'],['草绿','#829b5c'],['森林','#426b51'],['墨绿','#294a3e'],
 ['薄荷','#a7c8b1'],['青绿','#61a89d'],['深青','#367c7c'],['浅蓝','#b6d5dc'],
 ['湖蓝','#79a8c3'],['海蓝','#4c779f'],['藏蓝','#35465d'],['薰衣草','#b5a6cb'],
 ['紫色','#866998'],['深紫','#5d436f'],['莓粉','#c983a7'],['米灰','#c5bfb2']
];
const palette = { id:'demo-v1', brand:'演示色板', series:'合成测试色 · 不可采购', version:1, verified:false,
 colors:values.map((v,i)=>({id:'DEMO-'+String(i+1).padStart(2,'0'),name:v[0],hex:v[1]})) };
const board = { id:'demo-square-29',name:'演示方板 29×29',columns:29,rows:29,pitch:5,verified:false,connectable:true };
module.exports = { palette, board };
