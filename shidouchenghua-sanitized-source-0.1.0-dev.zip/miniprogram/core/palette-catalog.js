const artkal=require('./artkal-s');
const mard=require('./mard-221');
const demo=require('./palette').palette;
const clone=v=>JSON.parse(JSON.stringify(v));
function list(custom){return [artkal,mard,...(custom?[custom]:[]),demo].map(clone);}
function get(id,custom){const p=list(custom).find(p=>p.id===id);if(!p)throw Error('所选色卡已不可用，请重新选择');return p;}
function official(p){return p&&p.id===artkal.id&&p.brand===artkal.brand&&p.series===artkal.series&&String(p.version)===String(artkal.version)&&JSON.stringify(p.colors)===JSON.stringify(artkal.colors);}
function reference(p){return p&&p.id===mard.id&&p.brand===mard.brand&&p.series===mard.series&&String(p.version)===String(mard.version)&&JSON.stringify(p.colors)===JSON.stringify(mard.colors);}
function note(p){return official(p)?'Artkal官方RGB参考 · 173色子集 · 未做实物校验':reference(p)?'MARD 221色 · 社区RGB参考，非官方标准 · 未做实物校验':p&&p.id===demo.id?'演示色板 · 不可用于采购，请勿据此采购':'自备色表 · 来源和实物颜色未核验';}
const warning='图纸颜色为屏幕参考，可能与实际豆子及熨烫后的成品存在差异。请按所选品牌、系列和色号核对材料；对颜色要求较高时，建议先用实物试拼。';
module.exports={list,get,official,reference,note,warning};
