function draw(ctx,kind,w,h){ctx.clearRect(0,0,w,h);if(kind==='heart'){
 const pixels=['0011001100','0111111110','1111111111','1111111111','0111111110','0011111100','0001111000','0000110000'];
 const size=w/12;pixels.forEach((row,y)=>row.split('').forEach((v,x)=>{if(v==='1'){ctx.fillStyle=y<3?'#eab4b6':y<6?'#db7768':'#ba403d';ctx.fillRect((x+1)*size,(y+2)*size,size,size);}}));
 }else{ctx.fillStyle='#426b51';ctx.fillRect(w*.47,h*.43,w*.07,h*.48);ctx.beginPath();ctx.ellipse(w*.35,h*.69,w*.17,h*.07,-.5,0,Math.PI*2);ctx.fill();ctx.beginPath();ctx.ellipse(w*.64,h*.78,w*.17,h*.07,.5,0,Math.PI*2);ctx.fill();ctx.fillStyle='#eab4b6';for(let i=0;i<6;i++){const a=i*Math.PI/3;ctx.beginPath();ctx.arc(w*.5+Math.cos(a)*w*.19,h*.34+Math.sin(a)*h*.19,w*.12,0,Math.PI*2);ctx.fill();}ctx.fillStyle='#f4d765';ctx.beginPath();ctx.arc(w*.5,h*.34,w*.115,0,Math.PI*2);ctx.fill();}}
module.exports={draw};
