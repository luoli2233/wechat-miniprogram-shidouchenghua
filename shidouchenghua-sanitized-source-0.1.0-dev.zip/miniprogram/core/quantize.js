const {dimensions}=require('./model');
function rgbLab(r,g,b){
 const a=[r,g,b].map(v=>{v/=255;return v<=.04045?v/12.92:Math.pow((v+.055)/1.055,2.4);});
 const f=t=>t>.008856?Math.cbrt(t):7.787*t+16/116;
 const x=f((a[0]*.4124564+a[1]*.3575761+a[2]*.1804375)/.95047),y=f(a[0]*.2126729+a[1]*.7151522+a[2]*.072175),z=f((a[0]*.0193339+a[1]*.119192+a[2]*.9503041)/1.08883);
 return [116*y-16,500*(x-y),200*(y-z)];
}
function distance(a,b){return (a[0]-b[0])**2+(a[1]-b[1])**2+(a[2]-b[2])**2;}
// Area averaging uses alpha-weighted colors; transparent RGB never pollutes edges.
function sample(data,w,h,columns,rows){
 const out=[];
 for(let y=0;y<rows;y++)for(let x=0;x<columns;x++){
  const x0=x*w/columns,x1=(x+1)*w/columns,y0=y*h/rows,y1=(y+1)*h/rows;
  let sumA=0,r=0,g=0,b=0;
  for(let sy=Math.floor(y0);sy<Math.ceil(y1);sy++)for(let sx=Math.floor(x0);sx<Math.ceil(x1);sx++){
   const weight=(Math.min(x1,sx+1)-Math.max(x0,sx))*(Math.min(y1,sy+1)-Math.max(y0,sy));
   const offset=(sy*w+sx)*4,a=data[offset+3]/255*weight;sumA+=a;r+=data[offset]*a;g+=data[offset+1]*a;b+=data[offset+2]*a;
  }
  out.push(sumA/((x1-x0)*(y1-y0))<.5?null:rgbLab(r/sumA,g/sumA,b/sumA));
 }
 return out;
}
function choose(samples,palette,k){
 const labs=palette.colors.map(c=>rgbLab(...[1,3,5].map(i=>parseInt(c.hex.slice(i,i+2),16))));
 const visible=samples.filter(Boolean);if(!visible.length)throw Error('没有可生成的有效内容');
 // Greedy palette-constrained facility selection, followed by deterministic reassignment.
 const best=visible.map(()=>Infinity),selected=[];
 for(let step=0;step<Math.min(k,labs.length);step++){
  let winner=-1,score=Infinity;
  labs.forEach((lab,index)=>{if(selected.includes(index))return;let cost=0;for(let j=0;j<visible.length;j++)cost+=Math.min(best[j],distance(visible[j],lab));if(cost<score){score=cost;winner=index;}});
  if(winner<0)break;selected.push(winner);visible.forEach((s,j)=>best[j]=Math.min(best[j],distance(s,labs[winner])));if(score===0)break;
 }
 return samples.map(s=>{if(s===null)return null;let winner=selected[0],d=Infinity;selected.forEach(i=>{const next=distance(s,labs[i]);if(next<d){d=next;winner=i;}});return palette.colors[winner].id;});
}
function convert(data,w,h,columns,k,palette){
 if(![8,12,16,24].includes(k))throw Error('颜色参数无效');
 if(data.length!==w*h*4)throw Error('图片数据长度错误');
 const grid=dimensions(w,h,columns);return {...grid,maxColors:k,cells:choose(sample(data,w,h,grid.columns,grid.rows),palette,k)};
}
async function convertAsync(data,w,h,columns,k,palette,cancelled=()=>false){
 if(![8,12,16,24].includes(k)||data.length!==w*h*4)throw Error('转换参数无效');
 const grid=dimensions(w,h,columns),samples=sample(data,w,h,grid.columns,grid.rows);
 const labs=palette.colors.map(c=>rgbLab(...[1,3,5].map(i=>parseInt(c.hex.slice(i,i+2),16)))),visible=samples.filter(Boolean);
 if(!visible.length)throw Error('没有可生成的有效内容');
 const best=visible.map(()=>Infinity),selected=[];
 for(let step=0;step<Math.min(k,labs.length);step++){
  await new Promise(resolve=>setTimeout(resolve,0));if(cancelled())throw Error('已取消生成');
  let winner=-1,score=Infinity;
  labs.forEach((lab,index)=>{if(selected.includes(index))return;let cost=0;for(let j=0;j<visible.length;j++)cost+=Math.min(best[j],distance(visible[j],lab));if(cost<score){score=cost;winner=index;}});
  if(winner<0)break;selected.push(winner);visible.forEach((s,j)=>best[j]=Math.min(best[j],distance(s,labs[winner])));if(score===0)break;
 }
 const cells=samples.map(s=>{if(s===null)return null;let winner=selected[0],d=Infinity;selected.forEach(i=>{const next=distance(s,labs[i]);if(next<d){d=next;winner=i;}});return palette.colors[winner].id;});
 return {...grid,maxColors:k,cells};
}
module.exports={rgbLab,distance,sample,choose,convert,convertAsync};
