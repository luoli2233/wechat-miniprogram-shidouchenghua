const cloud=require('wx-server-sdk');
cloud.init({env:cloud.DYNAMIC_CURRENT_ENV});
const code=error=>Number(error&&(error.errCode!==undefined?error.errCode:error.errcode));
const risky=error=>Boolean(error&&([87014,87017].includes(code(error))||/risky|87014|87017/i.test(error.message||error.errMsg||'')));
const suggestion=result=>String(result&&(result.result&&result.result.suggest||result.suggest)||'').toLowerCase();
function passed(result){
 const suggest=suggestion(result);
 if(suggest)return suggest==='pass';
 const errCode=code(result);
 return !Number.isFinite(errCode)||errCode===0;
}
function failed(error){
 const errCode=code(error),message=String(error&&(error.errMsg||error.message)||'');
 // Do not return upstream details or user input to the client. The short reason is
 // only for actionable UI copy and diagnostics.
 if(risky(error))return {pass:false,risky:true,reason:'content_rejected'};
 if(errCode===-604101||/-604101/.test(message))return {pass:false,risky:false,reason:'permission_not_ready'};
 if([40001,40013,48001].includes(errCode))return {pass:false,risky:false,reason:'account_permission'};
 console.error('[dougeSecurity]',Number.isFinite(errCode)?errCode:'unknown');
 return {pass:false,risky:false,reason:'service_error'};
}
exports.main=async event=>{
 if(event.action==='text'){
  const content=String(event.content||'').trim();if(!content||content.length>500)return {pass:false};
  const {OPENID}=cloud.getWXContext();if(!OPENID)return {pass:false,risky:false,reason:'service_error'};
  try{const result=await cloud.openapi.security.msgSecCheck({content,version:2,scene:4,openid:OPENID});return passed(result)?{pass:true}:{pass:false,risky:true,reason:'content_rejected'};}catch(error){return failed(error);}
 }
 if(event.action!=='image'||typeof event.fileID!=='string'||!event.fileID.startsWith('cloud://')||!event.fileID.includes('/security-check/'))return {pass:false};
 try{
  const file=await cloud.downloadFile({fileID:event.fileID});
  if(!file.fileContent||file.fileContent.length>1024*1024)return {pass:false};
  const png=file.fileContent[0]===0x89&&file.fileContent[1]===0x50;
  const result=await cloud.openapi.security.imgSecCheck({media:{contentType:png?'image/png':'image/jpeg',value:file.fileContent}});
  return passed(result)?{pass:true}:{pass:false,risky:true,reason:'content_rejected'};
 }catch(error){return failed(error);}
 finally{try{await cloud.deleteFile({fileList:[event.fileID]});}catch(ignore){}}
};
