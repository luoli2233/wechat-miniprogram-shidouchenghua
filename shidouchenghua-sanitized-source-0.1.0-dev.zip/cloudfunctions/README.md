# 拾豆成画云函数

- 小程序 AppID：`YOUR_WECHAT_APPID`
- 云环境：`your-cloud-env-id`
- 工程配置：根目录 `project.config.json` 的 `cloudfunctionRoot` 为 `cloudfunctions/`。
- 客户端：`miniprogram/cloud-config.js` 指定环境，`app.js` 启动时初始化；`traceUser:false`。

每个子目录是一项独立云函数：

- `dougeIdentity`：只返回微信提供的调用者身份，不读取或修改数据库、存储，不信任客户端传入的openid。
- `dougeSecurity`：在用户主动分享、保存或导出前检查图片和相关非空标题。图片使用临时云文件，检查结束后由客户端和云函数尝试删除；风险、待复核或服务异常均失败关闭。

云端还存在早期实验函数`dougeContentSecurity`，本地没有对应源码，当前客户端不调用。它是待确认的远程清理项，不能把它视为当前实现，也不要在未确认前直接删除。

## 部署

导入包含`project.config.json`的工程根目录。在微信开发者工具中为云函数目录选择上述环境，然后只对本次变更涉及的函数选择“上传并部署：云端安装依赖”。依赖已固定为`wx-server-sdk@4.0.2`，不需要把服务端npm包打入小程序。

`dougeIdentity/index.js` 使用 `cloud.DYNAMIC_CURRENT_ENV` 跟随实际部署环境。AppSecret、访问令牌和腾讯云密钥不得写入此目录。

云函数部署与小程序代码上传是两个不同步骤；部署函数不会自动更新公众平台上的小程序版本。

`dougeSecurity/config.json`已声明`security.imgSecCheck`和`security.msgSecCheck`。截至2026-09-01，函数虽已完整部署，云端“云调用权限”仍为空，正常文字真实探测返回`permission_not_ready`。这属于发布阻断项；取得正常文字和正常图片的真实`pass:true`前不得重新提审。处理与工单资料见`docs/微信内容安全_部署与提审说明.md`。

## 业务启用边界

云初始化不代表备份启用。`enabled:false` 和 `privacyReady:false` 保持不变，作品与照片不会自动上传。启用备份前还需创建私有集合、验证私有存储、双账号隔离、服务端配额和隐私说明，见 `docs/微信云备份_部署说明.md`。
