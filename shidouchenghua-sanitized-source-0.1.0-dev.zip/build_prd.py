"""Build the companion standalone HTML using Python's standard library."""
from pathlib import Path
import html
import re
import sys

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / (sys.argv[1] if len(sys.argv) > 1 else '照片转拼豆辅助图_PRD_V1.3.md')
TARGET = SOURCE.with_suffix('.html')

def inline(value):
    value = html.escape(value)
    return re.sub(r'\[([^\]]+)\]\((https://[^)]+)\)', r'<a href="\2">\1</a>', value)

lines = SOURCE.read_text(encoding='utf-8').splitlines()
blocks, toc = [], []
i = 0
while i < len(lines):
    line = lines[i].strip()
    if not line:
        i += 1
        continue
    heading = re.match(r'^(#{1,3}) (.+)$', line)
    if heading:
        level, title = len(heading[1]), heading[2]
        anchor = 'section-' + str(len(toc) + 1) if level == 2 else 'heading-' + str(i)
        if level == 2:
            toc.append((anchor, title))
        blocks.append(f'<h{level} id="{anchor}">{inline(title)}</h{level}>')
    elif line.startswith('|'):
        rows = []
        while i < len(lines) and lines[i].strip().startswith('|'):
            cells = [cell.strip() for cell in lines[i].strip().strip('|').split('|')]
            if not all(re.fullmatch(r':?-+:?', cell) for cell in cells):
                rows.append(cells)
            i += 1
        assert len({len(row) for row in rows}) == 1, rows
        head = '<thead><tr>' + ''.join('<th>' + inline(c) + '</th>' for c in rows[0]) + '</tr></thead>'
        body = '<tbody>' + ''.join('<tr>' + ''.join('<td>' + inline(c) + '</td>' for c in row) + '</tr>' for row in rows[1:]) + '</tbody>'
        blocks.append('<div class="table-wrap"><table>' + head + body + '</table></div>')
        continue
    elif line.startswith('- '):
        items = []
        while i < len(lines) and lines[i].startswith('- '):
            items.append('<li>' + inline(lines[i][2:]) + '</li>')
            i += 1
        blocks.append('<ul>' + ''.join(items) + '</ul>')
        continue
    else:
        blocks.append('<p>' + inline(line) + '</p>')
    i += 1

actual_sections = [match.group(1) for _, title in toc
                   for match in [re.match(r'^(\d+)\.', title)] if match]
expected_sections = [str(index) for index in range(1, len(actual_sections) + 1)]
assert actual_sections == expected_sections, 'PRD sections must be consecutively numbered'
navigation = '<nav aria-label="文档目录"><b>文档目录</b><ol>' + ''.join(f'<li><a href="#{key}">{inline(title)}</a></li>' for key, title in toc) + '</ol></nav>'
style = '''
:root{--ink:#22364a;--accent:#b65e36;--line:#dce3e9;--paper:#fff;--bg:#f1f4f7}
*{box-sizing:border-box}html{scroll-behavior:smooth;scroll-padding-top:80px}
body{margin:0;background:var(--bg);color:#293747;font:15px/1.85 "Microsoft YaHei","PingFang SC",sans-serif}
.toolbar{position:sticky;top:0;z-index:2;background:var(--ink);color:white;padding:12px 5%;display:flex;justify-content:space-between;gap:20px;align-items:center}
button{background:#f0b88c;color:#22364a;border:0;border-radius:6px;padding:9px 18px;font:inherit;cursor:pointer}
main{max-width:1120px;margin:32px auto 60px;background:white;padding:54px 64px;box-shadow:0 10px 40px #22364a10;border-top:5px solid var(--accent)}
h1{font-size:30px;line-height:1.5;color:var(--ink);margin:0 0 20px}h2{font-size:23px;color:var(--ink);border-bottom:2px solid var(--line);padding-bottom:10px;margin:42px 0 20px}h3{font-size:17px;margin:25px 0 10px;color:#8f492c}
p{margin:10px 0 16px;overflow-wrap:anywhere}a{color:#245f89;text-decoration:none}a:hover{text-decoration:underline}
nav{background:#f4f7f9;padding:24px 30px;margin:30px 0;border-left:4px solid var(--accent)}nav ol{columns:2;list-style:none;padding:0;margin:12px 0 0}nav li{break-inside:avoid;padding:3px 0}
.table-wrap{overflow-x:auto;margin:18px 0 24px}table{border-collapse:collapse;width:100%;font-size:13px;line-height:1.7}th{background:#edf2f6;color:var(--ink);text-align:left;font-weight:700}td,th{border:1px solid var(--line);padding:10px 12px;vertical-align:top;overflow-wrap:anywhere}tbody tr:nth-child(even){background:#fafbfc}li{margin:6px 0}footer{margin-top:40px;border-top:1px solid var(--line);padding-top:20px;color:#677685;font-size:12px}
@media(max-width:720px){main{margin:0;padding:28px 18px}h1{font-size:25px}nav ol{columns:1}table{min-width:570px}.toolbar{padding:10px 18px;font-size:12px}}
@page{size:A4;margin:16mm 14mm 18mm}
@media print{html{scroll-padding:0}body{background:white;font-size:10pt;line-height:1.65}.toolbar,nav{display:none}main{max-width:none;margin:0;padding:0;border:0;box-shadow:none}h1{font-size:22pt}h2{font-size:15pt;margin-top:22pt;break-after:avoid}h3{font-size:11.5pt;break-after:avoid}p{orphans:3;widows:3}table{font-size:9pt;min-width:0!important}thead{display:table-header-group}tr{break-inside:avoid}td,th{padding:6pt 7pt}.table-wrap{overflow:visible}a{color:inherit}footer{font-size:8pt}*{-webkit-print-color-adjust:exact;print-color-adjust:exact}}
'''
body = '\n'.join(blocks)
first_section = body.index('<h2')
body = body[:first_section] + navigation + body[first_section:]
page = '<!doctype html>\n<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>照片转拼豆辅助图 · PRD V1.1</title><style>' + style + '</style></head><body><div class="toolbar"><span>PRD V1.1 · 完整修订稿 · 2026-08-31</span><button type="button" onclick="window.print()">打印 / 保存 PDF</button></div><main>' + body + '<footer>照片转拼豆辅助图 · PRD V1.1 · 对应产品 V1.0 首发范围 · 本地独立文档，无外部脚本、字体或图片依赖。</footer></main></body></html>'
version_match = re.search(r'PRD_V(\d+\.\d+)', SOURCE.name)
if version_match:
    page = page.replace('PRD V1.1', 'PRD V' + version_match.group(1))
if version_match and version_match.group(1) != '1.1':
    scope = '含产品 V1.0 基线与社区、素材拼贴扩展'
    if version_match.group(1) == '1.3':
        scope += '及AI照片风格化需求'
    if '微信小程序当前范围（优先执行）' in SOURCE.read_text(encoding='utf-8'):
        scope = '微信当前范围以文首说明为准；后附历史需求基线'
    page = page.replace('对应产品 V1.0 首发范围', scope)
TARGET.write_text(page, encoding='utf-8')
print(f'Generated: {TARGET.name}')
print(f'Sections: {len(toc)}; Tables: {page.count("<table>")}; Characters: {len(page)}')
